---
  title: "Seasonal dynamics of the gut microbiome in urban feral pigeons are associated with environmental conditions, not with diet shifts"
author: "Kangqing Zhang"
date: "October 09, 2025"
---

  #####################################################################################

# DNA metabarcoding successfully quantifies relative abundances of food taxa in pigeon's diets
##For Metazoa (COI_primer)
#R 4.4.0
#getting started with a session
#if required, clear workspace
rm(list = ls())
setwd("D:/pigeon/metabarcoding/pigeondata/analyist_COI")
getwd()

#if (!require("BiocManager", quietly = TRUE))
  #install.packages("BiocManager")
#BiocManager::install("Rqc")

library(phyloseq)
library(Rqc)
theme_set(theme_bw())
library(data.table)
library(vegan)
library(plyr)
library(reshape2)
library(dplyr)
library(RColorBrewer)
library(colorRamps)
library(colorspace)
library("gridExtra")
library(openxlsx)
packageVersion('phyloseq')
library("ggplot2"); packageVersion("ggplot2")
library(ape)
library(phyloseq)
library(microbiome)
library(decontam)
library(vsn)
library(ape)
library(venn)
library(directlabels)
library(doBy)
library(Rmisc)
library(lme4)
library(nlme)
library(nortest)
library(data.table)
library(cluster)
library(rockchalk)
library(blmeco)
library(glmmTMB)
library(bbmle)
library(MuMIn)
library(rcompanion)
library(qqplotr)
library(car)
library(btools)
library(multcomp)
library(multcompView)
library(cowplot)
library(devtools)
library(pairwiseAdonis) # for posthoc ADONIS analysis
library(emmeans)
library(sjPlot) #for plotting lmer and glmer mods
library(sjmisc)
library(effects)
library(sjstats) #use for r2 functions
library(ggeffects)
library(ade4) # v 1.7-16
library(ICC)
library(pheatmap)
library(dunn.test)
library(ggsignif)
library(coin)

cols2 <- c( "#CC79A7", "#F0E442", "#009E73", "#D55E00", "#E69F00",
            "#7570B3", "#56B4E9", "#CC6666", "#0072B2", "#66CC99",
            "#A6761D", "#A65628", "#7570B3", "#66A61E", "#F781BF",
            "#E6AB02", "#08519C", "#A6761D", "#377EB8", "#4DAF4A",
            "#984EA3", "#238443", "#FFFF33", "#A65628", "#F781BF",
            "#66A61E", "#1B9E77", "#D95F02" ,"#999999", "#E7298A",
            "#999999", "#E69F00", "#009E73", "#56B4E9", "#F0E442",
            "#CC79A7", "#999999", "#E69F00", "#009E73", "#56B4E9",
            "#CC79A7", "#D55E00", "#0072B2", "#CC6666", "#66CC99",
            "#A6761D", "#7570B3", "#A65628", "#F781BF", "#66A61E",
            "#E6AB02", "#08519C", "#A6761D", "#377EB8", "#4DAF4A",
            "#984EA3", "#238443", "#FFFF33", "#A65628", "#F781BF",
            "#66A61E", "#1B9E77", "#D95F02" ,"#7570B3", "#E7298A",
            "#999999", "#E69F00", "#009E73", "#56B4E9", "#F0E442",
            "#CC79A7")

cols <- c("#1B9E77", "#D95F02" ,"#7570B3", "#E7298A", "#66A61E",
          "#E6AB02", "#A6761D", "#08519C", "#377EB8", "#4DAF4A",
          "#984EA3", "#238443", "#FFFF33", "#A65628", "#F781BF")
colsSeason <- c("WINTER" = "blue", "SUMMER" = "red")
allGroupsColors<- c(
  "orange", "grey50", "purple", "deepskyblue",
  "red", "darkred", "grey0", "green4")
cbbPalette <- c("#E69F00", "#56B4E9")
cbbPalette_1 <- c("#009E73", "#F0E442")

Sex_labels <- c("F" = "females",
                "M" = "males")
Local_labels<-c("MOLUKKENPAD","NOORDERPLANTSOEN","VISMARKT" )

#######################################COI_primer###########################################
#STEP1-1
#PREPRstep > substract negative controls from OTU file#########
## NC_kits
#set working directory and check
setwd("D:/pigeon/metabarcoding/pigeondata/analyist_COI")
getwd()

COI_ASV_Table<- read.table("COI_ASV_Table.txt", header=T, sep="\t")
COI_ASV_Table<- as.data.frame(COI_ASV_Table)
#make OTUs rownames
row.names(COI_ASV_Table)<- COI_ASV_Table$asv_id
COI_ASV_Table_2<-COI_ASV_Table
COI_ASV_Table_2<-COI_ASV_Table_2[,-1]
NC_Kits<- read.table("NC_Kits.txt", header=T, sep="\t")
NC_Kits<- as.data.frame(NC_Kits)
#make rownames
row.names(NC_Kits)<- NC_Kits$X
names(NC_Kits)

NCkit1<- NC_Kits[,2]
NCkit1<- as.data.frame(NCkit1)
row.names(NCkit1)<- NC_Kits$X

NCkit2<- NC_Kits[,3]
NCkit2<- as.data.frame(NCkit2)
row.names(NCkit2)<- NC_Kits$X

neg_controls_kits<- read.table("neg_controls_kits.txt", header=T, sep="\t")

##
nc_kit1_samples <- neg_controls_kits$sample[neg_controls_kits$negcontrol == "nc_kit1"]
# Use match() to find the corresponding indices in COI_ASV_Table_2
nc_kit1_indices <- match(nc_kit1_samples, colnames(COI_ASV_Table_2))

nc_kit2_samples <- neg_controls_kits$sample[neg_controls_kits$negcontrol == "nc_kit2"]
# Use match() to find the corresponding indices in COI_ASV_Table_2
nc_kit2_indices <- match(nc_kit2_samples, colnames(COI_ASV_Table_2))

nc_kit1_matrix <- matrix(rep(NCkit1, each = length(nc_kit1_indices)), byrow = TRUE, ncol = length(nc_kit1_indices))
nc_kit2_matrix<- matrix(rep(NCkit2, each = length(nc_kit2_indices)), byrow = TRUE, ncol = length(nc_kit2_indices))
nc_kit_total<- cbind(nc_kit1_matrix, nc_kit2_matrix)

COI_asv_table_nonc <- COI_ASV_Table_2 - nc_kit_total
row.names(COI_asv_table_nonc)<- row.names(COI_ASV_Table)
COI_asv_table_nonc$asv_id<-row.names(COI_asv_table_nonc)
### Export
write.csv(COI_asv_table_nonc, file = "COI_asv_table_nokitsnc_20240822.csv", quote = FALSE, row.names = T)
write.xlsx(COI_asv_table_nonc, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "COI_asv_table_nokitsnc_20240822.xlsx"))

# Replace negative values in COI_asv_table_nonc with 0
COI_asv_table_nonc[COI_asv_table_nonc < 0] <- 0

write.csv(COI_asv_table_nonc, file = "COI_asv_table_nokitsnc_20240822_noneg.csv", quote = FALSE, row.names = T)
write.xlsx(COI_asv_table_nonc, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "COI_asv_table_nokitsnc_20240822_noneg.xlsx"))

#STEP1-2
#PREPRstep > substract negative controls from OTU file#########
## NC_pcr
# input neg_controls_pcr.txt and NC_pcr.txt
NC_pcr<- read.table("NC_pcr.txt", header=T, sep="\t")
NC_pcr<- as.data.frame(NC_pcr)
#make rownames
row.names(NC_pcr)<- NC_pcr$X
names(NC_pcr)

NCpcr1<- NC_pcr[,3]
NCpcr1<- as.data.frame(NCpcr1)
row.names(NCpcr1)<- NC_pcr$X

NCpcr2<- NC_pcr[,4]
NCpcr2<- as.data.frame(NCpcr2)
row.names(NCpcr2)<- NC_pcr$X

NCpcr3<- NC_pcr[,2]
NCpcr3<- as.data.frame(NCpcr3)
row.names(NCpcr3)<- NC_pcr$X

neg_controls_pcr<- read.table("neg_controls_pcr.txt", header=T, sep="\t")

##
nc_pcr1_samples <- neg_controls_pcr$sample[neg_controls_pcr$negcontrol == "NC_pcr001"]
# Use match() to find the corresponding indices in COI_asv_table_nonc
nc_pcr1_indices <- match(nc_pcr1_samples, colnames(COI_asv_table_nonc))

nc_pcr2_samples <- neg_controls_pcr$sample[neg_controls_pcr$negcontrol == "NC_pcr002"]
# Use match() to find the corresponding indices in COI_asv_table_nonc
nc_pcr2_indices <- match(nc_pcr2_samples, colnames(COI_asv_table_nonc))

nc_pcr3_samples <- neg_controls_pcr$sample[neg_controls_pcr$negcontrol == "NC_pcr003"]
# Use match() to find the corresponding indices in COI_asv_table_nonc
nc_pcr3_indices <- match(nc_pcr3_samples, colnames(COI_asv_table_nonc))

nc_pcr1_matrix <- matrix(rep(NCpcr1, each = length(nc_pcr1_indices)), byrow = TRUE, ncol = length(nc_pcr1_indices))
nc_pcr2_matrix<- matrix(rep(NCpcr2, each = length(nc_pcr2_indices)), byrow = TRUE, ncol = length(nc_pcr2_indices))
nc_pcr3_matrix<- matrix(rep(NCpcr3, each = length(nc_pcr3_indices)), byrow = TRUE, ncol = length(nc_pcr3_indices))
nc_pcr_total<- cbind(nc_pcr1_matrix, nc_pcr2_matrix, nc_pcr3_matrix)

# Define the sample names to exclude
samples_to_exclude <- c("Plant004013", "Plant007038", "Plant006076", "asv_id")
# Subset the matrix to exclude columns by their names
small_matrix <- COI_asv_table_nonc[, (colnames(COI_asv_table_nonc) %in% samples_to_exclude)]

COI_asv_table_nonc_nopcr <- COI_asv_table_nonc[, !(colnames(COI_asv_table_nonc) %in% samples_to_exclude)]

COI_asv_table_nonc_nopcr <- COI_asv_table_nonc_nopcr - nc_pcr_total

row.names(COI_asv_table_nonc_nopcr)<- row.names(COI_asv_table_nonc)

COI_asv_table_nonc_nopcr_2<-cbind(COI_asv_table_nonc_nopcr, small_matrix)

### Export
write.csv(COI_asv_table_nonc_nopcr_2, file = "COI_asv_table_nokitsnc_nopcr_20240822.csv", quote = FALSE, row.names = T)
write.xlsx(COI_asv_table_nonc_nopcr_2, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "COI_asv_table_nokitsnc_nopcr_20240822.xlsx"))

# Replace negative values in COI_asv_table_nonc_nopcr_2 with 0
COI_asv_table_nonc_nopcr_2[COI_asv_table_nonc_nopcr_2 < 0] <- 0

write.csv(COI_asv_table_nonc_nopcr_2, file = "COI_asv_table_nokitsnc_nopcr_20240822_noneg.csv", quote = FALSE, row.names = T)
write.xlsx(COI_asv_table_nonc_nopcr_2, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "COI_asv_table_nokitsnc_nopcr_20240822_noneg.xlsx"))

##################################################################################################
#STEP 1-3
otu<-read.table("COI_asv_table_nokitsnc_nopcr_20240822_noneg.txt", header=TRUE)
head(otu)
tax<-read.table("taxatable_COI_20240821.txt", sep='\t', header=TRUE)
head(tax)
## merge otu and tax file
merged_file<-merge(otu, tax, by.x=c("asv_id"), by.y=c("asv_id"))
head(merged_file)
write.table(merged_file, file="combined_otu_tax.txt", sep='\t', col.names=TRUE, row.names=FALSE)

#STEP 1-4
#Compered with repeated COI samples(COI001013 and FP.GR18095,COI002038 and FP.GR18069,COI003076 and M4, FP.GR18246 and KQZ2468_2)
#####
repected_COI_samples_013 <- merged_file[, c("asv_id","COI001013", "FP.GR18095", "lca_rank", "lca_taxon", "method","reference_db", "kingdom", "phylum", "class", "order", "family", "genus", "species")]
repected_COI_samples_038 <- merged_file[, c("asv_id","COI002038", "FP.GR18069", "lca_rank", "lca_taxon", "method","reference_db", "kingdom", "phylum", "class", "order", "family", "genus", "species")]
repected_COI_samples_076 <- merged_file[, c("asv_id","COI003076", "M4", "lca_rank", "lca_taxon", "method","reference_db", "kingdom", "phylum", "class", "order", "family", "genus", "species")]
repected_COI_samples_068 <- merged_file[, c("asv_id","FP.GR18246", "KQZ2468_2", "lca_rank", "lca_taxon", "method","reference_db", "kingdom", "phylum", "class", "order", "family", "genus", "species")]


repected_COI_samples_013_asv_table <- merged_file[, c("COI001013", "FP.GR18095")]
repected_COI_samples_038_asv_table <- merged_file[, c("COI002038", "FP.GR18069")]
repected_COI_samples_076_asv_table <- merged_file[, c("COI003076", "M4")]
repected_COI_samples_068_asv_table <- merged_file[, c("FP.GR18246", "KQZ2468_2")]

repected_COI_samples_013_asv_table<- as.data.frame(repected_COI_samples_013_asv_table)
repected_COI_samples_038_asv_table<- as.data.frame(repected_COI_samples_038_asv_table)
repected_COI_samples_076_asv_table<- as.data.frame(repected_COI_samples_076_asv_table)
repected_COI_samples_068_asv_table<- as.data.frame(repected_COI_samples_068_asv_table)

row.names(repected_COI_samples_013_asv_table)<- repected_COI_samples_013$asv_id
row.names(repected_COI_samples_038_asv_table)<- repected_COI_samples_038$asv_id
row.names(repected_COI_samples_076_asv_table)<- repected_COI_samples_076$asv_id
row.names(repected_COI_samples_068_asv_table)<- repected_COI_samples_068$asv_id

###presence and absence
presence_absence_013 <- (repected_COI_samples_013_asv_table > 0) * 1
presence_absence_diff_013 <- presence_absence_013[, "COI001013"] - presence_absence_013[, "FP.GR18095"]
#In the results, 1 means that ASV is present only in COI001013, -1 means it is present only in FP.GR18095, and 0 means it is present in both samples
presence_absence_diff_013
presence_absence_matrix_013 <- as.matrix(presence_absence_diff_013)
rownames(presence_absence_matrix_013) <- names(presence_absence_diff_013)
colnames(presence_absence_matrix_013) <- "Presence_Absence_Diff"

count_1 <- sum(presence_absence_matrix_013[, 1] == 1)
count_minus1 <- sum(presence_absence_matrix_013[, 1] == -1)
count_0 <- sum(presence_absence_matrix_013[, 1] == 0)

cat("Number of ASVs with 1 (present in COI001013 only):", count_1, "\n")
cat("Number of ASVs with -1 (present in FP.GR18095 only):", count_minus1, "\n")
cat("Number of ASVs with 0 (present in both samples):", count_0, "\n")
#Number of ASVs with 1 (present in COI001013 only): 49
#Number of ASVs with -1 (present in FP.GR18095 only): 24
#Number of ASVs with 0 (present in both samples): 960
#(49-24)/1033=0.024 (2.4%)
write.table(presence_absence_matrix_013, file = "presence_absence_matrix_013.txt", sep = "\t", row.names = TRUE, col.names = TRUE, quote = FALSE)

###COI002038 and FP.GR18069
presence_absence_038 <- (repected_COI_samples_038_asv_table > 0) * 1
presence_absence_diff_038 <- presence_absence_038[, "COI002038"] - presence_absence_038[, "FP.GR18069"]
#In the results, 1 means that ASV is present only in COI002038, -1 means it is present only in FP.GR18069, and 0 means it is present in both samples
presence_absence_diff_038
presence_absence_matrix_038 <- as.matrix(presence_absence_diff_038)
rownames(presence_absence_matrix_038) <- names(presence_absence_diff_038)
colnames(presence_absence_matrix_038) <- "Presence_Absence_Diff"

count_1 <- sum(presence_absence_matrix_038[, 1] == 1)
count_minus1 <- sum(presence_absence_matrix_038[, 1] == -1)
count_0 <- sum(presence_absence_matrix_038[, 1] == 0)

cat("Number of ASVs with 1 (present in COI002038 only):", count_1, "\n")
cat("Number of ASVs with -1 (present in FP.GR18069 only):", count_minus1, "\n")
cat("Number of ASVs with 0 (present in both samples):", count_0, "\n")
#Number of ASVs with 1 (present in COI002038 only): 70
#Number of ASVs with -1 (present in FP.GR18069 only): 36
#Number of ASVs with 0 (present in both samples): 927
#(70-36)/1033=0.032 (3.2%)
write.table(presence_absence_matrix_038, file = "presence_absence_matrix_038.txt", sep = "\t", row.names = TRUE, col.names = TRUE, quote = FALSE)

###COI003076 and M4
presence_absence_076 <- (repected_COI_samples_076_asv_table > 0) * 1
presence_absence_diff_076 <- presence_absence_076[, "COI003076"] - presence_absence_076[, "M4"]
#In the results, 1 means that ASV is present only in COI003076, -1 means it is present only in M4, and 0 means it is present in both samples
presence_absence_diff_076
presence_absence_matrix_076 <- as.matrix(presence_absence_diff_076)
rownames(presence_absence_matrix_076) <- names(presence_absence_diff_076)
colnames(presence_absence_matrix_076) <- "Presence_Absence_Diff"

count_1 <- sum(presence_absence_matrix_076[, 1] == 1)
count_minus1 <- sum(presence_absence_matrix_076[, 1] == -1)
count_0 <- sum(presence_absence_matrix_076[, 1] == 0)

cat("Number of ASVs with 1 (present in COI003076 only):", count_1, "\n")
cat("Number of ASVs with -1 (present in M4 only):", count_minus1, "\n")
cat("Number of ASVs with 0 (present in both samples):", count_0, "\n")
#Number of ASVs with 1 (present in COI003076 only): 61
#Number of ASVs with -1 (present in M4 only): 41
#Number of ASVs with 0 (present in both samples): 931
#(61-41)/1033=0.019 (1.9%)
write.table(presence_absence_matrix_076, file = "presence_absence_matrix_076.txt", sep = "\t", row.names = TRUE, col.names = TRUE, quote = FALSE)

###FP.GR18246 and KQZ2468_2
presence_absence_068 <- (repected_COI_samples_068_asv_table > 0) * 1
presence_absence_diff_068 <- presence_absence_068[, "FP.GR18246"] - presence_absence_068[, "KQZ2468_2"]
#In the results, 1 means that ASV is present only in FP.GR18246, -1 means it is present only in KQZ2468_2, and 0 means it is present in both samples
presence_absence_diff_068
presence_absence_matrix_068 <- as.matrix(presence_absence_diff_068)
rownames(presence_absence_matrix_068) <- names(presence_absence_diff_068)
colnames(presence_absence_matrix_068) <- "Presence_Absence_Diff"

count_1 <- sum(presence_absence_matrix_068[, 1] == 1)
count_minus1 <- sum(presence_absence_matrix_068[, 1] == -1)
count_0 <- sum(presence_absence_matrix_068[, 1] == 0)

cat("Number of ASVs with 1 (present in FP.GR18246 only):", count_1, "\n")
cat("Number of ASVs with -1 (present in KQZ2468_2 only):", count_minus1, "\n")
cat("Number of ASVs with 0 (present in both samples):", count_0, "\n")
#Number of ASVs with 1 (present in FP.GR18246 only): 53
#Number of ASVs with -1 (present in KQZ2468_2 only): 41
#Number of ASVs with 0 (present in both samples): 939
#(53-41)/1033=0.012 (1.2%)
write.table(presence_absence_matrix_068, file = "presence_absence_matrix_068.txt", sep = "\t", row.names = TRUE, col.names = TRUE, quote = FALSE)

##########Abundance Compered###################
#The difference in abundance between the two samples was calculated
asv_abundance_diff_013 <- repected_COI_samples_013_asv_table[, "COI001013"] - repected_COI_samples_013_asv_table[, "FP.GR18095"]
asv_abundance_diff_013
asv_abundance_diff_013 <- as.matrix(asv_abundance_diff_013)
rownames(asv_abundance_diff_013) <- repected_COI_samples_013$asv_id
colnames(asv_abundance_diff_013) <- "Asv_Abundance_Diff"
summary(asv_abundance_diff_013)
significant_asv_abundance_diff_013_df <- asv_abundance_diff_013[abs(asv_abundance_diff_013[, 1]) > 100, ]
significant_asv_abundance_diff_013_df
#Zotu1(1233) Zotu3(1415) Zotu5(92)
#only 3 asvs have over 100 different reads between COI001013 and FP.GR18095

###COI002038 and FP.GR18069
asv_abundance_diff_038 <- repected_COI_samples_038_asv_table[, "COI002038"] - repected_COI_samples_038_asv_table[, "FP.GR18069"]
asv_abundance_diff_038
asv_abundance_diff_038 <- as.matrix(asv_abundance_diff_038)
rownames(asv_abundance_diff_038) <- repected_COI_samples_038$asv_id
colnames(asv_abundance_diff_038) <- "Asv_Abundance_Diff"
summary(asv_abundance_diff_038)
significant_asv_abundance_diff_038_df <- asv_abundance_diff_038[abs(asv_abundance_diff_038[, 1]) > 100, ]
significant_asv_abundance_diff_038_df
#Zotu1(1000) Zotu10(120)  Zotu2(1186) Zotu22(248)  Zotu3(214) Zotu30(168)  Zotu7(418)
# 7 asvs have over 100 different reads between COI002038 and FP.GR18069

###COI003076 and M4
asv_abundance_diff_076 <- repected_COI_samples_076_asv_table[, "COI003076"] - repected_COI_samples_076_asv_table[, "M4"]
asv_abundance_diff_076
asv_abundance_diff_076 <- as.matrix(asv_abundance_diff_076)
rownames(asv_abundance_diff_076) <- repected_COI_samples_076$asv_id
colnames(asv_abundance_diff_076) <- "Asv_Abundance_Diff"
summary(asv_abundance_diff_076)
significant_asv_abundance_diff_076_df <- asv_abundance_diff_076[abs(asv_abundance_diff_076[, 1]) > 100, ]
significant_asv_abundance_diff_076_df
# No asv have over 100 different reads between COI003076 and M4
##There are not much different between COI001013 and FP.GR18095,COI002038 and FP.GR18069,COI003076 and M4

###FP.GR18246 and KQZ2468_2
asv_abundance_diff_068 <- repected_COI_samples_068_asv_table[, "FP.GR18246"] - repected_COI_samples_068_asv_table[, "KQZ2468_2"]
asv_abundance_diff_068
asv_abundance_diff_068 <- as.matrix(asv_abundance_diff_068)
rownames(asv_abundance_diff_068) <- repected_COI_samples_068$asv_id
colnames(asv_abundance_diff_068) <- "Asv_Abundance_Diff"
summary(asv_abundance_diff_068)
significant_asv_abundance_diff_068_df <- asv_abundance_diff_068[abs(asv_abundance_diff_068[, 1]) > 100, ]
significant_asv_abundance_diff_068_df
#Zotu1(499) Zotu17(172)
# 2 asvs have over 100 different reads between FP.GR18246 and KQZ2468_2
# There are not much different between FP.GR18246 and KQZ2468_2

#mock samples
COI_mock_samples_asv_table <- merged_file[, c("asv_id", "M1", "M2", "M3", "M4", "M5", "M6", "M7", "M8", "M9", "M10", "M11", "M12","lca_rank", "lca_taxon", "method","reference_db", "kingdom", "phylum", "class", "order", "family", "genus", "species")]
rownames(COI_mock_samples_asv_table) <- COI_mock_samples_asv_table$asv_id
COI_mock_samples_asv_table_df <- COI_mock_samples_asv_table[apply(COI_mock_samples_asv_table[,2:13],1,function(x) any(x>100)), ]
COI_mock_samples_asv_table_df
#M1:M7 have no identification taxa(Zotu20),M8 have Homo sapiens in there(Zotu8 and Zotu85),M9:M12 have two different groups of fungi (Zotu24,Zotu28,Zotu39,Zotu40,Zotu42)
# they are could be possible

##remove mock samples(M1:M12),multiply COI and plant samples(COI001013,COI002038,COI003076,Plant004013,Plant006076,Plant007038 and KQZ2468_2)
colnames(COI_asv_table_nonc_nopcr_2)
cols_to_remove <- grep("^(M|COI|Plant|KQZ)", colnames(COI_asv_table_nonc_nopcr_2), value = TRUE)
COI_asv_table_nonc_nopcr_2_only_poopNC<-COI_asv_table_nonc_nopcr_2[, !colnames(COI_asv_table_nonc_nopcr_2) %in% cols_to_remove]
colnames(COI_asv_table_nonc_nopcr_2_only_poopNC)
write.table(COI_asv_table_nonc_nopcr_2_only_poopNC, file = "COI_asv_table_nonc_nopcr_2_only_poopNC.txt", sep = "\t", row.names = TRUE, col.names = TRUE, quote = FALSE)

## NC for poop samples
nc_poop_all<-COI_asv_table_nonc_nopcr_2_only_poopNC[, c("asv_id","FP.GR18067","FP.GR18053","FP.GR18071","FP.GR18080","FP.GR18064","FP.GR18275","FP.GR18097","FP.GR18252")]
nc_poop_all<- as.data.frame(nc_poop_all)
rownames(nc_poop_all) <- nc_poop_all$asv_id

nc_poop_0408<- nc_poop_all[,2]
nc_poop_0408<- as.data.frame(nc_poop_0408)
row.names(nc_poop_0408)<- nc_poop_0408$X

nc_poop_0707<- nc_poop_all[,3]
nc_poop_0707<- as.data.frame(nc_poop_0707)
row.names(nc_poop_0707)<- nc_poop_0707$X

nc_poop_1702<- nc_poop_all[,4]
nc_poop_1702<- as.data.frame(nc_poop_1702)
row.names(nc_poop_1702)<- nc_poop_1702$X

nc_poop_2702<- nc_poop_all[,5]
nc_poop_2702<- as.data.frame(nc_poop_2702)
row.names(nc_poop_2702)<- nc_poop_2702$X

nc_poop_1102<- nc_poop_all[,6]
nc_poop_1102<- as.data.frame(nc_poop_1102)
row.names(nc_poop_1102)<- nc_poop_1102$X

nc_poop_1207<- nc_poop_all[,7]
nc_poop_1207<- as.data.frame(nc_poop_1207)
row.names(nc_poop_1207)<- nc_poop_1207$X

nc_poop_1802<- nc_poop_all[,8]
nc_poop_1802<- as.data.frame(nc_poop_1802)
row.names(nc_poop_1802)<- nc_poop_1802$X

nc_poop_2508<- nc_poop_all[,9]
nc_poop_2508<- as.data.frame(nc_poop_2508)
row.names(nc_poop_2508)<- nc_poop_2508$X

neg_controls_poop_nc<- read.table("neg_controls_poop_nc.txt", header=T, sep="\t")

##
nc_poop_0408_samples <- neg_controls_poop_nc$sample[neg_controls_poop_nc$negcontrol == "nc_poop_0408"]
# Use match() to find the corresponding indices in COI_asv_table_nonc_nopcr_2_only_poopNC
nc_poop_0408_indices <- match(nc_poop_0408_samples, colnames(COI_asv_table_nonc_nopcr_2_only_poopNC))

nc_poop_0707_samples <- neg_controls_poop_nc$sample[neg_controls_poop_nc$negcontrol == "nc_poop_0707"]
nc_poop_0707_indices <- match(nc_poop_0707_samples, colnames(COI_asv_table_nonc_nopcr_2_only_poopNC))

nc_poop_1702_samples <- neg_controls_poop_nc$sample[neg_controls_poop_nc$negcontrol == "nc_poop_1702"]
nc_poop_1702_indices <- match(nc_poop_1702_samples, colnames(COI_asv_table_nonc_nopcr_2_only_poopNC))

nc_poop_2702_samples <- neg_controls_poop_nc$sample[neg_controls_poop_nc$negcontrol == "nc_poop_2702"]
nc_poop_2702_indices <- match(nc_poop_2702_samples, colnames(COI_asv_table_nonc_nopcr_2_only_poopNC))

nc_poop_1102_samples <- neg_controls_poop_nc$sample[neg_controls_poop_nc$negcontrol == "nc_poop_1102"]
nc_poop_1102_indices <- match(nc_poop_1102_samples, colnames(COI_asv_table_nonc_nopcr_2_only_poopNC))

nc_poop_1207_samples <- neg_controls_poop_nc$sample[neg_controls_poop_nc$negcontrol == "nc_poop_1207"]
nc_poop_1207_indices <- match(nc_poop_1207_samples, colnames(COI_asv_table_nonc_nopcr_2_only_poopNC))

nc_poop_1802_samples <- neg_controls_poop_nc$sample[neg_controls_poop_nc$negcontrol == "nc_poop_1802"]
nc_poop_1802_indices <- match(nc_poop_1802_samples, colnames(COI_asv_table_nonc_nopcr_2_only_poopNC))

nc_poop_2508_samples <- neg_controls_poop_nc$sample[neg_controls_poop_nc$negcontrol == "nc_poop_2508"]
nc_poop_2508_indices <- match(nc_poop_2508_samples, colnames(COI_asv_table_nonc_nopcr_2_only_poopNC))

nc_poop_0408_matrix <- matrix(rep(nc_poop_0408, each = length(nc_poop_0408_indices)), byrow = TRUE, ncol = length(nc_poop_0408_indices))
nc_poop_0707_matrix <- matrix(rep(nc_poop_0707, each = length(nc_poop_0707_indices)), byrow = TRUE, ncol = length(nc_poop_0707_indices))
nc_poop_1702_matrix <- matrix(rep(nc_poop_1702, each = length(nc_poop_1702_indices)), byrow = TRUE, ncol = length(nc_poop_1702_indices))
nc_poop_2702_matrix <- matrix(rep(nc_poop_2702, each = length(nc_poop_2702_indices)), byrow = TRUE, ncol = length(nc_poop_2702_indices))
nc_poop_1102_matrix <- matrix(rep(nc_poop_1102, each = length(nc_poop_1102_indices)), byrow = TRUE, ncol = length(nc_poop_1102_indices))
nc_poop_1207_matrix <- matrix(rep(nc_poop_1207, each = length(nc_poop_1207_indices)), byrow = TRUE, ncol = length(nc_poop_1207_indices))
nc_poop_1802_matrix <- matrix(rep(nc_poop_1802, each = length(nc_poop_1802_indices)), byrow = TRUE, ncol = length(nc_poop_1802_indices))
nc_poop_2508_matrix <- matrix(rep(nc_poop_2508, each = length(nc_poop_2508_indices)), byrow = TRUE, ncol = length(nc_poop_2508_indices))

nc_poop_total<- cbind(nc_poop_0408_matrix, nc_poop_0707_matrix, nc_poop_1702_matrix, nc_poop_2702_matrix, nc_poop_1102_matrix, nc_poop_1207_matrix, nc_poop_1802_matrix, nc_poop_2508_matrix)
COI_asv_table_nonc_nopcr_2_nopoopnc <- COI_asv_table_nonc_nopcr_2_only_poopNC[,!((COI_asv_table_nonc_nopcr_2_only_poopNC) %in% nc_poop_all)]
selected_columns <- neg_controls_poop_nc$sample
COI_asv_table_nonc_nopcr_2_nopoopnc_filter <- COI_asv_table_nonc_nopcr_2_nopoopnc[,selected_columns]
remaining_columns <- setdiff(colnames(COI_asv_table_nonc_nopcr_2_nopoopnc), selected_columns)
COI_asv_table_nonc_nopcr_2_nopoopnc_remaining <- COI_asv_table_nonc_nopcr_2_nopoopnc[, remaining_columns]

COI_asv_table_all_clean_nonc <- COI_asv_table_nonc_nopcr_2_nopoopnc_filter - nc_poop_total

COI_asv_table_all_clean<-cbind(COI_asv_table_clean_all_nonc, COI_asv_table_nonc_nopcr_2_nopoopnc_remaining)
# Replace negative values in COI_asv_table_nonc with 0
COI_asv_table_all_clean[COI_asv_table_all_clean < 0] <- 0
COI_asv_table_all_clean$asv_id<-row.names(COI_asv_table_all_clean)

write.csv(COI_asv_table_all_clean, file = "COI_asv_table_all_clean.csv", quote = FALSE, row.names = T)
write.xlsx(COI_asv_table_all_clean, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "COI_asv_table_all_clean.xlsx"))

#####################COI#################
rm(list = ls())
setwd("D:/pigeon/metabarcoding/pigeondata/analyist_COI")

#STEP 3-2 make Phyloseq objects for Metazoan data with OTU data(after subtracted NC), taxonomy data and metadata (sample-info)
COI_otu<-read.table("COI_asv_table_all_clean.txt", header=TRUE)
COI_otu<- as.data.frame(COI_otu)
row.names(COI_otu)<- COI_otu$asv_id
COI_otu<-COI_otu[,-1]
head(COI_otu)
COI_tax<-read.table("taxatable_COI_20240821.txt", sep='\t', header=TRUE)
row.names(COI_tax)<- COI_tax$asv_id
COI_tax<-COI_tax[,-1]
head(COI_tax)
COI_otu_table=as.matrix(COI_otu)
COI_taxonomy= as.matrix(COI_tax)
COI_metadata<-read.csv("metadata.csv", sep=';', header=TRUE)
row.names(COI_metadata)<- COI_metadata$PoopNr

COI_root_tree = read_tree("rooted_tree.nwk")


## create phyloseq object
COI_OTU = otu_table(COI_otu_table, taxa_are_rows=TRUE)
COI_TAX = tax_table(COI_taxonomy)
COI_META = sample_data(COI_metadata)

taxa_names(COI_TAX)
taxa_names(COI_OTU)
taxa_names(COI_root_tree)

sample_names(COI_OTU)
sample_names(COI_META)

COI_physeq = phyloseq(COI_OTU, COI_TAX, COI_META, COI_root_tree)
COI_physeq
rank_names(COI_physeq)
#otu_table()   OTU Table:         [ 1033 taxa and 63 samples ]
#sample_data() Sample Data:       [ 63 samples by 33 sample variables ]
#tax_table()   Taxonomy Table:    [ 1033 taxa by 11 taxonomic ranks ]
#phy_tree()    Phylogenetic Tree: [ 1033 tips and 1032 internal nodes ]

sum(sample_sums(COI_physeq)) # calculate total number of sequence reads and counts per sample
sample_sums(COI_physeq)    # number of read counts per sample
range(taxa_sums(COI_physeq))    # range of ASV abundance
range(sample_sums(COI_physeq))  # range of counts per sample
summary(sample_sums(COI_physeq))
sample_variables(COI_physeq)    # variables available
table(tax_table(COI_physeq)[,"phylum"], exclude=NULL)
table(tax_table(COI_physeq)[,"kingdom"], exclude=NULL)
table(tax_table(COI_physeq)[,"genus"], exclude=NULL)
## remove no identification
## remove ASVs with 0 reads
COI_physeq_clean <- subset_taxa(COI_physeq, kingdom != "no identification")
COI_physeq_clean_metazoa_noid<-subset_taxa(COI_physeq, kingdom == "no identification"| kingdom == "Metazoa")
sum(sample_sums(COI_physeq_clean_metazoa_noid))
sample_sums(COI_physeq_clean_metazoa_noid)
range(taxa_sums(COI_physeq_clean_metazoa_noid))
range(sample_sums(COI_physeq_clean_metazoa_noid))
summary(sample_sums(COI_physeq_clean_metazoa_noid))
table(tax_table(COI_physeq_clean_metazoa_noid)[,"phylum"], exclude=NULL)
table(tax_table(COI_physeq_clean_metazoa_noid)[,"kingdom"], exclude=NULL)

COI_physeq_clean <- prune_taxa(taxa_sums(COI_physeq_clean)>0, COI_physeq_clean)
# check removal
table(tax_table(COI_physeq_clean)[,"kingdom"], exclude=NULL)

# Check data again
COI_physeq_clean
#otu_table()   OTU Table:         [ 757 taxa and 63 samples ]
#sample_data() Sample Data:       [ 63 samples by 33 sample variables ]
#tax_table()   Taxonomy Table:    [ 757 taxa by 11 taxonomic ranks ]
#phy_tree()    Phylogenetic Tree: [ 757 tips and 756 internal nodes ]

sum(sample_sums(COI_physeq_clean))
sample_sums(COI_physeq_clean)
range(taxa_sums(COI_physeq_clean))
range(sample_sums(COI_physeq_clean))
summary(sample_sums(COI_physeq_clean))
table(tax_table(COI_physeq_clean)[,"phylum"], exclude=NULL)

# Make taxa and ASV table en write to file
COI_taxa_physeq_clean = as(tax_table(COI_physeq_clean), "matrix")
write.csv(COI_taxa_physeq_clean, file='COI_taxa_physeq_clean.csv')
COI_ASV_physeq_clean = as(otu_table(COI_physeq_clean), "matrix")
write.csv(COI_ASV_physeq_clean, file='COI_ASV_physeq_clean.csv')

#save phyloseq object
saveRDS(COI_physeq_clean, "COI_physeq_clean.rds")
# load phyloseq object
#physeq_loaded
COI_physeq_clean<- readRDS("COI_physeq_clean.rds")
# save phyloseq to biom file
#write_biom(COI_physeq_clean, "COI_physeq_clean.biom")




# remove singletons
COI_physeq_clean_min2 <-prune_taxa(taxa_sums(COI_physeq_clean)>1, COI_physeq_clean)
COI_physeq_clean_min2
#otu_table()   OTU Table:         [ 712 taxa and 63 samples ]
#sample_data() Sample Data:       [ 63 samples by 33 sample variables ]
#tax_table()   Taxonomy Table:    [ 712 taxa by 11 taxonomic ranks ]
#phy_tree()    Phylogenetic Tree: [ 712 tips and 711 internal nodes ]

sum(sample_sums(COI_physeq_clean_min2))
sample_sums(COI_physeq_clean_min2)
range(taxa_sums(COI_physeq_clean_min2))
range(sample_sums(COI_physeq_clean_min2))
summary(sample_sums(COI_physeq_clean_min2))
table(tax_table(COI_physeq_clean_min2)[,"phylum"], exclude=NULL)
table(tax_table(COI_physeq_clean_min2)[,"kingdom"], exclude=NULL)
table(tax_table(COI_physeq_clean_min2)[,"genus"], exclude=NULL)

## us include command ==. When subsetting Phyla using the exlude command (kingdom!=) all OTUs with "NA" in these taxa will be removed.
COI_physeq_clean_min2_Metazoa = subset_taxa(COI_physeq_clean_min2, kingdom=="Metazoa")
# remove taxa with zero counts
COI_physeq_clean_min2_Metazoa <-prune_taxa(taxa_sums(COI_physeq_clean_min2_Metazoa)>0, COI_physeq_clean_min2_Metazoa)
COI_physeq_clean_min2_Metazoa
#otu_table()   OTU Table:         [ 288 taxa and 63 samples ]
#sample_data() Sample Data:       [ 63 samples by 33 sample variables ]
#tax_table()   Taxonomy Table:    [ 288 taxa by 11 taxonomic ranks ]
#phy_tree()    Phylogenetic Tree: [ 288 tips and 287 internal nodes ]
#inspect general info of your data file
range(taxa_sums(COI_physeq_clean_min2_Metazoa)) # range of OTU abundance
range(sample_sums(COI_physeq_clean_min2_Metazoa)) # range of counts per sample
sample_variables(COI_physeq_clean_min2_Metazoa) #variables available
sample_sums(COI_physeq_clean_min2_Metazoa) #counts per sample
median(sample_sums(COI_physeq_clean_min2_Metazoa))
mean(sample_sums(COI_physeq_clean_min2_Metazoa))
sum(sample_sums(COI_physeq_clean_min2_Metazoa))
std <- function(x) sd(x)/sqrt(length(x))
std(sample_sums(COI_physeq_clean_min2_Metazoa))
summary(sample_sums(COI_physeq_clean_min2_Metazoa))
table(tax_table(COI_physeq_clean_min2_Metazoa)[,"phylum"], exclude=NULL)
table(tax_table(COI_physeq_clean_min2_Metazoa)[,"class"], exclude=NULL)
table(tax_table(COI_physeq_clean_min2_Metazoa)[,"order"], exclude=NULL)
table(tax_table(COI_physeq_clean_min2_Metazoa)[,"family"], exclude=NULL)
table(tax_table(COI_physeq_clean_min2_Metazoa)[,"genus"], exclude=NULL)
table(tax_table(COI_physeq_clean_min2_Metazoa)[,"species"], exclude=NULL)

COI_physeq_clean_min2_Metazoa_2<-COI_physeq_clean_min2_Metazoa
COI_physeq_clean_min2_Metazoa_2 = as(otu_table(COI_physeq_clean_min2_Metazoa_2), "matrix")
COI_physeq_clean_min2_Metazoa_taxa = tax_table(COI_physeq_clean_min2_Metazoa)
write.csv(COI_physeq_clean_min2_Metazoa_2, file='COI_physeq_clean_min2_Metazoa.csv')
write.xlsx(COI_physeq_clean_min2_Metazoa_taxa, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "COI_physeq_clean_min2_Metazoa_taxa.xlsx"),rowNames=TRUE)

################
######remove other plylum ("Chordata", "Nematoda","Platyhelminthes","Rotifera")
COI_physeq_clean_min2_Metazoa_remaining_phyla = subset_taxa(COI_physeq_clean_min2_Metazoa, !(phylum %in% c("Chordata", "Nematoda","Platyhelminthes","Rotifera")))
COI_physeq_clean_min2_Metazoa_Arthropoda = subset_taxa(COI_physeq_clean_min2_Metazoa, phylum=="Arthropoda")
COI_physeq_clean_min2_Metazoa_Annelida = subset_taxa(COI_physeq_clean_min2_Metazoa, phylum=="Annelida")

range(taxa_sums(COI_physeq_clean_min2_Metazoa_remaining_phyla)) # range of OTU abundance
range(sample_sums(COI_physeq_clean_min2_Metazoa_remaining_phyla)) # range of counts per sample
sample_variables(COI_physeq_clean_min2_Metazoa_remaining_phyla) #variables available
sample_sums(COI_physeq_clean_min2_Metazoa_remaining_phyla) #counts per sample
median(sample_sums(COI_physeq_clean_min2_Metazoa_remaining_phyla))
mean(sample_sums(COI_physeq_clean_min2_Metazoa_remaining_phyla))
sum(sample_sums(COI_physeq_clean_min2_Metazoa_remaining_phyla))
std <- function(x) sd(x)/sqrt(length(x))
std(sample_sums(COI_physeq_clean_min2_Metazoa_remaining_phyla))
summary(sample_sums(COI_physeq_clean_min2_Metazoa_remaining_phyla))
table(tax_table(COI_physeq_clean_min2_Metazoa_remaining_phyla)[,"phylum"], exclude=NULL)
table(tax_table(COI_physeq_clean_min2_Metazoa_remaining_phyla)[,"class"], exclude=NULL)
table(tax_table(COI_physeq_clean_min2_Metazoa_remaining_phyla)[,"order"], exclude=NULL)
table(tax_table(COI_physeq_clean_min2_Metazoa_remaining_phyla)[,"family"], exclude=NULL)
table(tax_table(COI_physeq_clean_min2_Metazoa_remaining_phyla)[,"genus"], exclude=NULL)
table(tax_table(COI_physeq_clean_min2_Metazoa_remaining_phyla)[,"species"], exclude=NULL)
COI_physeq_clean_min2_Metazoa_remaining_phyla <-prune_taxa(taxa_sums(COI_physeq_clean_min2_Metazoa_remaining_phyla)>0, COI_physeq_clean_min2_Metazoa_remaining_phyla)
COI_physeq_clean_min2_Metazoa_remaining_phyla
COI_physeq_clean_min2_Metazoa_remaining_phyla_2<-COI_physeq_clean_min2_Metazoa_remaining_phyla
COI_physeq_clean_min2_Metazoa_remaining_phyla_2 = as(otu_table(COI_physeq_clean_min2_Metazoa_remaining_phyla_2), "matrix")
COI_physeq_clean_min2_Metazoa_remaining_phyla_taxa = tax_table(COI_physeq_clean_min2_Metazoa_remaining_phyla)
write.csv(COI_physeq_clean_min2_Metazoa_remaining_phyla_2, file='COI_physeq_clean_min2_Metazoa_remaining_phyla.csv')
write.xlsx(COI_physeq_clean_min2_Metazoa_remaining_phyla_taxa, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "COI_physeq_clean_min2_Metazoa_remaining_phyla_taxa.xlsx"),rowNames=TRUE)

range(taxa_sums(COI_physeq_clean_min2_Metazoa_Arthropoda)) # range of OTU abundance
range(sample_sums(COI_physeq_clean_min2_Metazoa_Arthropoda)) # range of counts per sample
sample_variables(COI_physeq_clean_min2_Metazoa_Arthropoda) #variables available
sample_sums(COI_physeq_clean_min2_Metazoa_Arthropoda) #counts per sample
median(sample_sums(COI_physeq_clean_min2_Metazoa_Arthropoda))
mean(sample_sums(COI_physeq_clean_min2_Metazoa_Arthropoda))
sum(sample_sums(COI_physeq_clean_min2_Metazoa_Arthropoda))
std <- function(x) sd(x)/sqrt(length(x))
std(sample_sums(COI_physeq_clean_min2_Metazoa_Arthropoda))
summary(sample_sums(COI_physeq_clean_min2_Metazoa_Arthropoda))
table(tax_table(COI_physeq_clean_min2_Metazoa_Arthropoda)[,"phylum"], exclude=NULL)
table(tax_table(COI_physeq_clean_min2_Metazoa_Arthropoda)[,"class"], exclude=NULL)
table(tax_table(COI_physeq_clean_min2_Metazoa_Arthropoda)[,"order"], exclude=NULL)
table(tax_table(COI_physeq_clean_min2_Metazoa_Arthropoda)[,"family"], exclude=NULL)
table(tax_table(COI_physeq_clean_min2_Metazoa_Arthropoda)[,"genus"], exclude=NULL)
table(tax_table(COI_physeq_clean_min2_Metazoa_Arthropoda)[,"species"], exclude=NULL)
COI_physeq_clean_min2_Metazoa_Arthropoda <-prune_taxa(taxa_sums(COI_physeq_clean_min2_Metazoa_Arthropoda)>0, COI_physeq_clean_min2_Metazoa_Arthropoda)
COI_physeq_clean_min2_Metazoa_Arthropoda
COI_physeq_clean_min2_Metazoa_Arthropoda_2<-COI_physeq_clean_min2_Metazoa_Arthropoda
COI_physeq_clean_min2_Metazoa_Arthropoda_2 = as(otu_table(COI_physeq_clean_min2_Metazoa_Arthropoda_2), "matrix")
COI_physeq_clean_min2_Metazoa_Arthropoda_taxa = tax_table(COI_physeq_clean_min2_Metazoa_Arthropoda)
write.xlsx(COI_physeq_clean_min2_Metazoa_Arthropoda_taxa, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "COI_physeq_clean_min2_Metazoa_Arthropoda_taxa.xlsx"),rowNames=TRUE)
write.csv(COI_physeq_clean_min2_Metazoa_Arthropoda_2, file='COI_physeq_clean_min2_Metazoa_Arthropoda.csv')

############################
#Subset for Arthropoda (Insecta, Arachnida, Collembola class), Mollusca and Annelida
COI_physeq_clean_min2_Metazoa_AMA = subset_taxa(COI_physeq_clean_min2_Metazoa, phylum == "Arthropoda" | phylum == "Mollusca" | phylum == "Annelida")
COI_physeq_clean_min2_Metazoa_AMA = subset_taxa(COI_physeq_clean_min2_Metazoa_AMA, !(class %in% c("Hexanauplia")))
#Transform OTU counts to relative abundances
COI_physeq_clean_min2_Metazoa_AMA_rel <- transform_sample_counts(COI_physeq_clean_min2_Metazoa_AMA, function(x) x / sum(x))
# Melt the phyloseq object to get long-form data
physeq_melt_AMA <- psmelt(COI_physeq_clean_min2_Metazoa_AMA_rel)
physeq_melt_AMA_2 <-physeq_melt_AMA
physeq_melt_AMA_2 <- subset(physeq_melt_AMA_2, !is.na(Abundance))
write.csv(physeq_melt_AMA_2, file='physeq_melt_AMA.csv')
write.xlsx(physeq_melt_AMA_2, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "physeq_melt_AMA.xlsx"))

physeq_melt_AMA_readcount <- psmelt(COI_physeq_clean_min2_Metazoa_AMA)
write.csv(physeq_melt_AMA_readcount, file='physeq_melt_AMA_readcount.csv')
write.xlsx(physeq_melt_AMA_readcount, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "physeq_melt_AMA_readcount.xlsx"))


# Make taxa and ASV table en write to file
taxa_COI_physeq_clean_min2_Metazoa_AMA = as(tax_table(COI_physeq_clean_min2_Metazoa_AMA), "matrix")
write.csv(taxa_COI_physeq_clean_min2_Metazoa_AMA, file='taxa_COI_physeq_clean_min2_Metazoa_AMA.csv')
ASV_COI_physeq_clean_min2_Metazoa_AMA = as(otu_table(COI_physeq_clean_min2_Metazoa_AMA), "matrix")
write.csv(ASV_COI_physeq_clean_min2_Metazoa_AMA, file='ASV_COI_physeq_clean_min2_Metazoa_AMA.csv')
metadata_COI_physeq_clean_min2_Metazoa_AMA <- data.frame(sample_data(COI_physeq_clean_min2_Metazoa_AMA))
write.csv(metadata_COI_physeq_clean_min2_Metazoa_AMA, "metadata_COI_physeq_clean_min2_Metazoa_AMA.csv")
tree_COI_physeq_clean_min2_Metazoa_AMA <- write.tree(phy_tree(COI_physeq_clean_min2_Metazoa_AMA))
write(tree_COI_physeq_clean_min2_Metazoa_AMA, file = "tree_COI_physeq_clean_min2_Metazoa_AMA.newick")

#save phyloseq object
saveRDS(COI_physeq_clean_min2_Metazoa_AMA, "COI_physeq_clean_min2_Metazoa_AMA.rds")
# load phyloseq object
#physeq_loaded
COI_physeq_clean_min2_Metazoa_AMA<- readRDS("COI_physeq_clean_min2_Metazoa_AMA.rds")
# save phyloseq to biom file
#biom_COI_physeq_clean_min2_Metazoa_AMA<- phyloseq_to_biom(COI_physeq_clean_min2_Metazoa_AMA)
#write_biom(COI_physeq_clean_min2_Metazoa_AMA, "biom_COI_physeq_clean_min2_Metazoa_AMA.biom")

###########################################FOO%#############################################################
head(tax_table(COI_physeq_clean_min2_Metazoa_AMA))

COI_physeq_glom <- tax_glom(COI_physeq_clean_min2_Metazoa_AMA, taxrank = "family")
COI_physeq_glom_2 <-COI_physeq_glom
head(otu_table(COI_physeq_glom))
head(tax_table(COI_physeq_glom))
COI_physeq_glom_2 <- as(otu_table(COI_physeq_glom_2), "matrix")
write.csv(COI_physeq_glom_2, file='COI_physeq_glom_AMA_family.csv')

# Step 1:
otu_table_pa <- otu_table(COI_physeq_glom) > 0  # Presence/Absence table

# Step 2: Calculate the frequency of each MOTU in the sample (n = number of occurrences, t = total number of samples)
n <- rowSums(otu_table_pa)
t <- ncol(otu_table_pa)
foo_percent <- (n / t) * 100
foo_percent
foo_df <- data.frame(MOTU = rownames(otu_table_pa), FOO_Percent = foo_percent)
write.csv(foo_df, "FOO_percent_COI_AMA_glom_family.csv", row.names = FALSE)
write.xlsx(foo_df, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "FOO_percent_COI_AMA_glom_family.xlsx"))

taxa_info <- as.data.frame(tax_table(COI_physeq_glom))
foo_df$MOTU <- rownames(foo_df)
merged_df <- merge(foo_df, taxa_info, by.x = "MOTU", by.y = "row.names", all.x = TRUE)
head(merged_df)
rownames(merged_df)<-merged_df$MOTU
write.csv(merged_df, "FOO_taxa_COI_AMA_glom_family.csv", row.names = FALSE)
write.xlsx(merged_df, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "FOO_taxa_COI_AMA_glom_family.xlsx"))
#####################FOO% FOR DIFFERENT SEASON AND LOCATION########################
#####SUMMER
COI_summer_physeq <- subset_samples(COI_physeq_glom, Season == "SUMMER")
COI_winter_physeq <- subset_samples(COI_physeq_glom, Season == "WINTER")
COI_MOLUKKENPAD_physeq <- subset_samples(COI_physeq_glom, Location == "MOLUKKENPAD")
COI_NOORDERPLANTSOEN_physeq <- subset_samples(COI_physeq_glom, Location == "NOORDERPLANTSOEN")
COI_VISMARKT_physeq <- subset_samples(COI_physeq_glom, Location == "VISMARKT")

# Step 1:Presence/Absence table
otu_table_summer <- otu_table(COI_summer_physeq) > 0
otu_table_winter <- otu_table(COI_winter_physeq) > 0
otu_table_MOLUKKENPAD <- otu_table(COI_MOLUKKENPAD_physeq) > 0
otu_table_NOORDERPLANTSOEN <- otu_table(COI_NOORDERPLANTSOEN_physeq) > 0
otu_table_VISMARKT <- otu_table(COI_VISMARKT_physeq) > 0

# Step 2: Calculate the frequency of each MOTU in the sample (n = number of occurrences, t = total number of samples)
n_summer <- rowSums(otu_table_summer)
n_winter <- rowSums(otu_table_winter)
n_MOLUKKENPAD <- rowSums(otu_table_MOLUKKENPAD)
n_NOORDERPLANTSOEN <- rowSums(otu_table_NOORDERPLANTSOEN)
n_VISMARKT <- rowSums(otu_table_VISMARKT)

t_summer <- ncol(otu_table_summer)
t_winter <- ncol(otu_table_winter)
t_MOLUKKENPAD <- ncol(otu_table_MOLUKKENPAD)
t_NOORDERPLANTSOEN <- ncol(otu_table_NOORDERPLANTSOEN)
t_VISMARKT <- ncol(otu_table_VISMARKT)

foo_percent_summer <- (n_summer / t_summer) * 100
foo_percent_winter <- (n_winter / t_winter) * 100
foo_percent_MOLUKKENPAD <- (n_MOLUKKENPAD / t_MOLUKKENPAD) * 100
foo_percent_NOORDERPLANTSOEN <- (n_NOORDERPLANTSOEN / t_NOORDERPLANTSOEN) * 100
foo_percent_VISMARKT <- (n_VISMARKT / t_VISMARKT) * 100

foo_percent_summer
foo_percent_winter
foo_percent_MOLUKKENPAD
foo_percent_NOORDERPLANTSOEN
foo_percent_VISMARKT

foo_df_summer <- data.frame(MOTU = rownames(otu_table_summer), FOO_Percent = foo_percent_summer)
foo_df_winter <- data.frame(MOTU = rownames(otu_table_winter), FOO_Percent = foo_percent_winter)
foo_df_MOLUKKENPAD <- data.frame(MOTU = rownames(otu_table_MOLUKKENPAD), FOO_Percent = foo_percent_MOLUKKENPAD)
foo_df_NOORDERPLANTSOEN <- data.frame(MOTU = rownames(otu_table_NOORDERPLANTSOEN), FOO_Percent = foo_percent_NOORDERPLANTSOEN)
foo_df_VISMARKT <- data.frame(MOTU = rownames(otu_table_VISMARKT), FOO_Percent = foo_percent_VISMARKT)


write.csv(foo_df_summer, "FOO_percent_COI_AMA_summer_glom_family.csv", row.names = FALSE)
write.csv(foo_df_winter, "FOO_percent_COI_AMA_winter_glom_family.csv", row.names = FALSE)
write.csv(foo_df_MOLUKKENPAD, "FOO_percent_COI_AMA_MOLUKKENPAD_glom_family.csv", row.names = FALSE)
write.csv(foo_df_NOORDERPLANTSOEN, "FOO_percent_COI_AMA_NOORDERPLANTSOEN_glom_family.csv", row.names = FALSE)
write.csv(foo_df_VISMARKT, "FOO_percent_COI_AMA_VISMARKT_glom_family.csv", row.names = FALSE)


write.xlsx(foo_df_summer, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "FOO_percent_COI_AMA_summer_glom_family.xlsx"))
write.xlsx(foo_df_winter, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "FOO_percent_COI_AMA_winter_glom_family.xlsx"))
write.xlsx(foo_df_MOLUKKENPAD, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "FOO_percent_COI_AMA_MOLUKKENPAD_glom_family.xlsx"))
write.xlsx(foo_df_NOORDERPLANTSOEN, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "FOO_percent_COI_AMA_NOORDERPLANTSOEN_glom_family.xlsx"))
write.xlsx(foo_df_VISMARKT, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "FOO_percent_COI_AMA_VISMARKT_glom_family.xlsx"))

taxa_info_summer <- as.data.frame(tax_table(COI_summer_physeq))
taxa_info_winter <- as.data.frame(tax_table(COI_winter_physeq))
taxa_info_MOLUKKENPAD <- as.data.frame(tax_table(COI_MOLUKKENPAD_physeq))
taxa_info_NOORDERPLANTSOEN <- as.data.frame(tax_table(COI_NOORDERPLANTSOEN_physeq))
taxa_info_VISMARKT <- as.data.frame(tax_table(COI_VISMARKT_physeq))

foo_df_summer$MOTU <- rownames(foo_df_summer)
foo_df_winter$MOTU <- rownames(foo_df_winter)
foo_df_MOLUKKENPAD$MOTU <- rownames(foo_df_MOLUKKENPAD)
foo_df_NOORDERPLANTSOEN$MOTU <- rownames(foo_df_NOORDERPLANTSOEN)
foo_df_VISMARKT$MOTU <- rownames(foo_df_VISMARKT)

merged_df_summer <- merge(foo_df_summer, taxa_info_summer, by.x = "MOTU", by.y = "row.names", all.x = TRUE)
merged_df_winter <- merge(foo_df_winter, taxa_info_winter, by.x = "MOTU", by.y = "row.names", all.x = TRUE)
merged_df_MOLUKKENPAD <- merge(foo_df_MOLUKKENPAD, taxa_info_MOLUKKENPAD, by.x = "MOTU", by.y = "row.names", all.x = TRUE)
merged_df_NOORDERPLANTSOEN <- merge(foo_df_NOORDERPLANTSOEN, taxa_info_NOORDERPLANTSOEN, by.x = "MOTU", by.y = "row.names", all.x = TRUE)
merged_df_VISMARKT <- merge(foo_df_VISMARKT, taxa_info_VISMARKT, by.x = "MOTU", by.y = "row.names", all.x = TRUE)

rownames(merged_df_summer)<-merged_df_summer$MOTU
rownames(merged_df_winter)<-merged_df_winter$MOTU
rownames(merged_df_MOLUKKENPAD)<-merged_df_MOLUKKENPAD$MOTU
rownames(merged_df_NOORDERPLANTSOEN)<-merged_df_NOORDERPLANTSOEN$MOTU
rownames(merged_df_VISMARKT)<-merged_df_VISMARKT$MOTU

write.csv(merged_df_summer, "FOO_taxa_COI_AMA_summer_glom_family.csv", row.names = FALSE)
write.csv(merged_df_winter, "FOO_taxa_COI_AMA_winter_glom_family.csv", row.names = FALSE)
write.csv(merged_df_MOLUKKENPAD, "FOO_taxa_COI_AMA_MOLUKKENPAD_glom_family.csv", row.names = FALSE)
write.csv(merged_df_NOORDERPLANTSOEN, "FOO_taxa_COI_AMA_NOORDERPLANTSOEN_glom_family.csv", row.names = FALSE)
write.csv(merged_df_VISMARKT, "FOO_taxa_COI_AMA_VISMARKT_glom_family.csv", row.names = FALSE)

write.xlsx(merged_df_summer, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "FOO_taxa_COI_AMA_summer_glom_family.xlsx"))
write.xlsx(merged_df_winter, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "FOO_taxa_COI_AMA_winter_glom_family.xlsx"))
write.xlsx(merged_df_MOLUKKENPAD, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "FOO_taxa_COI_AMA_MOLUKKENPAD_glom_family.xlsx"))
write.xlsx(merged_df_NOORDERPLANTSOEN, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "FOO_taxa_COI_AMA_NOORDERPLANTSOEN_glom_family.xlsx"))
write.xlsx(merged_df_VISMARKT, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "FOO_taxa_COI_AMA_VISMARKT_glom_family.xlsx"))

merged_df_summer<-merged_df_summer[,-c(5:13)]
merged_df_winter<-merged_df_winter[,-c(5:13)]
merged_df_MOLUKKENPAD<-merged_df_MOLUKKENPAD[,-c(5:13)]
merged_df_NOORDERPLANTSOEN<-merged_df_NOORDERPLANTSOEN[,-c(5:13)]
merged_df_VISMARKT<-merged_df_VISMARKT[,-c(5:13)]

merged_df_summer$season <- "SUMMER"
merged_df_winter$season <- "WINTER"
merged_df_MOLUKKENPAD$location <- "MOLUKKENPAD"
merged_df_NOORDERPLANTSOEN$location <- "NOORDERPLANTSOEN"
merged_df_VISMARKT$location <- "VISMARKT"

merged_df_summer <- merge(merged_df_summer, taxa_COI_physeq_clean_min2_Metazoa_AMA, by.x = "MOTU", by.y = "row.names", all.x = TRUE)
merged_df_winter <- merge(merged_df_winter, taxa_COI_physeq_clean_min2_Metazoa_AMA, by.x = "MOTU", by.y = "row.names", all.x = TRUE)
merged_df_MOLUKKENPAD <- merge(merged_df_MOLUKKENPAD, taxa_COI_physeq_clean_min2_Metazoa_AMA, by.x = "MOTU", by.y = "row.names", all.x = TRUE)
merged_df_NOORDERPLANTSOEN <- merge(merged_df_NOORDERPLANTSOEN, taxa_COI_physeq_clean_min2_Metazoa_AMA, by.x = "MOTU", by.y = "row.names", all.x = TRUE)
merged_df_VISMARKT <- merge(merged_df_VISMARKT, taxa_COI_physeq_clean_min2_Metazoa_AMA, by.x = "MOTU", by.y = "row.names", all.x = TRUE)

merged_df_season <- rbind(merged_df_summer, merged_df_winter)
merged_df_location <- rbind(merged_df_MOLUKKENPAD, merged_df_NOORDERPLANTSOEN,merged_df_VISMARKT)

write.csv(merged_df_season, "FOO_merged_df_season.csv", row.names = FALSE)
write.csv(merged_df_location, "FOO_merged_df_location.csv", row.names = FALSE)
write.xlsx(merged_df_season, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "FOO_merged_df_season.xlsx"))
write.xlsx(merged_df_location, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_COI", "FOO_merged_df_location.xlsx"))

###################FOO Analysis################################
FOO_Season <-read.csv("FOO_merged_df_season.csv",header=TRUE, sep=";",row.names=1)
FOO_Location <-read.csv("FOO_merged_df_location.csv",header=TRUE, sep=";", row.names=1)

FOO_Season <-merged_df_season
FOO_Location <-merged_df_location

str(FOO_Season)
str(FOO_Location)
FOO_Season$FOO_Percent <- as.numeric(gsub(",", ".", FOO_Season$FOO_Percent))
FOO_Location$FOO_Percent <- as.numeric(gsub(",", ".", FOO_Location$FOO_Percent))
FOO_Season$season <- as.factor(FOO_Season$season)
FOO_Location$location <- as.factor(FOO_Location$location)
FOO_Season$family <- as.factor(FOO_Season$family)

FOO_Season %>% count(MOTU)
FOO_Season %>%
  group_by(MOTU, season) %>%
  summarise(cnt = n()) %>%
  arrange(desc(cnt))%>%
  print(n=Inf)
#####################Make a bar plot
# Show the difference between FOO_Percent of MOTU in summer and winter in different families
FOO_Season_filtered <- FOO_Season %>%
  group_by(MOTU, family) %>%
  filter(any(FOO_Percent >= 33)) %>%
  filter(lca_taxon.x != "Arthropoda") %>%
  ungroup()

FOO_Season_Alaus_melanops <-filter(FOO_Season, lca_taxon.x=='Alaus melanops')
chisq.test(FOO_Season_Alaus_melanops$FOO_Percent)
##X-squared = 17.778, df = 1, p-value = 2.483e-05
FOO_Season_Glyptotendipes_pallens <-filter(FOO_Season, lca_taxon.x=='Glyptotendipes pallens')
chisq.test(FOO_Season_Glyptotendipes_pallens$FOO_Percent)
##X-squared = 4.4563, df = 1, p-value = 0.03477
FOO_Season_Hemiptera <-filter(FOO_Season, lca_taxon.x=='Hemiptera')
chisq.test(FOO_Season_Hemiptera$FOO_Percent)
##X-squared = 0.74074, df = 1, p-value = 0.3894

p<-ggplot(FOO_Season_filtered, aes(x = lca_taxon.x, y = FOO_Percent, fill = season)) +
  geom_bar(stat = "identity", position = "dodge") +
  facet_wrap(~ order, scales = "free_x") +
  labs(title = "",
       x = "MOTU",
       y = "FOO Presence (%)",
       fill = "Season") +
  scale_y_continuous(limits = c(0, 100)) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 8),
    axis.text.y = element_text(size = 10),
    strip.text = element_text(size = 12),
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.title.position = "plot",
    panel.grid = element_blank(),
    panel.background = element_rect(color = 'black', fill = 'transparent')
  )
p
##############locations###########
# Filter out FOO_Percent > 33 for different locations and remove the data for 'Others'
FOO_Location_filtered <- FOO_Location %>%
  group_by(MOTU, family) %>%
  filter(any(FOO_Percent >= 33)) %>%
  filter(lca_taxon.x != "Arthropoda") %>%
  ungroup()

# Show the difference in FOO_Presence of MOTU in different locations in different families
ggplot(FOO_Location_filtered, aes(x = lca_taxon.x, y = FOO_Percent, fill = location)) +
  geom_bar(stat = "identity", position = "dodge") +
  facet_wrap(~ order, scales = "free_x") +
  labs(title = "",
       x = "MOTU",
       y = "FOO Presence (%)",
       fill = "Season") +
  scale_y_continuous(limits = c(0, 100)) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1, size = 8),
    axis.text.y = element_text(size = 10),
    strip.text = element_text(size = 12),
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    plot.title.position = "plot",
    panel.grid = element_blank(),
    panel.background = element_rect(color = 'black', fill = 'transparent')
  )
set.seed(123)
FOO_Location_Coleoptera <-filter(FOO_Location, lca_taxon.x=='Coleoptera')
kruskal.test(FOO_Percent ~ location,FOO_Location_Coleoptera)
dunn.test(FOO_Location_Coleoptera$FOO_Percent, FOO_Location_Coleoptera$location, method = "bonferroni")
#Kruskal-Wallis chi-squared = 2, df = 2, p-value = 0.37
FOO_Location_Tanymecus_palliatus <-filter(FOO_Location, lca_taxon.x=='Tanymecus palliatus')
kruskal.test(FOO_Percent ~ location,FOO_Location_Tanymecus_palliatus)
#Kruskal-Wallis chi-squared = 2, df = 2, p-value = 0.3679
FOO_Location_Glyptotendipes_pallens <-filter(FOO_Location, lca_taxon.x=='Glyptotendipes pallens')
kruskal.test(FOO_Percent ~ location,FOO_Location_Glyptotendipes_pallens)
dunn.test(FOO_Location_Glyptotendipes_pallens$FOO_Percent, FOO_Location_Glyptotendipes_pallens$location, method = "bonferroni")
#Kruskal-Wallis chi-squared = 2, df = 2, p-value = 0.3679
FOO_Location_Hemiptera <-filter(FOO_Location, lca_taxon.x=='Hemiptera')
kruskal.test(FOO_Percent ~ location,FOO_Location_Hemiptera)
dunn.test(FOO_Location_Hemiptera$FOO_Percent, FOO_Location_Hemiptera$location, method = "bonferroni")
#Kruskal-Wallis chi-squared = 2, df = 2, p-value = 0.3679

