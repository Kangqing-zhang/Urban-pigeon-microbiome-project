---
  title: "Seasonal dynamics of the gut microbiome in urban feral pigeons are associated with environmental conditions, not with diet shifts"
author: "Kangqing Zhang"
date: "October 09, 2025"
---

  #####################################################################################
# DNA metabarcoding successfully quantifies relative abundances of food taxa in pigeon's diets
##For Plant(its2)_primer
#R 4.4.0
#getting started with a session
#if required, clear workspace
rm(list = ls())
setwd("D:/pigeon/metabarcoding/pigeondata/analyist_Plant")
getwd()

#if (!require("BiocManager", quietly = TRUE))
  #install.packages("BiocManager")
#BiocManager::install("Rqc")

library(phyloseq)
library(Rqc)
library(data.table)
library(vegan)
library(plyr)
library(tidyr)
library(reshape2)
library(dplyr)
library(RColorBrewer)
library(colorRamps)
library(colorspace)
library("gridExtra")
library(openxlsx)
packageVersion('phyloseq')
library("ggplot2"); packageVersion("ggplot2")
library(ape)
library(microbiome)
library(decontam)
library(vsn)
library(ape)
library(venn)
library(directlabels)
library(doBy)
library(Rmisc)
library(lme4)
library(nlme)
library(nortest)
library(data.table)
library(cluster)
library(rockchalk)
library(blmeco)
library(glmmTMB)
library(bbmle)
library(MuMIn)
library(rcompanion)
library(qqplotr)
library(car)
library(btools)
library(multcomp)
library(multcompView)
library(cowplot)
library(devtools)
library(pairwiseAdonis) # for posthoc ADONIS analysis
library(emmeans)
library(sjPlot) #for plotting lmer and glmer mods
library(sjmisc)
library(effects)
library(sjstats) #use for r2 functions
library(ggeffects)
library(ade4) # v 1.7-16
library(ICC)
library(pheatmap)
library(dunn.test)
library(ggsignif)
library(coin)
library(wesanderson)
library(ggpubr)
theme_set(theme_bw())

colslocal <- c("darkseagreen", "darkgreen","saddlebrown")
colsSeason <- c("#DA5724","#508578")



cols2 <- c( "#CC79A7", "#F0E442", "#009E73", "#D55E00", "#E69F00",
            "#7570B3", "#56B4E9", "#CC6666", "#0072B2", "#66CC99",
            "#A6761D", "#A65628", "#7570B3", "#66A61E", "#F781BF",
            "#E6AB02", "#08519C", "#A6761D", "#377EB8", "#4DAF4A",
            "#984EA3", "#238443", "#FFFF33", "#A65628", "#F781BF",
            "#66A61E", "#1B9E77", "#D95F02" ,"#999999", "#E7298A",
            "#999999", "#E69F00", "#009E73", "#56B4E9", "#F0E442",
            "#CC79A7", "#999999", "#E69F00", "#009E73", "#56B4E9",
            "#CC79A7", "#D55E00", "#0072B2", "#CC6666", "#66CC99",
            "#A6761D", "#7570B3", "#A65628", "#F781BF", "#66A61E",
            "#E6AB02", "#08519C", "#A6761D", "#377EB8", "#4DAF4A",
            "#984EA3", "#238443", "#FFFF33", "#A65628", "#F781BF",
            "#66A61E", "#1B9E77", "#D95F02" ,"#7570B3", "#E7298A",
            "#999999", "#E69F00", "#009E73", "#56B4E9", "#F0E442",
            "#CC79A7")

cols <- c("#1B9E77", "#D95F02" ,"#7570B3", "#E7298A", "#66A61E",
          "#E6AB02", "#A6761D", "#08519C", "#377EB8", "#4DAF4A",
          "#984EA3", "#238443", "#FFFF33", "#A65628", "#F781BF")
colsSeason <- c("WINTER" = "#0072B2", "SUMMER" = "#E69F00")
allGroupsColors<- c(
  "orange", "grey50", "purple", "deepskyblue",
  "red", "darkred", "grey0", "green4")
cbbPalette <- c("#E69F00", "#56B4E9")
cbbPalette_1 <- c("#009E73", "#F0E442")

Sex_labels <- c("F" = "females",
                "M" = "males")
Local_labels<-c("Molukkenpad","Noorderplantsoen","Vismarkt" )

#######################################Plant(its2)_primer################################################################
#STEP 2-1
#PREPRstep > substract negative controls from OTU file#########
## NC_kits
rm(list = ls())
#set working directory and check
setwd("D:/pigeon/metabarcoding/pigeondata/analyist_Plant")
getwd()

its2_ASV_Table<- read.table("its2_ASV_Table.txt", header=T, sep="\t")
its2_ASV_Table<- as.data.frame(its2_ASV_Table)
#make OTUs rownames
row.names(its2_ASV_Table)<- its2_ASV_Table$asv_id
its2_ASV_Table_2<-its2_ASV_Table
its2_ASV_Table_2<-its2_ASV_Table_2[,-1]
NC_Kits<- read.table("NC_Kits.txt", header=T, sep="\t")
NC_Kits<- as.data.frame(NC_Kits)
#make rownames
row.names(NC_Kits)<- NC_Kits$X
names(NC_Kits)

NCkit1<- NC_Kits[,2]
NCkit1<- as.data.frame(NCkit1)
row.names(NCkit1)<- NC_Kits$X

NCkit2<- NC_Kits[,3]
NCkit2<- as.data.frame(NCkit2)
row.names(NCkit2)<- NC_Kits$X

neg_controls_kits<- read.table("neg_controls_kits.txt", header=T, sep="\t")

##
nc_kit1_samples <- neg_controls_kits$sample[neg_controls_kits$negcontrol == "nc_kit1"]
# Use match() to find the corresponding indices in its2_ASV_Table_2
nc_kit1_indices <- match(nc_kit1_samples, colnames(its2_ASV_Table_2))

nc_kit2_samples <- neg_controls_kits$sample[neg_controls_kits$negcontrol == "nc_kit2"]
# Use match() to find the corresponding indices in its2_ASV_Table_2
nc_kit2_indices <- match(nc_kit2_samples, colnames(its2_ASV_Table_2))

nc_kit1_matrix <- matrix(rep(NCkit1, each = length(nc_kit1_indices)), byrow = TRUE, ncol = length(nc_kit1_indices))
nc_kit2_matrix<- matrix(rep(NCkit2, each = length(nc_kit2_indices)), byrow = TRUE, ncol = length(nc_kit2_indices))
nc_kit_total<- cbind(nc_kit1_matrix, nc_kit2_matrix)

its2_asv_table_nonc <- its2_ASV_Table_2 - nc_kit_total
row.names(its2_asv_table_nonc)<- row.names(its2_ASV_Table)
its2_asv_table_nonc$asv_id<-row.names(its2_asv_table_nonc)
### Export
write.csv(its2_asv_table_nonc, file = "its2_asv_table_nokitsnc_20240827.csv", quote = FALSE, row.names = T)
write.xlsx(its2_asv_table_nonc, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "its2_asv_table_nokitsnc_20240827.xlsx"))

# Replace negative values in its2_asv_table_nonc with 0
its2_asv_table_nonc[its2_asv_table_nonc < 0] <- 0

write.csv(its2_asv_table_nonc, file = "its2_asv_table_nokitsnc_20240827_noneg.csv", quote = FALSE, row.names = T)
write.xlsx(its2_asv_table_nonc, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "its2_asv_table_nokitsnc_20240827_noneg.xlsx"))

##################################################################################################
#STEP 1-2
otu<-read.table("its2_asv_table_nokitsnc_20240827_noneg.txt", header=TRUE)
head(otu)
tax<-read.table("taxatable_its2_20240821.txt", sep='\t', header=TRUE)
head(tax)
## merge otu and tax file
merged_file<-merge(otu, tax, by.x=c("asv_id"), by.y=c("asv_id"))
head(merged_file)
write.table(merged_file, file="combined_otu_tax.txt", sep='\t', col.names=TRUE, row.names=FALSE)

#STEP 1-4
#Compered with repeated its2 samples(Plant004013 and FP.GR18095,Plant007038 and FP.GR18069,Plant006076 and M4, FP.GR18246 and KQZ2468_2)
#####
repected_its2_samples_013 <- merged_file[, c("asv_id","Plant004013", "FP.GR18095", "lca_rank", "lca_taxon", "method","reference_db", "kingdom", "phylum", "class", "order", "family", "genus", "species")]
repected_its2_samples_038 <- merged_file[, c("asv_id","Plant007038", "FP.GR18069", "lca_rank", "lca_taxon", "method","reference_db", "kingdom", "phylum", "class", "order", "family", "genus", "species")]
repected_its2_samples_076 <- merged_file[, c("asv_id","Plant006076", "M4", "lca_rank", "lca_taxon", "method","reference_db", "kingdom", "phylum", "class", "order", "family", "genus", "species")]
repected_its2_samples_068 <- merged_file[, c("asv_id","FP.GR18246", "KQZ2468_2", "lca_rank", "lca_taxon", "method","reference_db", "kingdom", "phylum", "class", "order", "family", "genus", "species")]

repected_its2_samples_013_asv_table <- merged_file[, c("Plant004013", "FP.GR18095")]
repected_its2_samples_038_asv_table <- merged_file[, c("Plant007038", "FP.GR18069")]
repected_its2_samples_076_asv_table <- merged_file[, c("Plant006076", "M4")]
repected_its2_samples_068_asv_table <- merged_file[, c("FP.GR18246", "KQZ2468_2")]

repected_its2_samples_013_asv_table<- as.data.frame(repected_its2_samples_013_asv_table)
repected_its2_samples_038_asv_table<- as.data.frame(repected_its2_samples_038_asv_table)
repected_its2_samples_076_asv_table<- as.data.frame(repected_its2_samples_076_asv_table)
repected_its2_samples_068_asv_table<- as.data.frame(repected_its2_samples_068_asv_table)

row.names(repected_its2_samples_013_asv_table)<- repected_its2_samples_013$asv_id
row.names(repected_its2_samples_038_asv_table)<- repected_its2_samples_038$asv_id
row.names(repected_its2_samples_076_asv_table)<- repected_its2_samples_076$asv_id
row.names(repected_its2_samples_068_asv_table)<- repected_its2_samples_068$asv_id

###presence and absence
presence_absence_013 <- (repected_its2_samples_013_asv_table > 0) * 1
presence_absence_diff_013 <- presence_absence_013[, "Plant004013"] - presence_absence_013[, "FP.GR18095"]
#In the results, 1 means that ASV is present only in Plant004013, -1 means it is present only in FP.GR18095, and 0 means it is present in both samples
presence_absence_diff_013
presence_absence_matrix_013 <- as.matrix(presence_absence_diff_013)
rownames(presence_absence_matrix_013) <- names(presence_absence_diff_013)
colnames(presence_absence_matrix_013) <- "Presence_Absence_Diff"

count_1 <- sum(presence_absence_matrix_013[, 1] == 1)
count_minus1 <- sum(presence_absence_matrix_013[, 1] == -1)
count_0 <- sum(presence_absence_matrix_013[, 1] == 0)

cat("Number of ASVs with 1 (present in Plant004013 only):", count_1, "\n")
cat("Number of ASVs with -1 (present in FP.GR18095 only):", count_minus1, "\n")
cat("Number of ASVs with 0 (present in both samples):", count_0, "\n")
#Number of ASVs with 1 (present in Plant004013 only): 94
#Number of ASVs with -1 (present in FP.GR18095 only): 12
#Number of ASVs with 0 (present in both samples): 3072
#(94-12)/3178=0.026 (2.6%)
write.table(presence_absence_matrix_013, file = "presence_absence_matrix_013.txt", sep = "\t", row.names = TRUE, col.names = TRUE, quote = FALSE)

###Plant007038 and FP.GR18069
presence_absence_038 <- (repected_its2_samples_038_asv_table > 0) * 1
presence_absence_diff_038 <- presence_absence_038[, "Plant007038"] - presence_absence_038[, "FP.GR18069"]
#In the results, 1 means that ASV is present only in Plant007038, -1 means it is present only in FP.GR18069, and 0 means it is present in both samples
presence_absence_diff_038
presence_absence_matrix_038 <- as.matrix(presence_absence_diff_038)
rownames(presence_absence_matrix_038) <- names(presence_absence_diff_038)
colnames(presence_absence_matrix_038) <- "Presence_Absence_Diff"

count_1 <- sum(presence_absence_matrix_038[, 1] == 1)
count_minus1 <- sum(presence_absence_matrix_038[, 1] == -1)
count_0 <- sum(presence_absence_matrix_038[, 1] == 0)

cat("Number of ASVs with 1 (present in Plant007038 only):", count_1, "\n")
cat("Number of ASVs with -1 (present in FP.GR18069 only):", count_minus1, "\n")
cat("Number of ASVs with 0 (present in both samples):", count_0, "\n")
#Number of ASVs with 1 (present in Plant007038 only): 121
#Number of ASVs with -1 (present in FP.GR18069 only): 49
#Number of ASVs with 0 (present in both samples): 3008
#(121-49)/3178=0.022 (2.2%)
write.table(presence_absence_matrix_038, file = "presence_absence_matrix_038.txt", sep = "\t", row.names = TRUE, col.names = TRUE, quote = FALSE)

###Plant006076 and M4
presence_absence_076 <- (repected_its2_samples_076_asv_table > 0) * 1
presence_absence_diff_076 <- presence_absence_076[, "Plant006076"] - presence_absence_076[, "M4"]
#In the results, 1 means that ASV is present only in Plant006076, -1 means it is present only in M4, and 0 means it is present in both samples
presence_absence_diff_076
presence_absence_matrix_076 <- as.matrix(presence_absence_diff_076)
rownames(presence_absence_matrix_076) <- names(presence_absence_diff_076)
colnames(presence_absence_matrix_076) <- "Presence_Absence_Diff"

count_1 <- sum(presence_absence_matrix_076[, 1] == 1)
count_minus1 <- sum(presence_absence_matrix_076[, 1] == -1)
count_0 <- sum(presence_absence_matrix_076[, 1] == 0)

cat("Number of ASVs with 1 (present in Plant006076 only):", count_1, "\n")
cat("Number of ASVs with -1 (present in M4 only):", count_minus1, "\n")
cat("Number of ASVs with 0 (present in both samples):", count_0, "\n")
#Number of ASVs with 1 (present in Plant006076 only): 97
#Number of ASVs with -1 (present in M4 only): 29
#Number of ASVs with 0 (present in both samples): 3052
#(97-29)/3178=0.021 (2.1%)
write.table(presence_absence_matrix_076, file = "presence_absence_matrix_076.txt", sep = "\t", row.names = TRUE, col.names = TRUE, quote = FALSE)

###FP.GR18246 and KQZ2468_2
presence_absence_068 <- (repected_its2_samples_068_asv_table > 0) * 1
presence_absence_diff_068 <- presence_absence_068[, "FP.GR18246"] - presence_absence_068[, "KQZ2468_2"]
#In the results, 1 means that ASV is present only in FP.GR18246, -1 means it is present only in KQZ2468_2, and 0 means it is present in both samples
presence_absence_diff_068
presence_absence_matrix_068 <- as.matrix(presence_absence_diff_068)
rownames(presence_absence_matrix_068) <- names(presence_absence_diff_068)
colnames(presence_absence_matrix_068) <- "Presence_Absence_Diff"

count_1 <- sum(presence_absence_matrix_068[, 1] == 1)
count_minus1 <- sum(presence_absence_matrix_068[, 1] == -1)
count_0 <- sum(presence_absence_matrix_068[, 1] == 0)

cat("Number of ASVs with 1 (present in FP.GR18246 only):", count_1, "\n")
cat("Number of ASVs with -1 (present in KQZ2468_2 only):", count_minus1, "\n")
cat("Number of ASVs with 0 (present in both samples):", count_0, "\n")
#Number of ASVs with 1 (present in FP.GR18246 only): 77
#Number of ASVs with -1 (present in KQZ2468_2 only): 146
#Number of ASVs with 0 (present in both samples): 2955
#(146-77)/3178=0.021 (2.1%)
write.table(presence_absence_matrix_068, file = "presence_absence_matrix_068.txt", sep = "\t", row.names = TRUE, col.names = TRUE, quote = FALSE)

##########Abundance Compered######################
#The difference in abundance between the two samples was calculated
asv_abundance_diff_013 <- repected_its2_samples_013_asv_table[, "Plant004013"] - repected_its2_samples_013_asv_table[, "FP.GR18095"]
asv_abundance_diff_013
asv_abundance_diff_013 <- as.matrix(asv_abundance_diff_013)
rownames(asv_abundance_diff_013) <- repected_its2_samples_013$asv_id
colnames(asv_abundance_diff_013) <- "Asv_Abundance_Diff"
summary(asv_abundance_diff_013)
significant_asv_abundance_diff_013_df <- asv_abundance_diff_013[abs(asv_abundance_diff_013[, 1]) > 100, ]
significant_asv_abundance_diff_013_df
#Zotu17(112) Zotu2(1838) Zotu308(104) Zotu40(180) Zotu52(129) Zotu80(119)
# 6 asvs have over 100 different reads between Plant004013 and FP.GR18095, but they are all detected in both samples

###Plant007038 and FP.GR18069
asv_abundance_diff_038 <- repected_its2_samples_038_asv_table[, "Plant007038"] - repected_its2_samples_038_asv_table[, "FP.GR18069"]
asv_abundance_diff_038
asv_abundance_diff_038 <- as.matrix(asv_abundance_diff_038)
rownames(asv_abundance_diff_038) <- repected_its2_samples_038$asv_id
colnames(asv_abundance_diff_038) <- "Asv_Abundance_Diff"
summary(asv_abundance_diff_038)
significant_asv_abundance_diff_038_df <- asv_abundance_diff_038[abs(asv_abundance_diff_038[, 1]) > 100, ]
significant_asv_abundance_diff_038_df
#Zotu1(850) Zotu140(105)  Zotu165(132) Zotu2(554)  Zotu20(105) Zotu37(406)  Zotu45(112) Zotu8(122)
# 8 asvs have over 100 different reads between Plant007038 and FP.GR18069

###Plant006076 and M4
asv_abundance_diff_076 <- repected_its2_samples_076_asv_table[, "Plant006076"] - repected_its2_samples_076_asv_table[, "M4"]
asv_abundance_diff_076
asv_abundance_diff_076 <- as.matrix(asv_abundance_diff_076)
rownames(asv_abundance_diff_076) <- repected_its2_samples_076$asv_id
colnames(asv_abundance_diff_076) <- "Asv_Abundance_Diff"
summary(asv_abundance_diff_076)
significant_asv_abundance_diff_076_df <- asv_abundance_diff_076[abs(asv_abundance_diff_076[, 1]) > 100, ]
significant_asv_abundance_diff_076_df
# Zotu3(-1013) Zotu4(-1165)
#2 asvs have over 100 different reads between Plant006076 and M4
##There are not much different between Plant004013 and FP.GR18095,Plant007038 and FP.GR18069,Plant006076 and M4

###FP.GR18246 and KQZ2468_2
asv_abundance_diff_068 <- repected_its2_samples_068_asv_table[, "FP.GR18246"] - repected_its2_samples_068_asv_table[, "KQZ2468_2"]
asv_abundance_diff_068
asv_abundance_diff_068 <- as.matrix(asv_abundance_diff_068)
rownames(asv_abundance_diff_068) <- repected_its2_samples_068$asv_id
colnames(asv_abundance_diff_068) <- "Asv_Abundance_Diff"
summary(asv_abundance_diff_068)
significant_asv_abundance_diff_068_df <- asv_abundance_diff_068[abs(asv_abundance_diff_068[, 1]) > 100, ]
significant_asv_abundance_diff_068_df
#Zotu1(-205) Zotu13(-106) Zotu165(-111) Zotu17(283) Zotu2(-610) Zotu29(103)
# 6 asvs have over 100 different reads between FP.GR18246 and KQZ2468_2
# There are not too much different between FP.GR18246 and KQZ2468_2

#mock samples
its2_mock_samples_asv_table <- merged_file[, c("asv_id", "M1", "M2", "M3", "M4", "M5", "M6", "M7", "M8", "M9", "M10", "M11", "M12","lca_rank", "lca_taxon", "method","reference_db", "kingdom", "phylum", "class", "order", "family", "genus", "species")]
rownames(its2_mock_samples_asv_table) <- its2_mock_samples_asv_table$asv_id
its2_mock_samples_asv_table_plant<-filter(its2_mock_samples_asv_table,kingdom=="Viridiplantae")
write.table(its2_mock_samples_asv_table_plant, file = "its2_mock_samples_asv_table_plant.txt", sep = "\t", row.names = TRUE, col.names = TRUE, quote = FALSE)

its2_mock_samples_asv_table_df <- its2_mock_samples_asv_table[apply(its2_mock_samples_asv_table[,2:13],1,function(x) any(x>100)), ]
its2_mock_samples_asv_table_df
write.table(its2_mock_samples_asv_table, file = "its2_mock_samples_asv_table.txt", sep = "\t", row.names = TRUE, col.names = TRUE, quote = FALSE)
write.table(its2_mock_samples_asv_table_df, file = "its2_mock_samples_asv_table_df.txt", sep = "\t", row.names = TRUE, col.names = TRUE, quote = FALSE)
#M1:M5 have Pisum genus (Zotu3, zotu4),M6 have Pisum genus and Solanum tuberosum,M7:M12 have Taraxacum in there(Zotu9).
#In M1:M3 and M10:M12 have really little wheat taxa,because of the bread is the high temperature heating food.
#In M10:M12 have Pisum abyssinicum, its shouldn't be in these samples, one of the possible reason is contamination.

#The abundant of four taxa in mock samples (compare the expect value and real value)
mock_samples_data<- read.table("mock_samples_data.txt", header=T, sep="\t")
mock_samples_data$Abundant <- as.numeric(gsub(",", ".", mock_samples_data$Abundant))

#colsMock <- c("Fabaceae" = "darkolivegreen1", "Solanaceae" = "#E69F00","Taraxacum" = "#FFFF33","Triticum" = "khaki2")
Mock_compare<-ggbarplot(mock_samples_data, x = "Samples", y="Abundant", color="black", fill="Taxa",
                             legend="middle",
                             legend.title="Taxa", main="",
                             font.main = c(14,"bold", "black"), font.x = c(14, "bold"),
                             font.y=c(14,"bold")) +
  theme_bw() +
  rotate_x_text() +
  #scale_fill_manual(values=c("Fabaceae" = "#599861", "Solanaceae" = "darkorange1","Taraxacum" = "#FFFF33","Triticum" = "khaki2"))+
  scale_fill_brewer(palette="Set3")+
  facet_grid(Group~Samples, scales = "free_x", space='free') +
  labs(x = "Samples", y = "Relative abundance") +
  theme(axis.text.x=element_blank(),
        axis.ticks.x=element_blank(),
        axis.title = element_text(face = "bold"),
        plot.title = element_text(face = "bold"),
        legend.title = element_text(face = "bold"))
Mock_compare
ggsave(filename = "Mock_compare_EX_RE.pdf", device="pdf", width=8, height=6)

##remove mock samples(M1:M12),multiply plant samples(Plant004013,Plant006076,Plant007038 and KQZ2468_2)
colnames(its2_asv_table_nonc)
cols_to_remove <- grep("^(M|Plant|KQZ)", colnames(its2_asv_table_nonc), value = TRUE)
its2_asv_table_nonc_only_poopNC<-its2_asv_table_nonc[, !colnames(its2_asv_table_nonc) %in% cols_to_remove]
colnames(its2_asv_table_nonc_only_poopNC)
write.table(its2_asv_table_nonc_only_poopNC, file = "its2_asv_table_nonc_only_poopNC.txt", sep = "\t", row.names = TRUE, col.names = TRUE, quote = FALSE)

## NC for poop samples
nc_poop_all<-its2_asv_table_nonc_only_poopNC[, c("asv_id","FP.GR18067","FP.GR18053","FP.GR18071","FP.GR18080","FP.GR18064","FP.GR18275","FP.GR18097","FP.GR18252")]
nc_poop_all<- as.data.frame(nc_poop_all)
rownames(nc_poop_all) <- nc_poop_all$asv_id

nc_poop_0408<- nc_poop_all[,2]
nc_poop_0408<- as.data.frame(nc_poop_0408)
row.names(nc_poop_0408)<- nc_poop_0408$X

nc_poop_0707<- nc_poop_all[,3]
nc_poop_0707<- as.data.frame(nc_poop_0707)
row.names(nc_poop_0707)<- nc_poop_0707$X

nc_poop_1702<- nc_poop_all[,4]
nc_poop_1702<- as.data.frame(nc_poop_1702)
row.names(nc_poop_1702)<- nc_poop_1702$X

nc_poop_2702<- nc_poop_all[,5]
nc_poop_2702<- as.data.frame(nc_poop_2702)
row.names(nc_poop_2702)<- nc_poop_2702$X

nc_poop_1102<- nc_poop_all[,6]
nc_poop_1102<- as.data.frame(nc_poop_1102)
row.names(nc_poop_1102)<- nc_poop_1102$X

nc_poop_1207<- nc_poop_all[,7]
nc_poop_1207<- as.data.frame(nc_poop_1207)
row.names(nc_poop_1207)<- nc_poop_1207$X

nc_poop_1802<- nc_poop_all[,8]
nc_poop_1802<- as.data.frame(nc_poop_1802)
row.names(nc_poop_1802)<- nc_poop_1802$X

nc_poop_2508<- nc_poop_all[,9]
nc_poop_2508<- as.data.frame(nc_poop_2508)
row.names(nc_poop_2508)<- nc_poop_2508$X

neg_controls_poop_nc<- read.table("neg_controls_poop_nc.txt", header=T, sep="\t")

##
nc_poop_0408_samples <- neg_controls_poop_nc$sample[neg_controls_poop_nc$negcontrol == "nc_poop_0408"]
# Use match() to find the corresponding indices in its2_asv_table_nonc_only_poopNC
nc_poop_0408_indices <- match(nc_poop_0408_samples, colnames(its2_asv_table_nonc_only_poopNC))

nc_poop_0707_samples <- neg_controls_poop_nc$sample[neg_controls_poop_nc$negcontrol == "nc_poop_0707"]
nc_poop_0707_indices <- match(nc_poop_0707_samples, colnames(its2_asv_table_nonc_only_poopNC))

nc_poop_1702_samples <- neg_controls_poop_nc$sample[neg_controls_poop_nc$negcontrol == "nc_poop_1702"]
nc_poop_1702_indices <- match(nc_poop_1702_samples, colnames(its2_asv_table_nonc_only_poopNC))

nc_poop_2702_samples <- neg_controls_poop_nc$sample[neg_controls_poop_nc$negcontrol == "nc_poop_2702"]
nc_poop_2702_indices <- match(nc_poop_2702_samples, colnames(its2_asv_table_nonc_only_poopNC))

nc_poop_1102_samples <- neg_controls_poop_nc$sample[neg_controls_poop_nc$negcontrol == "nc_poop_1102"]
nc_poop_1102_indices <- match(nc_poop_1102_samples, colnames(its2_asv_table_nonc_only_poopNC))

nc_poop_1207_samples <- neg_controls_poop_nc$sample[neg_controls_poop_nc$negcontrol == "nc_poop_1207"]
nc_poop_1207_indices <- match(nc_poop_1207_samples, colnames(its2_asv_table_nonc_only_poopNC))

nc_poop_1802_samples <- neg_controls_poop_nc$sample[neg_controls_poop_nc$negcontrol == "nc_poop_1802"]
nc_poop_1802_indices <- match(nc_poop_1802_samples, colnames(its2_asv_table_nonc_only_poopNC))

nc_poop_2508_samples <- neg_controls_poop_nc$sample[neg_controls_poop_nc$negcontrol == "nc_poop_2508"]
nc_poop_2508_indices <- match(nc_poop_2508_samples, colnames(its2_asv_table_nonc_only_poopNC))

nc_poop_0408_matrix <- matrix(rep(nc_poop_0408, each = length(nc_poop_0408_indices)), byrow = TRUE, ncol = length(nc_poop_0408_indices))
nc_poop_0707_matrix <- matrix(rep(nc_poop_0707, each = length(nc_poop_0707_indices)), byrow = TRUE, ncol = length(nc_poop_0707_indices))
nc_poop_1702_matrix <- matrix(rep(nc_poop_1702, each = length(nc_poop_1702_indices)), byrow = TRUE, ncol = length(nc_poop_1702_indices))
nc_poop_2702_matrix <- matrix(rep(nc_poop_2702, each = length(nc_poop_2702_indices)), byrow = TRUE, ncol = length(nc_poop_2702_indices))
nc_poop_1102_matrix <- matrix(rep(nc_poop_1102, each = length(nc_poop_1102_indices)), byrow = TRUE, ncol = length(nc_poop_1102_indices))
nc_poop_1207_matrix <- matrix(rep(nc_poop_1207, each = length(nc_poop_1207_indices)), byrow = TRUE, ncol = length(nc_poop_1207_indices))
nc_poop_1802_matrix <- matrix(rep(nc_poop_1802, each = length(nc_poop_1802_indices)), byrow = TRUE, ncol = length(nc_poop_1802_indices))
nc_poop_2508_matrix <- matrix(rep(nc_poop_2508, each = length(nc_poop_2508_indices)), byrow = TRUE, ncol = length(nc_poop_2508_indices))

nc_poop_total<- cbind(nc_poop_0408_matrix, nc_poop_0707_matrix, nc_poop_1702_matrix, nc_poop_2702_matrix, nc_poop_1102_matrix, nc_poop_1207_matrix, nc_poop_1802_matrix, nc_poop_2508_matrix)
its2_asv_table_nonc_nopoopnc <- its2_asv_table_nonc_only_poopNC[,!((its2_asv_table_nonc_only_poopNC) %in% nc_poop_all)]
selected_columns <- neg_controls_poop_nc$sample
its2_asv_table_nonc_nopoopnc_filter <- its2_asv_table_nonc_only_poopNC[,selected_columns]
remaining_columns <- setdiff(colnames(its2_asv_table_nonc_nopoopnc), selected_columns)
remaining_columns_2 <- remaining_columns[remaining_columns != "asv_id"]
its2_asv_table_nonc_nopoopnc_remaining <- its2_asv_table_nonc_nopoopnc[, remaining_columns_2]
head(its2_asv_table_nonc_nopoopnc_remaining)

its2_asv_table_all_clean_nonc <- its2_asv_table_nonc_nopoopnc_filter - nc_poop_total

its2_asv_table_all_clean<-cbind(its2_asv_table_all_clean_nonc, its2_asv_table_nonc_nopoopnc_remaining)
# Replace negative values with 0
its2_asv_table_all_clean[its2_asv_table_all_clean < 0] <- 0
its2_asv_table_all_clean$asv_id<-row.names(its2_asv_table_all_clean)

write.csv(its2_asv_table_all_clean, file = "its2_asv_table_all_clean.csv", quote = FALSE, row.names = T)
write.xlsx(its2_asv_table_all_clean, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "its2_asv_table_all_clean.xlsx"))

###############################make Phyloseq objects###############################################################
#STEP 3-1 make Phyloseq objects for plant data with OTU data(after subtracted NC), taxonomy data and metadata (sample-info)
its2_otu<-read.table("its2_asv_table_all_clean.txt", header=TRUE)
its2_otu<- as.data.frame(its2_otu)
row.names(its2_otu)<- its2_otu$asv_id
its2_otu<-its2_otu[,-1]
head(its2_otu)
its2_tax<-read.table("taxatable_its2_20240821.txt", sep='\t', header=TRUE)
row.names(its2_tax)<- its2_tax$asv_id
its2_tax<-its2_tax[,-1]
head(its2_tax)
its2_otu_table=as.matrix(its2_otu)
its2_taxonomy= as.matrix(its2_tax)
its2_metadata<-read.csv("metadata.csv", sep=';', header=TRUE)
row.names(its2_metadata)<- its2_metadata$PoopNr

its2_root_tree = read_tree("rooted_tree.nwk")


## create phyloseq object
its2_OTU = otu_table(its2_otu_table, taxa_are_rows=TRUE)
its2_TAX = tax_table(its2_taxonomy)
its2_META = sample_data(its2_metadata)

taxa_names(its2_TAX)
taxa_names(its2_OTU)
taxa_names(its2_root_tree)

sample_names(its2_OTU)
sample_names(its2_META)

its2_physeq = phyloseq(its2_OTU, its2_TAX, its2_META, its2_root_tree)
its2_physeq
rank_names(its2_physeq)
#otu_table()   OTU Table:         [ 3178 taxa and 63 samples ]
#sample_data() Sample Data:       [ 63 samples by 33 sample variables ]
#tax_table()   Taxonomy Table:    [ 3178 taxa by 11 taxonomic ranks ]
#phy_tree()    Phylogenetic Tree: [ 3178 tips and 3104 internal nodes ]

sum(sample_sums(its2_physeq)) # calculate total number of sequence reads and counts per sample
sample_sums(its2_physeq)    # number of read counts per sample
range(taxa_sums(its2_physeq))    # range of ASV abundance
range(sample_sums(its2_physeq))  # range of counts per sample
summary(sample_sums(its2_physeq))
sample_variables(its2_physeq)    # variables available
table(tax_table(its2_physeq)[,"phylum"], exclude=NULL)
table(tax_table(its2_physeq)[,"kingdom"], exclude=NULL)
table(tax_table(its2_physeq)[,"genus"], exclude=NULL)
## remove no identification
## remove ASVs with 0 reads
its2_physeq_clean <- subset_taxa(its2_physeq, kingdom != "no identification")
its2_physeq_clean <- prune_taxa(taxa_sums(its2_physeq_clean)>0, its2_physeq_clean)
# check removal
table(tax_table(its2_physeq_clean)[,"kingdom"], exclude=NULL)

# Check data again
its2_physeq_clean
#phyloseq-class experiment-level object
#otu_table()   OTU Table:         [ 2468 taxa and 63 samples ]
#sample_data() Sample Data:       [ 63 samples by 33 sample variables ]
#tax_table()   Taxonomy Table:    [ 2468 taxa by 11 taxonomic ranks ]
#phy_tree()    Phylogenetic Tree: [ 2468 tips and 2406 internal nodes ]

sum(sample_sums(its2_physeq_clean))
sample_sums(its2_physeq_clean)
range(taxa_sums(its2_physeq_clean))
range(sample_sums(its2_physeq_clean))
summary(sample_sums(its2_physeq_clean))
table(tax_table(its2_physeq_clean)[,"phylum"], exclude=NULL)

# Make taxa and ASV table en write to file
its2_taxa_physeq_clean = as(tax_table(its2_physeq_clean), "matrix")
write.csv(its2_taxa_physeq_clean, file='its2_taxa_physeq_clean.csv')
its2_ASV_physeq_clean = as(otu_table(its2_physeq_clean), "matrix")
write.csv(its2_ASV_physeq_clean, file='its2_ASV_physeq_clean.csv')

#save phyloseq object
saveRDS(its2_physeq_clean, "its2_physeq_clean.rds")
# load phyloseq object
#its2_physeq_clean <- readRDS("its2_physeq_clean.rds")


# remove singletons
its2_physeq_clean_min2 <-prune_taxa(taxa_sums(its2_physeq_clean)>1, its2_physeq_clean)
its2_physeq_clean_min2
#phyloseq-class experiment-level object
#otu_table()   OTU Table:         [ 2369taxa and 63 samples ]
#sample_data() Sample Data:       [ 63 samples by 33 sample variables ]
#tax_table()   Taxonomy Table:    [ 2369 taxa by 11 taxonomic ranks ]
#phy_tree()    Phylogenetic Tree: [ 2369 tips and 2309 internal nodes ]

sum(sample_sums(its2_physeq_clean_min2))
sample_sums(its2_physeq_clean_min2)
range(taxa_sums(its2_physeq_clean_min2))
range(sample_sums(its2_physeq_clean_min2))
summary(sample_sums(its2_physeq_clean_min2))
table(tax_table(its2_physeq_clean_min2)[,"phylum"], exclude=NULL)
table(tax_table(its2_physeq_clean_min2)[,"kingdom"], exclude=NULL)
table(tax_table(its2_physeq_clean_min2)[,"species"], exclude=NULL)

# Make taxa and ASV table en write to file
taxa_its2_physeq_clean_min2 = as(tax_table(its2_physeq_clean_min2), "matrix")
write.csv(taxa_its2_physeq_clean_min2, file='taxa_its2_physeq_clean_min2.csv')
ASV_its2_physeq_clean_min2 = as(otu_table(its2_physeq_clean_min2), "matrix")
write.csv(ASV_its2_physeq_clean_min2, file='ASV_its2_physeq_clean_min2.csv')
metadata_its2_physeq_clean_min2 <- data.frame(sample_data(its2_physeq_clean_min2))
write.csv(metadata_its2_physeq_clean_min2, "metadata_its2_physeq_clean_min2.csv")
tree_its2_physeq_clean_min2 <- write.tree(phy_tree(its2_physeq_clean_min2))
write(tree_its2_physeq_clean_min2, file = "tree_its2_physeq_clean_min2.newick")

#save phyloseq object
saveRDS(its2_physeq_clean_min2, "its2_physeq_clean_min2_plant.rds")
# load phyloseq object
#its2_physeq_clean_min2 <- readRDS("its2_physeq_clean_min2_plant.rds")

#Look at the distribution of total reads per sample
readsumsdf = data.frame(nreads = sort(taxa_sums(its2_physeq_clean_min2), TRUE), sorted = 1:ntaxa(its2_physeq_clean_min2),
                        type = "ASVs")
readsumsdf = rbind(readsumsdf, data.frame(nreads = sort(sample_sums(its2_physeq_clean_min2),
                                                        TRUE), sorted = 1:nsamples(its2_physeq_clean_min2), type = "Samples"))
title = "Overview number of reads for all samples"
p = ggplot(readsumsdf, aes(x = sorted, y = nreads)) + geom_bar(stat = "identity")
p + ggtitle(title) + scale_y_log10() + facet_wrap(~type, 1, scales = "free")

#summarize sequencing depth - do this on unrarefied data!
sdtrp = data.table(as(sample_data(its2_physeq_clean_min2), "data.frame"),
                   TotalReads = sample_sums(its2_physeq_clean_min2), keep.rownames = TRUE)
setnames(sdtrp, "rn", "SampleID")
ggplot(sdtrp, aes(TotalReads)) + geom_histogram() +
  ggtitle("Sequencing Depth")

#Check readsumsdf and sdtrp file; are singletons still in dataset?
sdtrp[(TotalReads <= 0), .N]
sdtrp[(TotalReads <= 200), .N]
sdtrp[(TotalReads <= 500), .N]
sdtrp[(TotalReads <= 1000), .N]
sdtrp[(TotalReads <= 2000), .N]
sdtrp[(TotalReads <= 10000), .N]
sdtrp[(TotalReads <= 15000), .N]

# Another way to inspect rare ASVs is to look at the prevalence of the ASVs.
# Generate a table with prevelance (the number of samples each taxa occurs in)
# and total abundance (total number of read counts) for each taxa.
its2_physeq_clean_min2_prevelance_df = apply(X = otu_table(its2_physeq_clean_min2),
                                       MARGIN = 1,
                                       FUN = function(x){sum(x > 0)})
# Add taxonomy and total read counts to this data.frame
its2_physeq_clean_min2_prevelance_df = data.frame(Prevalence =its2_physeq_clean_min2_prevelance_df,
                                            TotalAbundance = taxa_sums(its2_physeq_clean_min2),
                                            tax_table(its2_physeq_clean_min2))
its2_physeq_clean_min2_prevelance_df[1:10,]
write.table(its2_physeq_clean_min2_prevelance_df, file = "its2_physeq_clean_min2_prevelance_df_20240828.csv")

# Next explore prevalence (and abundance) per phylum to gain more insight into the data
plyr::ddply(its2_physeq_clean_min2_prevelance_df, "phylum", function(df1)(cbind(mean(df1$Prevalence), sum(df1$Prevalence), mean(df1$TotalAbundance), sum(df1$TotalAbundance))))
# Make a prevalence plot per phylum with indicator line at 5%.
ggplot(its2_physeq_clean_min2_prevelance_df, aes(TotalAbundance, Prevalence / nsamples(its2_physeq_clean_min2),color=phylum)) +
  # Include a guess for parameter
  geom_hline(yintercept = 0.05, alpha = 0.5, linetype = 2) + geom_point(size = 2, alpha = 0.7) +
  scale_x_log10() + xlab("Total Abundance") + ylab("Prevalence [Frac. Samples]") +
  facet_wrap(~phylum, nrow = 5) + theme(legend.position="none")

##################################################################################
#Subset for Pinophyta (1), Streptophyta (503)
its2_physeq_clean_min2_pinstrep = subset_taxa(its2_physeq_clean_min2, phylum == "Streptophyta" | phylum == "Pinophyta" )
its2_physeq_clean_min2_pinstrep <-prune_taxa(taxa_sums(its2_physeq_clean_min2_pinstrep)>0, its2_physeq_clean_min2_pinstrep)
its2_physeq_clean_min2_pinstrep
its2_physeq_clean_min2_pinstrep <-prune_taxa(taxa_sums(its2_physeq_clean_min2_pinstrep)>1, its2_physeq_clean_min2_pinstrep)
its2_physeq_clean_min2_pinstrep
#phyloseq-class experiment-level object
#otu_table()   OTU Table:         [ 504 taxa and 63 samples ]
#sample_data() Sample Data:       [ 63 samples by 33 sample variables ]
#tax_table()   Taxonomy Table:    [ 504 taxa by 11 taxonomic ranks ]
#phy_tree()    Phylogenetic Tree: [ 504 tips and 496 internal nodes ]

sum(sample_sums(its2_physeq_clean_min2_pinstrep))
sample_sums(its2_physeq_clean_min2_pinstrep)
range(taxa_sums(its2_physeq_clean_min2_pinstrep))    # range of OTU abundance
range(sample_sums(its2_physeq_clean_min2_pinstrep))  # range of counts per sample
summary(sample_sums(its2_physeq_clean_min2_pinstrep))
table(tax_table(its2_physeq_clean_min2_pinstrep)[,"phylum"], exclude=NULL)
table(tax_table(its2_physeq_clean_min2_pinstrep)[,"class"], exclude=NULL)#Magnoliopsida(499)
table(tax_table(its2_physeq_clean_min2_pinstrep)[,"order"], exclude=NULL)
table(tax_table(its2_physeq_clean_min2_pinstrep)[,"family"], exclude=NULL)
table(tax_table(its2_physeq_clean_min2_pinstrep)[,"genus"], exclude=NULL)

# Make taxa and ASV table en write to file
taxa_its2_physeq_clean_min2_pinstrep = as(tax_table(its2_physeq_clean_min2_pinstrep), "matrix")
write.csv(taxa_its2_physeq_clean_min2_pinstrep, file='taxa_its2_physeq_clean_min2_pinstrep.csv')
write.xlsx(taxa_its2_physeq_clean_min2_pinstrep, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "taxa_its2_physeq_clean_min2_pinstrep.xlsx"),rowNames=TRUE)
ASV_its2_physeq_clean_min2_pinstrep = as(otu_table(its2_physeq_clean_min2_pinstrep), "matrix")
write.csv(ASV_its2_physeq_clean_min2_pinstrep, file='ASV_its2_physeq_clean_min2_pinstrep.csv')
write.xlsx(ASV_its2_physeq_clean_min2_pinstrep, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "ASV_its2_physeq_clean_min2_pinstrep.xlsx"),rowNames=TRUE)
metadata_its2_physeq_clean_min2_pinstrep <- data.frame(sample_data(its2_physeq_clean_min2_pinstrep))
write.csv(metadata_its2_physeq_clean_min2_pinstrep, "metadata_its2_physeq_clean_min2_pinstrep.csv")
write.xlsx(metadata_its2_physeq_clean_min2_pinstrep, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "metadata_its2_physeq_clean_min2_pinstrep.xlsx"),rowNames=TRUE)
tree_its2_physeq_clean_min2_pinstrep <- write.tree(phy_tree(its2_physeq_clean_min2_pinstrep))
write(tree_its2_physeq_clean_min2_pinstrep, file = "tree_its2_physeq_clean_min2_pinstrep.newick")

#save phyloseq object
saveRDS(its2_physeq_clean_min2_pinstrep, "its2_physeq_clean_min2_pinstrep.rds")
# load phyloseq object
#physeq_loaded
#its2_physeq_clean_min2_pinstrep<- readRDS("its2_physeq_clean_min2_pinstrep.rds")

ASV_its2_physeq_clean_min2_pinstrep <- as.data.frame(ASV_its2_physeq_clean_min2_pinstrep)
ASV_its2_physeq_clean_min2_pinstrep$asv_id <- rownames(ASV_its2_physeq_clean_min2_pinstrep)
its2_mock_samples_asv_table_plant <- as.data.frame(its2_mock_samples_asv_table_plant)

combined_asv_table_mock_plant <- full_join(ASV_its2_physeq_clean_min2_pinstrep,its2_mock_samples_asv_table_plant, by = "asv_id")
write.csv(combined_asv_table_mock_plant, file = "combined_asv_table_mock_plant.csv", quote = FALSE, row.names = T)
write.xlsx(combined_asv_table_mock_plant, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "combined_asv_table_mock_plant.xlsx"))

combined_asv_table_mock_plant$SumM1_M12 <- rowSums(combined_asv_table_mock_plant[, 65:76])
rownames(combined_asv_table_mock_plant)<-combined_asv_table_mock_plant$asv_id
write.xlsx(combined_asv_table_mock_plant, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "combined_asv_table_mock_plant_SumM1_M12.xlsx"),rowNames=TRUE)

###Subset for Pinophyta (1)
its2_physeq_clean_min2_pin = subset_taxa(its2_physeq_clean_min2, phylum == "Pinophyta" )
its2_physeq_clean_min2_pin <-prune_taxa(taxa_sums(its2_physeq_clean_min2_pin)>0, its2_physeq_clean_min2_pin)
its2_physeq_clean_min2_pin
its2_physeq_clean_min2_pin <-prune_taxa(taxa_sums(its2_physeq_clean_min2_pin)>1, its2_physeq_clean_min2_pin)
its2_physeq_clean_min2_pin
sum(sample_sums(its2_physeq_clean_min2_pin))
sample_sums(its2_physeq_clean_min2_pin)
range(taxa_sums(its2_physeq_clean_min2_pin))    # range of OTU abundance
range(sample_sums(its2_physeq_clean_min2_pin))  # range of counts per sample
summary(sample_sums(its2_physeq_clean_min2_pin))
table(tax_table(its2_physeq_clean_min2_pin)[,"class"], exclude=NULL)
table(tax_table(its2_physeq_clean_min2_pin)[,"order"], exclude=NULL)
table(tax_table(its2_physeq_clean_min2_pin)[,"family"], exclude=NULL)
table(tax_table(its2_physeq_clean_min2_pin)[,"genus"], exclude=NULL)
table(tax_table(its2_physeq_clean_min2_pin)[,"species"], exclude=NULL)

#Subset for Streptophyta (503)
its2_physeq_clean_min2_strep = subset_taxa(its2_physeq_clean_min2, phylum=="Streptophyta")
its2_physeq_clean_min2_strep <-prune_taxa(taxa_sums(its2_physeq_clean_min2_strep)>0, its2_physeq_clean_min2_strep)
its2_physeq_clean_min2_strep
its2_physeq_clean_min2_strep <-prune_taxa(taxa_sums(its2_physeq_clean_min2_strep)>1, its2_physeq_clean_min2_strep)
its2_physeq_clean_min2_strep

sum(sample_sums(its2_physeq_clean_min2_strep))
sample_sums(its2_physeq_clean_min2_strep)
range(taxa_sums(its2_physeq_clean_min2_strep))    # range of OTU abundance
range(sample_sums(its2_physeq_clean_min2_strep))  # range of counts per sample
summary(sample_sums(its2_physeq_clean_min2_strep))
table(tax_table(its2_physeq_clean_min2_strep)[,"phylum"], exclude=NULL)
table(tax_table(its2_physeq_clean_min2_strep)[,"class"], exclude=NULL)#Magnoliopsida(499)
table(tax_table(its2_physeq_clean_min2_strep)[,"order"], exclude=NULL)
table(tax_table(its2_physeq_clean_min2_strep)[,"family"], exclude=NULL)
table(tax_table(its2_physeq_clean_min2_strep)[,"genus"], exclude=NULL)

#Subset for class Klebsormidiophyceae (3)
its2_physeq_clean_min2_kleb = subset_taxa(its2_physeq_clean_min2_pinstrep, class == "Klebsormidiophyceae" )
its2_physeq_clean_min2_kleb <-prune_taxa(taxa_sums(its2_physeq_clean_min2_kleb)>0, its2_physeq_clean_min2_kleb)
its2_physeq_clean_min2_kleb
its2_physeq_clean_min2_kleb <-prune_taxa(taxa_sums(its2_physeq_clean_min2_kleb)>1, its2_physeq_clean_min2_kleb)
its2_physeq_clean_min2_kleb
sum(sample_sums(its2_physeq_clean_min2_kleb))
sample_sums(its2_physeq_clean_min2_kleb)
range(taxa_sums(its2_physeq_clean_min2_kleb))    # range of OTU abundance
range(sample_sums(its2_physeq_clean_min2_kleb))  # range of counts per sample
summary(sample_sums(its2_physeq_clean_min2_kleb))
table(tax_table(its2_physeq_clean_min2_kleb)[,"class"], exclude=NULL)
table(tax_table(its2_physeq_clean_min2_kleb)[,"order"], exclude=NULL)
table(tax_table(its2_physeq_clean_min2_kleb)[,"family"], exclude=NULL)
table(tax_table(its2_physeq_clean_min2_kleb)[,"genus"], exclude=NULL)
table(tax_table(its2_physeq_clean_min2_kleb)[,"species"], exclude=NULL)

#Subset for class Magnoliopsida (499)
its2_physeq_clean_min2_Mag = subset_taxa(its2_physeq_clean_min2_pinstrep, class == "Magnoliopsida" )
its2_physeq_clean_min2_Mag <-prune_taxa(taxa_sums(its2_physeq_clean_min2_Mag)>0, its2_physeq_clean_min2_Mag)
its2_physeq_clean_min2_Mag
its2_physeq_clean_min2_Mag <-prune_taxa(taxa_sums(its2_physeq_clean_min2_Mag)>1, its2_physeq_clean_min2_Mag)
its2_physeq_clean_min2_Mag
sum(sample_sums(its2_physeq_clean_min2_Mag))
sample_sums(its2_physeq_clean_min2_Mag)
range(taxa_sums(its2_physeq_clean_min2_Mag))    # range of OTU abundance
range(sample_sums(its2_physeq_clean_min2_Mag))  # range of counts per sample
summary(sample_sums(its2_physeq_clean_min2_Mag))
table(tax_table(its2_physeq_clean_min2_Mag)[,"class"], exclude=NULL)
table(tax_table(its2_physeq_clean_min2_Mag)[,"order"], exclude=NULL)
table(tax_table(its2_physeq_clean_min2_Mag)[,"family"], exclude=NULL)
table(tax_table(its2_physeq_clean_min2_Mag)[,"genus"], exclude=NULL)
table(tax_table(its2_physeq_clean_min2_Mag)[,"species"], exclude=NULL)

#Transform OTU counts to relative abundances
# use file its2_physeq_clean_min2_pinstrep
## Use Krona make a Sunburst Chart
its2_physeq_clean_min2_pinstrep_rel <- transform_sample_counts(its2_physeq_clean_min2_pinstrep, function(x) x / sum(x))
# Melt the phyloseq object to get long-form data
physeq_melt_pinstrep <- psmelt(its2_physeq_clean_min2_pinstrep_rel)
physeq_melt_pinstrep_2 <-physeq_melt_pinstrep
write.csv(physeq_melt_pinstrep_2, file='physeq_melt_pinstrep.csv')
write.xlsx(physeq_melt_pinstrep_2, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "physeq_melt_pinstrep.xlsx"))

physeq_melt_pinstrep_readcount <- psmelt(its2_physeq_clean_min2_pinstrep)
write.csv(physeq_melt_pinstrep_readcount, file='physeq_melt_pinstrep_readcount.csv')
write.xlsx(physeq_melt_pinstrep_readcount, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "physeq_melt_pinstrep_readcount.xlsx"))

###########################################FOO#############################################################
head(tax_table(its2_physeq_clean_min2_pinstrep))
its2_physeq_psmelt_pinstrep <- psmelt(its2_physeq_clean_min2_pinstrep)

###Richness of per season and per location
its2_physeq_psmelt_pinstrep_2 <- filter(its2_physeq_psmelt_pinstrep, Abundance >0)
its2_MOTU_counts <- its2_physeq_psmelt_pinstrep_2 %>%
  group_by(Sample) %>%
  summarise(Nu_MOTUs = n_distinct(OTU))
metadata_its2_physeq_clean_min2_pinstrep$Sample <- rownames(metadata_its2_physeq_clean_min2_pinstrep)

its2_MOTU_counts<- merge(its2_MOTU_counts,metadata_its2_physeq_clean_min2_pinstrep,by="Sample")
its2_MOTU_counts$Nu_MOTUs <- as.numeric(gsub(",", ".", its2_MOTU_counts$Nu_MOTUs))

colslocal <- c("darkseagreen", "darkgreen","saddlebrown")
colsSeason <- c("#DA5724","#508578")
#season
ggplot(its2_MOTU_counts, aes(x = Season, y = Nu_MOTUs, fill = Season)) +
  geom_violin(position = position_dodge(width = 1), scale = 'width') +
  geom_boxplot(position = position_dodge(width = 1), outlier.size = 0.7, width = 0.2, show.legend = FALSE,
               fill = "white", color = "black", alpha = 0) +
  geom_jitter(color = "gray", size = 1.5, width = 0.2) +
  scale_fill_manual(
    values = c("SUMMER" = "#DA5724", "WINTER" = "#508578"),
    labels = c("SUMMER" = "Summer", "WINTER" = "Winter")
  ) +
  scale_x_discrete(
    labels = c("SUMMER" = "Summer", "WINTER" = "Winter")
  ) +
  labs(x = '', y = 'Richness') +
  theme(panel.grid = element_blank(),
        panel.background = element_rect(fill = 'transparent', color = 'black'),
        legend.title = element_blank(),
        legend.key = element_blank())


ggplot(its2_MOTU_counts, aes(x = Location, y = Nu_MOTUs, fill = Location)) +
  geom_violin(position = position_dodge(width = 1), scale = 'width') +
  geom_boxplot(position = position_dodge(width = 1), outlier.size = 0.7, width = 0.2, show.legend = FALSE,
               fill = "white", color = "black", alpha = 0) +
  geom_jitter(color = "gray", size = 1.5, width = 0.2) +  # Set color directly
  scale_fill_manual(values = c("MOLUKKENPAD" = "darkseagreen", "NOORDERPLANTSOEN" = "darkgreen","VISMARKT" = "saddlebrown"),
                    labels = c("MOLUKKENPAD" = "Molukkenpad", "NOORDERPLANTSOEN" = "Noorderplantsoen","VISMARKT"="Vismarkt")) +
  scale_x_discrete(
    labels = c("MOLUKKENPAD" = "Molukkenpad", "NOORDERPLANTSOEN" = "Noorderplantsoen","VISMARKT"="Vismarkt")
  ) +
  labs(x = '', y = 'Richness') +
  theme(panel.grid = element_blank(),
        panel.background = element_rect(fill = 'transparent', color = 'black'),
        legend.title = element_blank(),
        legend.key = element_blank())

its2_MOTU =lme(Nu_MOTUs ~ Season+Location, random= ~1 | BirdID, na.action=na.omit,
          data=its2_MOTU_counts)
summary(its2_MOTU)
library(emmeans)
em1<-emmeans(its2_MOTU, ~ Location)
em1

##########FOO
###################family level
head(tax_table(its2_physeq_clean_min2_pinstrep))
its2_physeq_psmelt_pinstrep <- psmelt(its2_physeq_clean_min2_pinstrep)
write.csv(its2_physeq_psmelt_pinstrep, file='its2_physeq_psmelt_pinstrep.csv')
write.xlsx(its2_physeq_psmelt_pinstrep, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "its2_physeq_psmelt_pinstrep.xlsx"))

its2_Abundance_MOTU_merged_family <- summaryBy(Abundance ~ Sample + family,
                                           data = its2_physeq_psmelt_pinstrep,
                                           FUN = c(sum))
its2_Abundance_MOTU_merged_family <- its2_Abundance_MOTU_merged_family %>%
  group_by(Sample, family) %>%
  filter(!is.na(family) & nchar(family) > 0) %>%
  ungroup()

metadata_its2_physeq_clean_min2_pinstrep_2<-metadata_its2_physeq_clean_min2_pinstrep
metadata_its2_physeq_clean_min2_pinstrep_2$Sample<-rownames(metadata_its2_physeq_clean_min2_pinstrep_2)
its2_merged_family<- merge(its2_Abundance_MOTU_merged_family,metadata_its2_physeq_clean_min2_pinstrep_2,by="Sample")
write.csv(its2_merged_family, file='its2_merged_family.csv')
write.xlsx(its2_merged_family, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "its2_merged_family.xlsx"))
its2_merged_family<-as.data.frame(its2_merged_family)
its2_merged_family_remove_unknown <- its2_merged_family %>%
  group_by(Sample, family) %>%
  filter(!is.na(family) & nchar(family) > 0) %>%
  ungroup()

###FOO% FOR DIFFERENT SEASON AND LOCATION########################
its2_summer_family <- filter(its2_merged_family, Season == "SUMMER")
its2_winter_family <- filter(its2_merged_family, Season == "WINTER")
its2_MOLUKKENPAD_family <- filter(its2_merged_family, Location == "MOLUKKENPAD")
its2_NOORDERPLANTSOEN_family <- filter(its2_merged_family, Location == "NOORDERPLANTSOEN")
its2_VISMARKT_family <- filter(its2_merged_family, Location == "VISMARKT")

# Step 1:Presence/Absence table
otu_table_summer <- filter(its2_summer_family, Abundance.sum >0)
otu_table_winter <- filter(its2_winter_family, Abundance.sum >0)
otu_table_MOLUKKENPAD <- filter(its2_MOLUKKENPAD_family, Abundance.sum >0)
otu_table_NOORDERPLANTSOEN <- filter(its2_NOORDERPLANTSOEN_family, Abundance.sum >0)
otu_table_VISMARKT <- filter(its2_VISMARKT_family, Abundance.sum >0)

#number of occurrences
FOO_family_summer_occur <- otu_table_summer %>%
    group_by(family) %>%
    summarise(Num_Samples = n_distinct(Sample))
FOO_family_winter_occur <- otu_table_winter %>%
  group_by(family) %>%
  summarise(Num_Samples = n_distinct(Sample))
FOO_family_MOLUKKENPAD_occur <- otu_table_MOLUKKENPAD %>%
  group_by(family) %>%
  summarise(Num_Samples = n_distinct(Sample))
FOO_family_NOORDERPLANTSOEN_occur <- otu_table_NOORDERPLANTSOEN %>%
  group_by(family) %>%
  summarise(Num_Samples = n_distinct(Sample))
FOO_family_VISMARKT_occur <- otu_table_VISMARKT %>%
  group_by(family) %>%
  summarise(Num_Samples = n_distinct(Sample))

# calculate FOO
FOO_family_summer <- FOO_family_summer_occur %>%
    mutate(FOO = (Num_Samples / 33) * 100)
FOO_family_winter <- FOO_family_winter_occur %>%
  mutate(FOO = (Num_Samples / 30) * 100)
FOO_family_MOLUKKENPAD <- FOO_family_MOLUKKENPAD_occur %>%
  mutate(FOO = (Num_Samples / 23) * 100)
FOO_family_NOORDERPLANTSOEN <- FOO_family_NOORDERPLANTSOEN_occur %>%
  mutate(FOO = (Num_Samples / 26) * 100)
FOO_family_VISMARKT <- FOO_family_VISMARKT_occur %>%
  mutate(FOO = (Num_Samples / 14) * 100)

FOO_family_summer$season <- "SUMMER"
FOO_family_winter$season <- "WINTER"
FOO_family_MOLUKKENPAD$location <- "MOLUKKENPAD"
FOO_family_NOORDERPLANTSOEN$location <- "NOORDERPLANTSOEN"
FOO_family_VISMARKT$location <- "VISMARKT"

FOO_family_season <- rbind(FOO_family_summer, FOO_family_winter)
FOO_family_location <- rbind(FOO_family_MOLUKKENPAD, FOO_family_NOORDERPLANTSOEN,FOO_family_VISMARKT)

FOO_family_season$Nu <- row.names(FOO_family_season)
FOO_family_location$Nu <- row.names(FOO_family_location)

write.csv(FOO_family_season, "FOO_family_season.csv", row.names = FALSE)
write.csv(FOO_family_location, "FOO_family_location.csv", row.names = FALSE)
write.xlsx(FOO_family_season, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "FOO_family_season.xlsx"))
write.xlsx(FOO_family_location, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "FOO_family_location.xlsx"))

colslocal <- c("darkseagreen", "darkgreen","saddlebrown")
colsSeason <- c("#DA5724","#508578")

#per season
FOO_family_season <- FOO_family_season %>%
  complete(season, family, fill = list(FOO = 0))
p <- ggplot(data=FOO_family_season, aes(y=family, x=FOO, fill=season)) +
  geom_col(position = 'dodge') +
  scale_fill_manual("Season", values=colsSeason,labels = c("SUMMER" = "Summer", "WINTER" = "Winter")) +
  labs(x = "FOO (%, per season)", y = "Family", fill = "season") +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(colour = "black"))+
  geom_vline(xintercept = 50, linetype = "dashed", color = "gray", linewidth = 1)
p
#per location
FOO_family_location <- FOO_family_location %>%
  complete(location, family, fill = list(FOO = 0))
p <- ggplot(data=FOO_family_location, aes(y=family, x=FOO, fill=location)) +
  geom_col(position = 'dodge') +
  scale_fill_manual("Location", values=colslocal,labels = c("MOLUKKENPAD" = "Molukkenpad", "NOORDERPLANTSOEN" = "Noorderplantsoen","VISMARKT"="Vismarkt")) +
  labs(x = "FOO (%, per location)", y = "Family", fill = "location") +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(colour = "black"))+
  geom_vline(xintercept = 50, linetype = "dashed", color = "gray", size = 1)
p
########################on genus level#############################
head(tax_table(its2_physeq_clean_min2_pinstrep))
its2_physeq_psmelt_pinstrep <- psmelt(its2_physeq_clean_min2_pinstrep)
write.csv(its2_physeq_psmelt_pinstrep, file='its2_physeq_psmelt_pinstrep.csv')
write.xlsx(its2_physeq_psmelt_pinstrep, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "its2_physeq_psmelt_pinstrep.xlsx"))

its2_Abundance_MOTU_merged_genus <- summaryBy(Abundance ~ Sample + genus,
                                               data = its2_physeq_psmelt_pinstrep,
                                               FUN = c(sum))
its2_Abundance_MOTU_merged_genus <- its2_Abundance_MOTU_merged_genus %>%
  group_by(Sample, genus) %>%
  filter(!is.na(genus) & nchar(genus) > 0) %>%
  ungroup()

metadata_its2_physeq_clean_min2_pinstrep_2<-metadata_its2_physeq_clean_min2_pinstrep
metadata_its2_physeq_clean_min2_pinstrep_2$Sample<-rownames(metadata_its2_physeq_clean_min2_pinstrep_2)
its2_merged_genus<- merge(its2_Abundance_MOTU_merged_genus,metadata_its2_physeq_clean_min2_pinstrep_2,by="Sample")
write.csv(its2_merged_genus, file='its2_merged_genus.csv')
write.xlsx(its2_merged_genus, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "its2_merged_genus.xlsx"))
its2_merged_genus<-as.data.frame(its2_merged_genus)
its2_merged_genus_remove_unknown <- its2_merged_genus %>%
  group_by(Sample, genus) %>%
  filter(!is.na(genus) & nchar(genus) > 0) %>%
  ungroup()
write.csv(its2_merged_genus, file='its2_merged_genus.csv')
write.xlsx(its2_merged_genus, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "its2_merged_genus.xlsx"))


###FOO FOR DIFFERENT SEASON AND LOCATION########################
##on genus level
its2_summer_genus <- filter(its2_merged_genus, Season == "SUMMER")
its2_winter_genus <- filter(its2_merged_genus, Season == "WINTER")
its2_MOLUKKENPAD_genus <- filter(its2_merged_genus, Location == "MOLUKKENPAD")
its2_NOORDERPLANTSOEN_genus <- filter(its2_merged_genus, Location == "NOORDERPLANTSOEN")
its2_VISMARKT_genus <- filter(its2_merged_genus, Location == "VISMARKT")

# Step 1:Presence/Absence table
otu_table_summer <- filter(its2_summer_genus, Abundance.sum >0)
otu_table_winter <- filter(its2_winter_genus, Abundance.sum >0)
otu_table_MOLUKKENPAD <- filter(its2_MOLUKKENPAD_genus, Abundance.sum >0)
otu_table_NOORDERPLANTSOEN <- filter(its2_NOORDERPLANTSOEN_genus, Abundance.sum >0)
otu_table_VISMARKT <- filter(its2_VISMARKT_genus, Abundance.sum >0)

#number of occurrences
FOO_genus_summer_occur <- otu_table_summer %>%
  group_by(genus) %>%
  summarise(Num_Samples = n_distinct(Sample))
FOO_genus_winter_occur <- otu_table_winter %>%
  group_by(genus) %>%
  summarise(Num_Samples = n_distinct(Sample))
FOO_genus_MOLUKKENPAD_occur <- otu_table_MOLUKKENPAD %>%
  group_by(genus) %>%
  summarise(Num_Samples = n_distinct(Sample))
FOO_genus_NOORDERPLANTSOEN_occur <- otu_table_NOORDERPLANTSOEN %>%
  group_by(genus) %>%
  summarise(Num_Samples = n_distinct(Sample))
FOO_genus_VISMARKT_occur <- otu_table_VISMARKT %>%
  group_by(genus) %>%
  summarise(Num_Samples = n_distinct(Sample))

# calculate FOO
FOO_genus_summer <- FOO_genus_summer_occur %>%
  mutate(FOO = (Num_Samples / 33) * 100)
FOO_genus_winter <- FOO_genus_winter_occur %>%
  mutate(FOO = (Num_Samples / 30) * 100)
FOO_genus_MOLUKKENPAD <- FOO_genus_MOLUKKENPAD_occur %>%
  mutate(FOO = (Num_Samples / 23) * 100)
FOO_genus_NOORDERPLANTSOEN <- FOO_genus_NOORDERPLANTSOEN_occur %>%
  mutate(FOO = (Num_Samples / 26) * 100)
FOO_genus_VISMARKT <- FOO_genus_VISMARKT_occur %>%
  mutate(FOO = (Num_Samples / 14) * 100)

FOO_genus_summer$season <- "SUMMER"
FOO_genus_winter$season <- "WINTER"
FOO_genus_MOLUKKENPAD$location <- "MOLUKKENPAD"
FOO_genus_NOORDERPLANTSOEN$location <- "NOORDERPLANTSOEN"
FOO_genus_VISMARKT$location <- "VISMARKT"

FOO_genus_season <- rbind(FOO_genus_summer, FOO_genus_winter)
FOO_genus_location <- rbind(FOO_genus_MOLUKKENPAD, FOO_genus_NOORDERPLANTSOEN,FOO_genus_VISMARKT)

FOO_genus_season$Nu <- row.names(FOO_genus_season)
FOO_genus_location$Nu <- row.names(FOO_genus_location)

write.csv(FOO_genus_season, "FOO_genus_season.csv", row.names = FALSE)
write.csv(FOO_genus_location, "FOO_genus_location.csv", row.names = FALSE)
write.xlsx(FOO_genus_season, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "FOO_genus_season.xlsx"))
write.xlsx(FOO_genus_location, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "FOO_genus_location.xlsx"))

colslocal <- c("darkseagreen", "darkgreen","saddlebrown")
colsSeason <- c("#DA5724","#508578")

FOO_genus_season_merged<- merge(FOO_genus_season,taxa_its2_physeq_clean_min2_pinstrep, by="genus")
FOO_genus_location_merged<- merge(FOO_genus_location,taxa_its2_physeq_clean_min2_pinstrep, by="genus")

FOO_genus_season_merged <- FOO_genus_season_merged %>%
  distinct(genus,season, .keep_all = TRUE)
FOO_genus_location_merged <- FOO_genus_location_merged %>%
  distinct(genus,location, .keep_all = TRUE)

FOO_genus_season_merged_PFA <- filter(FOO_genus_season_merged, family == "Poaceae"|family == "Fabaceae"|family == "Asteraceae")
FOO_genus_location_merged_PFA <- filter(FOO_genus_location_merged, family == "Poaceae"|family == "Fabaceae"|family == "Asteraceae")

#per season
FOO_genus_season_merged_PFA <- FOO_genus_season_merged_PFA %>%
  complete(season, genus, fill = list(FOO = 0))

p <- ggplot(data=FOO_genus_season_merged_PFA, aes(y=genus, x=FOO, fill=season)) +
  geom_col(position = 'dodge') +
  scale_fill_manual("Season", values=colsSeason, labels = c("SUMMER" = "Summer", "WINTER" = "Winter")) +
  labs(x = "FOO (%, per season)", y = "Genus", fill = "season") +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(colour = "black"))+
  geom_vline(xintercept = 50, linetype = "dashed", color = "gray", linewidth = 1)
p

#per location
# Ensure that all combinations of locations and species are included in the dataset
# Use the complete() function to add missing location-genus combinations, setting the FOO value of these combinations to 0
FOO_genus_location_merged_PFA <- FOO_genus_location_merged_PFA %>%
  complete(location, genus, fill = list(FOO = 0))

p <- ggplot(data=FOO_genus_location_merged_PFA, aes(y=genus, x=FOO, fill=location)) +
  geom_col(position = 'dodge') +
  scale_fill_manual("Location", values=colslocal, labels = c("MOLUKKENPAD" = "Molukkenpad", "NOORDERPLANTSOEN" = "Noorderplantsoen","VISMARKT"="Vismarkt")) +
  labs(x = "FOO (%, per location)", y = "Genus", fill = "location") +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_blank(),
        axis.line = element_line(colour = "black"))+
  geom_vline(xintercept = 50, linetype = "dashed", color = "gray", linewidth = 1)
p

######################NMDS##############
#####family level
its2_Abundance_MOTU_merged_family
its2_Abundance_MOTU_merged_family <- as(its2_Abundance_MOTU_merged_family, "matrix")
metadata_its2_physeq_clean_min2_pinstrep_2<-metadata_its2_physeq_clean_min2_pinstrep
metadata_its2_physeq_clean_min2_pinstrep_2$Sample<-rownames(metadata_its2_physeq_clean_min2_pinstrep_2)
its2_merged_family<- merge(its2_Abundance_MOTU_merged_family,metadata_its2_physeq_clean_min2_pinstrep_2,by="Sample")
write.csv(its2_merged_family, file='its2_merged_family.csv')
write.xlsx(its2_merged_family, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "its2_merged_family.xlsx"))
its2_merged_family<-as.data.frame(its2_merged_family)
its2_merged_family_remove_unknown <- its2_merged_family %>%
  group_by(Sample, family) %>%
  filter(!is.na(family) & nchar(family) > 0) %>%
  ungroup()
write.csv(its2_merged_family_remove_unknown, file='its2_merged_family_remove_unknown.csv')
write.xlsx(its2_merged_family_remove_unknown, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "its2_merged_family_remove_unknown.xlsx"))

its2_NMDS_family <- read.table("its2_NMDS_family.txt", header=TRUE, sep="\t", na.strings="NA", dec=".", strip.white=TRUE)
row.names(its2_NMDS_family)<-its2_NMDS_family$Sample
data_1 <- its2_NMDS_family[,5:47]
data_2 <- its2_NMDS_family[,1:4]
data_2$Taxa <-as.factor(data_2$Taxa)
data_2$Season <-as.factor(data_2$Season)
data_2$Location <-as.factor(data_2$Location)
levels(data_2$Season)
levels(data_2$Location)

NMDS<-metaMDS(data_1, distance = "jaccard", k=3)
NMDS

# Stress:     0.1710712

# A good rule of thumb: stress < 0.05 provides an excellent representation
# in reduced dimensions, < 0.1 is great, < 0.2 is good/ok, and stress < 0.3
# provides a poor representation.** To reiterate: high stress is bad,
# low stress is good!

stressplot(NMDS)
plot(NMDS)
NMDS$points

nmds_otu_site<-data.frame(NMDS$points)
#write.table(nmds_otu_site,'nmds_otu_site.txt',sep='\t',col.names=NA,quote=FALSE)

nmds_otu_species<-data.frame(NMDS$species)
#write.table(nmds_otu_species,'nmds_otu_species.txt',sep='\t',col.names=NA,quote=FALSE)

colsSeason <- c("#DA5724","#508578")
colslocal <- c("darkseagreen", "darkgreen","saddlebrown")

shape=c(19) # Bsp 16=filled circle, 1=empty circle

#season
plot (NMDS$points, col=colsSeason[data_2$Season], cex=1, main="Diet composition", pch=shape[data_2$Taxa],

      xlab="NMDS1", ylab="NMDS2",xlim=c(-1.0,1.0),ylim=c(-1.0,1.5), cex.main=1.3)

orditorp(NMDS,display="species",col="black",air=0.5, cex=0.8)

ordispider(NMDS,groups=data_2$Species,col=colsSeason, label=FALSE)

ordiellipse(NMDS,groups=data_2$Species, display = "sites", col=colsSeason,

            kind = "se", conf = 0.95, label = FALSE, lwd=3)

fit<-adonis2 (data_1~Season, data=data_2, permutations=999, method="jaccard",by = "term")
fit
#         Df SumOfSqs     R2      F Pr(>F)
#Season    1    0.368 0.02264 1.4129  0.133
#Residual 61   15.886 0.97736
#Total    62   16.254 1.00000
nmds<-NMDS$points

#Group
nmds_otu_site$name <- rownames(nmds_otu_site)
nmds_otu_site$Season <- data_2$Season
nmds_otu_site$Location <- data_2$Location

p <- ggplot(data = nmds_otu_site, aes(MDS1, MDS2)) +
  stat_ellipse(aes(fill = Season), geom = 'polygon', level = 0.95, alpha = 0.1, show.legend = FALSE) +
  geom_point(aes(color = Season)) +
  scale_color_manual(values = colsSeason) +
  scale_fill_manual(values = colsSeason) +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_rect(color = 'black', fill = 'transparent'),
        plot.title = element_text(hjust = 0.5),
        legend.position = 'none',
        axis.line = element_line(color = "gray")) +
  geom_vline(xintercept = 0, color = 'gray', size = 0.5) +
  geom_hline(yintercept = 0, color = 'gray', size = 0.5) +
  labs(x = 'NMDS1', y = 'NMDS2', title = '') #+
  #annotate('text', label = paste('Stress =', round(NMDS$stress, 4)), x = 0.85, y = 1.0, size = 4, colour = 'black')
p
ggsave(filename = "NMDS_its2_season_MDS1_MDS2_family.pdf", device="pdf", width=6, height=6)

p2 <- ggplot(data = nmds_otu_site, aes(MDS2, MDS3)) +
  stat_ellipse(aes(fill = Season), geom = 'polygon', level = 0.95, alpha = 0.1, show.legend = FALSE) +
  geom_point(aes(color = Season)) +
  scale_color_manual(values = colsSeason) +
  scale_fill_manual(values = colsSeason) +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_rect(color = 'black', fill = 'transparent'),
        plot.title = element_text(hjust = 0.5),
        legend.position = 'none',
        axis.line = element_line(color = "gray")) +
  geom_vline(xintercept = 0, color = 'gray', size = 0.5) +
  geom_hline(yintercept = 0, color = 'gray', size = 0.5) +
  #geom_text(data = species_top10, aes(label = name), color = 'blue', size = 3) +
  labs(x = 'NMDS2', y = 'NMDS3', title = '') #+
  #annotate('text', label = paste('Stress =', round(NMDS$stress, 4)), x = 0.70, y = 1.0, size = 4, colour = 'black') #+
  #annotate('text', label = 'Summer', x = -0.8, y = -0.75, size = 5, colour = 'black') +
  #annotate('text', label = 'Winter', x = 0.8, y = 0.75, size = 5, colour = 'black')
p2
ggsave(filename = "NMDS_its2_season_MDS2_MDS3_family.pdf", device="pdf", width=6, height=6)

p3 <- ggplot(data = nmds_otu_site, aes(MDS1, MDS3)) +
  stat_ellipse(aes(fill = Season), geom = 'polygon', level = 0.95, alpha = 0.1, show.legend = FALSE) +
  geom_point(aes(color = Season)) +
  scale_color_manual(values = colsSeason, labels = c("SUMMER"="Summer", "WINTER"="Winter")) +
  scale_fill_manual(values = colsSeason, labels = c("SUMMER"="Summer", "WINTER"="Winter")) +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_rect(color = 'black', fill = 'transparent'),
        plot.title = element_text(hjust = 0.5),
        legend.position = 'right',
        axis.line = element_line(color = "gray")) +
  geom_vline(xintercept = 0, color = 'gray', size = 0.5) +
  geom_hline(yintercept = 0, color = 'gray', size = 0.5) +
  #geom_text(data = species_top10, aes(label = name), color = 'blue', size = 3) +
  labs(x = 'NMDS1', y = 'NMDS3', title = '') #+
  #annotate('text', label = paste('Stress =', round(NMDS$stress, 4)), x = 0.75, y = 1.0, size = 4, colour = 'black') #+
  #annotate('text', label = 'Summer', x = -0.8, y = -0.75, size = 5, colour = 'black') +
  #annotate('text', label = 'Winter', x = 0.8, y = 0.75, size = 5, colour = 'black')
p3
ggsave(filename = "NMDS_its2_season_MDS1_MDS3_family.pdf", device="pdf", width=8, height=6)

#location
plot (NMDS$points, col=colsloca[data_2$Location], cex=1, main="Diet composition", pch=shape[data_2$Taxa],

      xlab="NMDS1", ylab="NMDS2",xlim=c(-1.2,1.0),ylim=c(-1.0,1.5), cex.main=1.3)

orditorp(NMDS,display="species",col="black",air=0.5, cex=0.8)

fit<-adonis2 (data_1~Location, data=data_2, permutations=999, method="jaccard", by = "term")
fit
#         Df SumOfSqs      R2      F Pr(>F)
#Location  2   0.8431 0.05187 1.6413  0.016 *
#Residual 60  15.4113 0.94813
#Total    62  16.2544 1.00000
summary(fit)

#devtools::install_github("pmartinezarbizu/pairwiseAdonis/pairwiseAdonis", force = TRUE)

library(pairwiseAdonis)
dune.pairwise.adonis <- pairwise.adonis(x=data_1, factors=data_2$Location,
                                        sim.function = "vegdist",
                                        sim.method = "jaccard",
                                        p.adjust.m = "BH",
                                        reduce = NULL,
                                        perm = 999)

dune.pairwise.adonis

p <- ggplot(data = nmds_otu_site, aes(MDS1, MDS2)) +
  stat_ellipse(aes(fill = Location), geom = 'polygon', level = 0.95, alpha = 0.1, show.legend = FALSE) +
  geom_point(aes(color = Location)) +
  scale_color_manual(values = colslocal) +
  scale_fill_manual(values = colslocal) +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_rect(color = 'black', fill = 'transparent'),
        plot.title = element_text(hjust = 0.5),
        legend.position = 'none',
        axis.line = element_line(color = "gray")) +
  geom_vline(xintercept = 0, color = 'gray', size = 0.5) +
  geom_hline(yintercept = 0, color = 'gray', size = 0.5) +
  labs(x = 'NMDS1', y = 'NMDS2', title = '') #+
  #annotate('text', label = paste('Stress =', round(NMDS$stress, 4)), x = 1.0, y = 1.2, size = 4, colour = 'black') #+
  #annotate('text', label = 'Molukkenpad', x = -0.8, y = 0.75, size = 5, colour = 'black') +
  #annotate('text', label = 'Vismarkt', x = 0.8, y = 0.75, size = 5, colour = 'black')+
  #annotate('text', label = 'Noorderplantsoen', x = 0.8, y = -0.75, size = 5, colour = 'black')
p
ggsave(filename = "NMDS_its2_location_MDS1_MDS2_family.pdf", device="pdf", width=6, height=6)

p2 <- ggplot(data = nmds_otu_site, aes(MDS2, MDS3)) +
  stat_ellipse(aes(fill = Location), geom = 'polygon', level = 0.95, alpha = 0.1, show.legend = FALSE) +
  geom_point(aes(color = Location)) +
  scale_color_manual(values = colslocal) +
  scale_fill_manual(values = colslocal) +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_rect(color = 'black', fill = 'transparent'),
        plot.title = element_text(hjust = 0.5),
        legend.position = 'none',
        axis.line = element_line(color = "gray")) +
  geom_vline(xintercept = 0, color = 'gray', size = 0.5) +
  geom_hline(yintercept = 0, color = 'gray', size = 0.5) +
  labs(x = 'NMDS2', y = 'NMDS3', title = '') #+
  #annotate('text', label = paste('Stress =', round(NMDS$stress, 4)), x = 0.75, y = 1.2, size = 4, colour = 'black') #+
  #annotate('text', label = 'Molukkenpad', x = -0.8, y = 0.75, size = 5, colour = 'black') +
  #annotate('text', label = 'Vismarkt', x = 0.8, y = 0.75, size = 5, colour = 'black')+
  #annotate('text', label = 'Noorderplantsoen', x = 0.8, y = -0.75, size = 5, colour = 'black')
p2
ggsave(filename = "NMDS_its2_location_MDS2_MDS3_family.pdf", device="pdf", width=6, height=6)

p3 <- ggplot(data = nmds_otu_site, aes(MDS1, MDS3)) +
  stat_ellipse(aes(fill = Location), geom = 'polygon', level = 0.95, alpha = 0.1, show.legend = FALSE) +
  geom_point(aes(color = Location)) +
  scale_color_manual(values = colslocal, labels = c("MOLUKKENPAD"="Molukkenpad", "NOORDERPLANTSOEN"="Noorderplantsoen","VISMARKT"="Vismarkt")) +
  scale_fill_manual(values = colslocal, labels = c("MOLUKKENPAD"="Molukkenpad", "NOORDERPLANTSOEN"="Noorderplantsoen","VISMARKT"="Vismarkt")) +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_rect(color = 'black', fill = 'transparent'),
        plot.title = element_text(hjust = 0.5),
        legend.position = 'right',
        axis.line = element_line(color = "gray")) +
  geom_vline(xintercept = 0, color = 'gray', size = 0.5) +
  geom_hline(yintercept = 0, color = 'gray', size = 0.5) +
  #geom_text(data = species_top10, aes(label = name), color = 'blue', size = 3) +
  labs(x = 'NMDS1', y = 'NMDS3', title = '') #+
#annotate('text', label = paste('Stress =', round(NMDS$stress, 4)), x = 0.75, y = 1.2, size = 4, colour = 'black') #+
#annotate('text', label = 'Molukkenpad', x = -0.8, y = 0.75, size = 5, colour = 'black') +
#annotate('text', label = 'Vismarkt', x = 0.8, y = 0.75, size = 5, colour = 'black')+
#annotate('text', label = 'Noorderplantsoen', x = 0.8, y = -0.75, size = 5, colour = 'black')
p3
ggsave(filename = "NMDS_its2_location_MDS1_MDS3_family.pdf", device="pdf", width=8, height=6)


#####genus level
its2_Abundance_MOTU_merged_genus
its2_Abundance_MOTU_merged_genus <- as(its2_Abundance_MOTU_merged_genus, "matrix")
metadata_its2_physeq_clean_min2_pinstrep_2<-metadata_its2_physeq_clean_min2_pinstrep
metadata_its2_physeq_clean_min2_pinstrep_2$Sample<-rownames(metadata_its2_physeq_clean_min2_pinstrep_2)
its2_merged_genus<- merge(its2_Abundance_MOTU_merged_genus,metadata_its2_physeq_clean_min2_pinstrep_2,by="Sample")
write.csv(its2_merged_genus, file='its2_merged_genus.csv')
write.xlsx(its2_merged_genus, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "its2_merged_genus.xlsx"))
its2_merged_genus<-as.data.frame(its2_merged_genus)
its2_merged_genus_remove_unknown <- its2_merged_genus %>%
  group_by(Sample, genus) %>%
  filter(!is.na(genus) & nchar(genus) > 0) %>%
  ungroup()
write.csv(its2_merged_genus_remove_unknown, file='its2_merged_genus_remove_unknown.csv')
write.xlsx(its2_merged_genus_remove_unknown, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "its2_merged_genus_remove_unknown.xlsx"))

its2_NMDS_genus <- read.table("its2_NMDS_genus.txt", header=TRUE, sep="\t", na.strings="NA", dec=".", strip.white=TRUE)
row.names(its2_NMDS_genus)<-its2_NMDS_genus$Sample

its2_NMDS_genus <- its2_NMDS_genus %>%
  mutate(across(5:102, ~ ifelse(. > 0, 1, 0)))

write.csv(its2_NMDS_genus, file='its2_NMDS_genus_PA.csv')
write.xlsx(its2_NMDS_genus, file = file.path("D:/pigeon/metabarcoding/pigeondata/analyist_Plant", "its2_NMDS_genus_PA.xlsx"))

data_1 <- its2_NMDS_genus[,5:102]
data_2 <- its2_NMDS_genus[,1:4]
data_2$Taxa <-as.factor(data_2$Taxa)
data_2$Season <-as.factor(data_2$Season)
data_2$Location <-as.factor(data_2$Location)
levels(data_2$Season)
levels(data_2$Location)

NMDS<-metaMDS(data_1, distance = "jaccard", k=3)
NMDS

# Stress:     0.192012

# A good rule of thumb: stress < 0.05 provides an excellent representation
# in reduced dimensions, < 0.1 is great, < 0.2 is good/ok, and stress < 0.3
# provides a poor representation.** To reiterate: high stress is bad,
# low stress is good!

stressplot(NMDS)
plot(NMDS)
NMDS$points

nmds_otu_site<-data.frame(NMDS$points)
write.table(nmds_otu_site,'nmds_otu_site.txt',sep='\t',col.names=NA,quote=FALSE)

nmds_otu_species<-data.frame(NMDS$species)
write.table(nmds_otu_species,'nmds_otu_species.txt',sep='\t',col.names=NA,quote=FALSE)

colsSeason <- c("#DA5724","#508578")
colslocal <- c("darkseagreen", "darkgreen","saddlebrown")

shape=c(19) # Bsp 16=filled circle, 1=empty circle

#season
plot (NMDS$points, col=colsSeason[data_2$Season], cex=1, main="Diet composition", pch=shape[data_2$Taxa],

      xlab="NMDS1", ylab="NMDS2",xlim=c(-1.0,1.0),ylim=c(-1.0,1.5), cex.main=1.3)

orditorp(NMDS,display="species",col="black",air=0.5, cex=0.8)

ordispider(NMDS,groups=data_2$Species,col=colsSeason, label=FALSE)

ordiellipse(NMDS,groups=data_2$Species, display = "sites", col=colsSeason,

            kind = "se", conf = 0.95, label = FALSE, lwd=3)

fit<-adonis2 (data_1~Season, data=data_2, permutations=999, method="jaccard", by = "term")
fit
#         Df SumOfSqs     R2      F Pr(>F)
#Season    1   0.4858 0.02048 1.2753  0.139
#Residual 61  23.2378 0.97952
#Total    62  23.7236 1.00000
nmds<-NMDS$points

#Group
nmds_otu_site$name <- rownames(nmds_otu_site)
nmds_otu_site$Season <- data_2$Season
nmds_otu_site$Location <- data_2$Location

p <- ggplot(data = nmds_otu_site, aes(MDS1, MDS2)) +
  stat_ellipse(aes(fill = Season), geom = 'polygon', level = 0.95, alpha = 0.1, show.legend = FALSE) +
  geom_point(aes(color = Season)) +
  scale_color_manual(values = colsSeason) +
  scale_fill_manual(values = colsSeason) +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_rect(color = 'black', fill = 'transparent'),
        plot.title = element_text(hjust = 0.5),
        legend.position = 'none',
        axis.line = element_line(color = "gray")) +
  geom_vline(xintercept = 0, color = 'gray', size = 0.5) +
  geom_hline(yintercept = 0, color = 'gray', size = 0.5) +
  labs(x = 'NMDS1', y = 'NMDS2', title = '') #+
#annotate('text', label = paste('Stress =', round(NMDS$stress, 4)), x = 0.85, y = 1.0, size = 4, colour = 'black')
p
ggsave(filename = "NMDS_its2_season_MDS1_MDS2_genus.pdf", device="pdf", width=6, height=6)

p2 <- ggplot(data = nmds_otu_site, aes(MDS2, MDS3)) +
  stat_ellipse(aes(fill = Season), geom = 'polygon', level = 0.95, alpha = 0.1, show.legend = FALSE) +
  geom_point(aes(color = Season)) +
  scale_color_manual(values = colsSeason) +
  scale_fill_manual(values = colsSeason) +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_rect(color = 'black', fill = 'transparent'),
        plot.title = element_text(hjust = 0.5),
        legend.position = 'none',
        axis.line = element_line(color = "gray")) +
  geom_vline(xintercept = 0, color = 'gray', size = 0.5) +
  geom_hline(yintercept = 0, color = 'gray', size = 0.5) +
  #geom_text(data = species_top10, aes(label = name), color = 'blue', size = 3) +
  labs(x = 'NMDS2', y = 'NMDS3', title = '') #+
#annotate('text', label = paste('Stress =', round(NMDS$stress, 4)), x = 0.70, y = 1.0, size = 4, colour = 'black') #+
#annotate('text', label = 'Summer', x = -0.8, y = -0.75, size = 5, colour = 'black') +
#annotate('text', label = 'Winter', x = 0.8, y = 0.75, size = 5, colour = 'black')
p2
ggsave(filename = "NMDS_its2_season_MDS2_MDS3_genus.pdf", device="pdf", width=6, height=6)

p3 <- ggplot(data = nmds_otu_site, aes(MDS1, MDS3)) +
  stat_ellipse(aes(fill = Season), geom = 'polygon', level = 0.95, alpha = 0.1, show.legend = FALSE) +
  geom_point(aes(color = Season)) +
  scale_color_manual(values = colsSeason,labels = c("SUMMER"="Summer", "WINTER"="Winter")) +
  scale_fill_manual(values = colsSeason,labels = c("SUMMER"="Summer", "WINTER"="Winter")) +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_rect(color = 'black', fill = 'transparent'),
        plot.title = element_text(hjust = 0.5),
        legend.position = 'right',
        axis.line = element_line(color = "gray")) +
  geom_vline(xintercept = 0, color = 'gray', size = 0.5) +
  geom_hline(yintercept = 0, color = 'gray', size = 0.5) +
  #geom_text(data = species_top10, aes(label = name), color = 'blue', size = 3) +
  labs(x = 'NMDS1', y = 'NMDS3', title = '') #+
#annotate('text', label = paste('Stress =', round(NMDS$stress, 4)), x = 0.75, y = 1.0, size = 4, colour = 'black') #+
#annotate('text', label = 'Summer', x = -0.8, y = -0.75, size = 5, colour = 'black') +
#annotate('text', label = 'Winter', x = 0.8, y = 0.75, size = 5, colour = 'black')
p3
ggsave(filename = "NMDS_its2_season_MDS1_MDS3_genus.pdf", device="pdf", width=8, height=6)

#location
plot (NMDS$points, col=colsloca[data_2$Location], cex=1, main="Diet composition", pch=shape[data_2$Taxa],

      xlab="NMDS1", ylab="NMDS2",xlim=c(-1.2,1.0),ylim=c(-1.0,1.5), cex.main=1.3)

orditorp(NMDS,display="species",col="black",air=0.5, cex=0.8)

fit<-adonis2 (data_1~Location, data=data_2, permutations=999, method="jaccard", by = "term")
fit
#         Df SumOfSqs      R2      F Pr(>F)
#Location  2   1.2778 0.05386 1.7079  0.001 ***
#Residual 60  22.4458 0.94614
#Total    62  23.7236 1.00000
summary(fit)

#devtools::install_github("pmartinezarbizu/pairwiseAdonis/pairwiseAdonis", force = TRUE)

library(pairwiseAdonis)
dune.pairwise.adonis <- pairwise.adonis(x=data_1, factors=data_2$Location,
                                        sim.function = "vegdist",
                                        sim.method = "jaccard",
                                        p.adjust.m = "BH",
                                        reduce = NULL,
                                        perm = 999)

dune.pairwise.adonis
#                            pairs Df SumsOfSqs  F.Model         R2 p.value p.adjusted
#1 MOLUKKENPAD vs NOORDERPLANTSOEN  1 0.7828749 2.152891 0.04379988   0.002     0.0060   *
#2         MOLUKKENPAD vs VISMARKT  1 0.5351752 1.387730 0.03813731   0.069     0.0690
#3    NOORDERPLANTSOEN vs VISMARKT  1 0.5585383 1.483925 0.03758303   0.035     0.0525

p <- ggplot(data = nmds_otu_site, aes(MDS1, MDS2)) +
  stat_ellipse(aes(fill = Location), geom = 'polygon', level = 0.95, alpha = 0.1, show.legend = FALSE) +
  geom_point(aes(color = Location)) +
  scale_color_manual(values = colslocal) +
  scale_fill_manual(values = colslocal) +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_rect(color = 'black', fill = 'transparent'),
        plot.title = element_text(hjust = 0.5),
        legend.position = 'none',
        axis.line = element_line(color = "gray")) +
  geom_vline(xintercept = 0, color = 'gray', size = 0.5) +
  geom_hline(yintercept = 0, color = 'gray', size = 0.5) +
  labs(x = 'NMDS1', y = 'NMDS2', title = '') #+
#annotate('text', label = paste('Stress =', round(NMDS$stress, 4)), x = 1.0, y = 1.2, size = 4, colour = 'black') #+
#annotate('text', label = 'Molukkenpad', x = -0.8, y = 0.75, size = 5, colour = 'black') +
#annotate('text', label = 'Vismarkt', x = 0.8, y = 0.75, size = 5, colour = 'black')+
#annotate('text', label = 'Noorderplantsoen', x = 0.8, y = -0.75, size = 5, colour = 'black')
p
ggsave(filename = "NMDS_its2_location_MDS1_MDS2_genus.pdf", device="pdf", width=6, height=6)

p2 <- ggplot(data = nmds_otu_site, aes(MDS2, MDS3)) +
  stat_ellipse(aes(fill = Location), geom = 'polygon', level = 0.95, alpha = 0.1, show.legend = FALSE) +
  geom_point(aes(color = Location)) +
  scale_color_manual(values = colslocal) +
  scale_fill_manual(values = colslocal) +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_rect(color = 'black', fill = 'transparent'),
        plot.title = element_text(hjust = 0.5),
        legend.position = 'none',
        axis.line = element_line(color = "gray")) +
  geom_vline(xintercept = 0, color = 'gray', size = 0.5) +
  geom_hline(yintercept = 0, color = 'gray', size = 0.5) +
  labs(x = 'NMDS2', y = 'NMDS3', title = '') #+
#annotate('text', label = paste('Stress =', round(NMDS$stress, 4)), x = 0.75, y = 1.2, size = 4, colour = 'black') #+
#annotate('text', label = 'Molukkenpad', x = -0.8, y = 0.75, size = 5, colour = 'black') +
#annotate('text', label = 'Vismarkt', x = 0.8, y = 0.75, size = 5, colour = 'black')+
#annotate('text', label = 'Noorderplantsoen', x = 0.8, y = -0.75, size = 5, colour = 'black')
p2
ggsave(filename = "NMDS_its2_location_MDS2_MDS3_genus.pdf", device="pdf", width=6, height=6)

p3 <- ggplot(data = nmds_otu_site, aes(MDS1, MDS3)) +
  stat_ellipse(aes(fill = Location), geom = 'polygon', level = 0.95, alpha = 0.1, show.legend = FALSE) +
  geom_point(aes(color = Location)) +
  scale_color_manual(values = colslocal, labels = c("MOLUKKENPAD"="Molukkenpad", "NOORDERPLANTSOEN"="Noorderplantsoen","VISMARKT"="Vismarkt")) +
  scale_fill_manual(values = colslocal, labels = c("MOLUKKENPAD"="Molukkenpad", "NOORDERPLANTSOEN"="Noorderplantsoen","VISMARKT"="Vismarkt")) +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.background = element_rect(color = 'black', fill = 'transparent'),
        plot.title = element_text(hjust = 0.5),
        legend.position = 'right',
        axis.line = element_line(color = "gray")) +
  geom_vline(xintercept = 0, color = 'gray', size = 0.5) +
  geom_hline(yintercept = 0, color = 'gray', size = 0.5) +
  #geom_text(data = species_top10, aes(label = name), color = 'blue', size = 3) +
  labs(x = 'NMDS1', y = 'NMDS3', title = '') #+
#annotate('text', label = paste('Stress =', round(NMDS$stress, 4)), x = 0.75, y = 1.2, size = 4, colour = 'black') #+
#annotate('text', label = 'Molukkenpad', x = -0.8, y = 0.75, size = 5, colour = 'black') +
#annotate('text', label = 'Vismarkt', x = 0.8, y = 0.75, size = 5, colour = 'black')+
#annotate('text', label = 'Noorderplantsoen', x = 0.8, y = -0.75, size = 5, colour = 'black')
p3
ggsave(filename = "NMDS_its2_location_MDS1_MDS3_genus.pdf", device="pdf", width=8, height=6)






