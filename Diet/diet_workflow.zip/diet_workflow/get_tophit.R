## Function to set and rank identity intervals

get_tophit <- function(df) {
  
  # Is only a single asv_id supplied?
  # If not, return an error
  if (length(unique(df$asv_id)) > 1) return(NA)
  
  

  # df <- tibble(asv_id, identity.min, identity.max) |> 
  df <- df |> 
     # Set identity interval
     # If there is no interval (identity.min == identity.max), set identity.max to NA
     mutate(identity.max = ifelse(identity.min == identity.max, NA, identity.max)) |> 
     mutate(identity.iv = iv(identity.min, identity.max)) 
  
  asv.ivs <- iv(df$identity.min, df$identity.max)
  
  # Combine intervals into groups
  iv.groups <- iv_identify_group(df$identity.iv, abutting = FALSE)
  
  # Assign ASVs without an interval to intervals containing the minimum identity
  # If the minimum identity falls inside multiple intervals, create a new interval combining all intervals that contain the minimum identity
  asvs.assigned <- iv_locate_includes(asv.ivs, df$identity.min)
  asvs.assigned$needles <- asv.ivs[asvs.assigned$needles]
  asvs.assigned <- asvs.assigned |> 
    filter(!is.na(haystack)) |> 
    group_by(haystack) |> 
    summarise(identity.iv = iv_span(needles)) |> 
    rename(df.idx = haystack)
  
  # Add missing identity ivs
  df$identity.iv[which(is.na(df$identity.iv))] <- 
    asvs.assigned$identity.iv[match(which(is.na(df$identity.iv)), asvs.assigned$df.idx)]

  
  # Find overlaps in the intervals
  # If there are overlaps, combine overlapping intervals
  iv.overlaps <- iv_locate_overlaps(df$identity.iv, df$identity.iv)
  iv.overlaps$haystack <- df$identity.iv[iv.overlaps$haystack]
  iv.overlaps <- iv.overlaps |> 
    group_by(needles) |> 
    summarise(identity.iv.wide = iv_span(haystack)) |> 
    rename(df.idx = needles)

  # Add combined ranges
  df$identity.iv.wide <- 
    iv.overlaps$identity.iv.wide[match(1:nrow(df), iv.overlaps$df.idx)]
  
  
  # Finally, add interval to ASVs without an interval that fall outside existing intervals
  # Split the interval between 0 and 100 (bounds in identity) in detected intervals and regions between intervals
  # Add ASVs not yet assigned to an inteval to the splitted interval
  # If there are multiple ASVs in between the same intervals, split that region based on the boundaries of the ASVs
  all.ivs <- iv_diff(sort(unique(c(0, df$identity.min, df$identity.max, 100)), na.last = NA))
  # Lines below work assign ASVs within the same region between intervals to the same interval instead of to unique intervals
  #all.ivs <- c(df$identity.iv.wide, iv(0,100)) |> 
  #  na.omit() |> 
  #  iv_splits()
  # iv_set_compliment may also work here
  asvs.assigned.splits <- iv_locate_includes(all.ivs, df$identity.min)
  asvs.assigned.splits$needles <- all.ivs[asvs.assigned.splits$needles]
  asvs.assigned.splits <- asvs.assigned.splits |> 
    filter(!is.na(haystack)) |> 
    group_by(haystack) |> 
    summarise(identity.iv.wide = iv_span(needles)) |> 
    rename(df.idx = haystack)
  
  # Add missing identity ivs
  df$identity.iv.wide[which(is.na(df$identity.iv.wide))] <- 
    asvs.assigned.splits$identity.iv.wide[match(which(is.na(df$identity.iv.wide)), asvs.assigned.splits$df.idx)]
  
  ## Rank, highest interval gets rank 1
  ## If there are still NA, those get a rank at the end
  ## Ties get the same rank
  df <- df |> 
    mutate(iv.rank = rank(identity.iv.wide, ties.method = "min", na.last = FALSE)) |> 
    mutate(iv.rank = rank(-iv.rank, ties.method = "min"))

  return(df)

}
