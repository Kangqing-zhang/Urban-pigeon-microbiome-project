#!/bin/bash
#SBATCH --job-name=202402-asvs
#SBATCH --output=202402-01-asvs-%j.log
#SBATCH --time=10:00:00
#SBATCH --mem=4000
#SBATCH --ntasks=1
#SBATCH --partition=regular

# Set directory
cd /scratch/p314509/metabarcoding/

# Make usearch executable
chmod +x ./usearch11.0.667

# Load cutadapt software
module purge
module load cutadapt/4.4-GCCcore-12.2.0

## Cluster reads in ASVs, seperately for COI and its2 loci

# Merge paired reads
mkdir 02-filtered_reads
./usearch11.0.667 -fastq_mergepairs 01-raw_reads/*_R1_*.fastq -fastqout 02-filtered_reads/01-merged_reads.fastq -relabel @

# Cut primers using cutadapt (also possible in usearch, with -search_pcr2
cutadapt -g GGWACWGGWTGAACWGTWTAYCCYCC...TGRTTYTTYGGNCAYCCNGARGTNTA -o "02-filtered_reads/02-merged_reads_trimmed-coi.fastq" 02-filtered_reads/01-merged_reads.fastq -e 0 --discard-untrimmed
cutadapt -g TGTGAATTGCARRATYCMG...GHGACCYCARRTCARDCGGG -o "02-filtered_reads/02-merged_reads_trimmed-its2.fastq" 02-filtered_reads/01-merged_reads.fastq -e 0 --discard-untrimmed

# Filter reads
# For COI, remove short sequences, keep short sequences for its2
./usearch11.0.667 -fastq_filter 02-filtered_reads/02-merged_reads_trimmed-coi.fastq -fastq_minlen 220 -fastq_maxee 0.4 -fastaout 02-filtered_reads/03-filtered_reads_coi.fasta
./usearch11.0.667 -fastq_filter 02-filtered_reads/02-merged_reads_trimmed-its2.fastq -fastq_maxee 0.4 -fastaout 02-filtered_reads/03-filtered_reads_its2.fasta

# Dereplicate reads 
./usearch11.0.667 -fastx_uniques 02-filtered_reads/03-filtered_reads_coi.fasta -strand both -fastaout 02-filtered_reads/04-filtered_derep_reads_coi.fasta -sizeout -relabel coi
./usearch11.0.667 -fastx_uniques 02-filtered_reads/03-filtered_reads_its2.fasta -strand both -fastaout 02-filtered_reads/04-filtered_derep_reads_its2.fasta -sizeout -relabel its2

# Sort by size
./usearch11.0.667 -sortbysize 02-filtered_reads/04-filtered_derep_reads_coi.fasta -fastaout 02-filtered_reads/05-filtered_derep_reads_sing_coi.fasta -minsize 2
./usearch11.0.667 -sortbysize 02-filtered_reads/04-filtered_derep_reads_its2.fasta -fastaout 02-filtered_reads/05-filtered_derep_reads_sing_its2.fasta -minsize 2

# Cluster ASVs in ASV database
mkdir 03-asvs
./usearch11.0.667 -unoise3 02-filtered_reads/05-filtered_derep_reads_sing_coi.fasta -zotus 03-asvs/asv_coi_db-20240705.fa -minsize 4
./usearch11.0.667 -unoise3 02-filtered_reads/05-filtered_derep_reads_sing_its2.fasta -zotus 03-asvs/asv_its2_db-20240705.fa -minsize 4

# Find ASVs in reads to generate ASV table
./usearch11.0.667 -otutab 02-filtered_reads/03-filtered_reads_coi.fasta -otus 03-asvs/asv_coi_db-20240705.fa -otutabout 03-asvs/asv_tab_coi-97-20240705.txt -id 0.97 \
-strand both -mapout 03-asvs/asv_map_coi-97-20240705.txt -notmatched 03-asvs/unmapped_coi-97-20240705.fa
./usearch11.0.667 -otutab 02-filtered_reads/03-filtered_reads_coi.fasta -otus 03-asvs/asv_coi_db-20240705.fa -otutabout 03-asvs/asv_tab_coi-100-20240705.txt -id 1.00 \
-strand both -mapout 03-asvs/asv_map_coi-100-20240705.txt -notmatched 03-asvs/unmapped_coi-100-20240705.fa

./usearch11.0.667 -otutab 02-filtered_reads/03-filtered_reads_its2.fasta -otus 03-asvs/asv_its2_db-20240705.fa -otutabout 03-asvs/asv_tab_its2-97-20240705.txt -id 0.97 \
-strand both -mapout 03-asvs/asv_map_its2-97-20240705.txt -notmatched 03-asvs/unmapped_its2-97-20240705.fa
./usearch11.0.667 -otutab 02-filtered_reads/03-filtered_reads_its2.fasta -otus 03-asvs/asv_its2_db-20240705.fa -otutabout 03-asvs/asv_tab_its2-100-20240705.txt -id 1.00 \
-strand both -mapout 03-asvs/asv_map_its2-100-20240705.txt -notmatched 03-asvs/unmapped_its2-100-20240705.fa

