agreement.tophit <- function(df) {
  df$flag <- NA
  if (length(unique(na.omit(df$species))) == 1 &
      length(unique(na.omit(df$genus))) == 1 &
      length(unique(na.omit(df$family))) == 1 &
      length(unique(na.omit(df$order))) == 1 &
      length(unique(na.omit(df$class))) == 1 &
      length(unique(na.omit(df$phylum))) == 1 &
      length(unique(na.omit(df$kingdom))) == 1) {
    # Check immediately length of non-nas, to deal with Zotu954
    df$species <- unique(na.omit(df$species))
    df$genus <- unique(na.omit(df$genus))
    df$family <- unique(na.omit(df$family))
    df$order <- unique(na.omit(df$order))
    df$class <- unique(na.omit(df$class))
    df$phylum <- unique(na.omit(df$phylum))
    df$kingdom <- unique(na.omit(df$kingdom))
    df$lca_rank <- "species"
    df$lca_taxon <- unique(na.omit(df$species))
    df$lca_level <- 7
  } else if (length(unique(na.omit(df$genus))) == 1 &
             length(unique(na.omit(df$family))) == 1 &
             length(unique(na.omit(df$order))) == 1 &
             length(unique(na.omit(df$class))) == 1 &
             length(unique(na.omit(df$phylum))) == 1 &
             length(unique(na.omit(df$kingdom))) == 1) {
    df$species <- NA
    df$genus <- unique(na.omit(df$genus))
    df$family <- unique(na.omit(df$family))
    df$order <- unique(na.omit(df$order))
    df$class <- unique(na.omit(df$class))
    df$phylum <- unique(na.omit(df$phylum))
    df$kingdom <- unique(na.omit(df$kingdom))
    df$lca_rank <- "genus"
    df$lca_taxon <- unique(na.omit(df$genus))
    df$lca_level <- 6
  } else if (length(unique(na.omit(df$family))) == 1 &
             length(unique(na.omit(df$order))) == 1 &
             length(unique(na.omit(df$class))) == 1 &
             length(unique(na.omit(df$phylum))) == 1 &
             length(unique(na.omit(df$kingdom))) == 1) {
    df$species <- NA
    df$genus <- NA
    df$family <- unique(na.omit(df$family))
    df$order <- unique(na.omit(df$order))
    df$class <- unique(na.omit(df$class))
    df$phylum <- unique(na.omit(df$phylum))
    df$kingdom <- unique(na.omit(df$kingdom))
    df$lca_rank <- "family"
    df$lca_taxon <- unique(na.omit(df$family))
    df$lca_level <- 5
  } else if (length(unique(na.omit(df$order))) == 1 &
             length(unique(na.omit(df$class))) == 1 &
             length(unique(na.omit(df$phylum))) == 1 &
             length(unique(na.omit(df$kingdom))) == 1) {
    df$species <- NA
    df$genus <- NA
    df$family <- NA
    df$order <- unique(na.omit(df$order))
    df$class <- unique(na.omit(df$class))
    df$phylum <- unique(na.omit(df$phylum))
    df$kingdom <- unique(na.omit(df$kingdom))
    df$lca_rank <- "order"
    df$lca_taxon <- unique(na.omit(df$order))
    if (all(df$method == "top hit")) df$flag <- "low_agreement"
    df$lca_level <- 4
  } else if (length(unique(na.omit(df$class))) == 1 &
             length(unique(na.omit(df$phylum))) == 1 &
             length(unique(na.omit(df$kingdom))) == 1) {
    df$species <- NA
    df$genus <- NA
    df$family <- NA
    df$order <- NA
    df$class <- unique(na.omit(df$class))
    df$phylum <- unique(na.omit(df$phylum))
    df$kingdom <- unique(na.omit(df$kingdom))
    df$lca_rank <- "class"
    df$lca_taxon <- unique(na.omit(df$class))
    if (all(df$method == "top hit")) df$flag <- "low_agreement"
    df$lca_level <- 3
  } else if (length(unique(na.omit(df$phylum))) == 1 &
             length(unique(na.omit(df$kingdom))) == 1) {
    df$species <- NA
    df$genus <- NA
    df$family <- NA
    df$order <- NA
    df$class <- NA
    df$phylum <- unique(na.omit(df$phylum))
    df$kingdom <- unique(na.omit(df$kingdom))
    df$lca_rank <- "phylum"
    df$lca_taxon <- unique(na.omit(df$phylum))
    if (all(df$method == "top hit")) df$flag <- "low_agreement"
    df$lca_level <- 2
  } else if (length(unique(na.omit(df$kingdom))) == 1) {
    df$species <- NA
    df$genus <- NA
    df$family <- NA
    df$order <- NA
    df$class <- NA
    df$phylum <- NA
    df$kingdom <- unique(na.omit(df$kingdom))
    df$lca_rank <- "kingdom"
    df$lca_taxon <- unique(na.omit(df$kingdom))
    if (all(df$method == "top hit")) df$flag <- "low_agreement"
    df$lca_level <- 1
  } else {
    df$species <- NA
    df$genus <- NA
    df$family <- NA
    df$order <- NA
    df$class <- NA
    df$phylum <- NA
    df$kingdom <- NA
    df$lca_rank <- "no identification"
    df$lca_taxon <- NA
    df$lca_level <- -1
    if (all(df$method == "top hit")) df$flag <- "low_agreement"
  }
  df <- df |> 
    group_by(asv_id, reference_db, lca_rank, lca_taxon, method, kingdom, phylum, class, order, family, genus, species, lca_level, flag) |> 
    summarise(identity.min = min(identity.min),
              identity.max = max(identity.max),
              coverage.min = min(coverage.min),
              coverage.max = max(coverage.max),
              n = sum(n)) |> 
    distinct() |> 
    group_by(asv_id, reference_db)
  return(df)
}
