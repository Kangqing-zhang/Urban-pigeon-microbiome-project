#!/bin/bash
#SBATCH --job-name=godwit_taxonmatcher
#SBATCH --time=48:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=12
#SBATCH --mem=16G
#SBATCH --output=godwit_taxonmatcher-%j.log

# Load python virtual environment
source /scratch/hb-conseco_lab/python_venvs/venv_metabarcoding/bin/activate

# Set directory
cd /scratch/p314509/metabarcoding/
mkdir 06-taxonmatcher

# Setup Dutch species reference database as explained here: https://github.com/naturalis/galaxy-tool-taxonmatcher (already done on shared Habrok drive)

# Get unique taxa from lca outputs
python3 get_unique_taxa.py

# Run taxonmatcher on unique taxa in bold and genbank lca outputs
python3 /scratch/hb-conseco_lab/tools/galaxy-tool-taxonmatcher/taxonmatcherV2_multicore.py -i 06-taxonmatcher/unique_taxa_coi_bold.txt -n /scratch/hb-conseco_lab/tools/galaxy-tool-taxonmatcher/nsr_taxonmatcher -o 06-taxonmatcher/taxonmatcher_coi_bold.out -t blast -r nsr
python3 /scratch/hb-conseco_lab/tools/galaxy-tool-taxonmatcher/taxonmatcherV2_multicore.py -i 06-taxonmatcher/unique_taxa_coi_gb.txt -n /scratch/hb-conseco_lab/tools/galaxy-tool-taxonmatcher/nsr_taxonmatcher -o 06-taxonmatcher/taxonmatcher_coi_gb.out -t blast -r nsr
python3 /scratch/hb-conseco_lab/tools/galaxy-tool-taxonmatcher/taxonmatcherV2_multicore.py -i 06-taxonmatcher/unique_taxa_its2_bold.txt -n /scratch/hb-conseco_lab/tools/galaxy-tool-taxonmatcher/nsr_taxonmatcher -o 06-taxonmatcher/taxonmatcher_its2_bold.out -t blast -r nsr
python3 /scratch/hb-conseco_lab/tools/galaxy-tool-taxonmatcher/taxonmatcherV2_multicore.py -i 06-taxonmatcher/unique_taxa_its2_gb.txt -n /scratch/hb-conseco_lab/tools/galaxy-tool-taxonmatcher/nsr_taxonmatcher -o 06-taxonmatcher/taxonmatcher_its2_gb.out -t blast -r nsr

deactivate
