#!/bin/bash
#SBATCH --job-name=202401-05-blast_trnl_bold
#SBATCH --time=02:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=6G
#SBATCH --output=202401-05-blast_trnl_bold-%j.log

# Load BLAST and python virtual environment
module purge
module load BLAST+/2.14.1-gompi-2023a
source /scratch/hb-conseco_lab/python_venvs/venv_metabarcoding/bin/activate

# Set directory
cd /scratch/p314509/metabarcoding/

# BLAST test fasta file against local nt database
mkdir 04-blast
conseco-blast/conseco-blast.bash -db_source bold -db /scratch/hb-conseco_lab/bold_refdb_20240311/bold_refdb_20240311 -i 03-asvs/asv_its2_db-20240705.fa -blastout 04-blast/blast_its2_bold-20240705.out \
  -o 04-blast/taxonomicassignment_its2_bold-20240705.out


deactivate