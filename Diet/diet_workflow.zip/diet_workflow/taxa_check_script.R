### Check and compare taxonomic assignments
rm(list = ls())
# Set working directory
setwd("D:/pigeon/metabarcoding/pigeondata/taxa_checked")

# Load packages
library(dplyr)
library(stringr)
library(tidyr)
library(ivs)
library(openxlsx)

#Load LCA and BLAST output based on assignments with BOLD and Genbank
bold.taxa_COI <- read.table("lca_coi_bold-20240705.out",sep="\t", dec = ".", header = FALSE, na = c("NA"))  |>
  rename(asv_id = V1,
         lca_rank = V2,
         lca_taxon = V3,
         kingdom = V4,
         phylum = V5,
         class = V6,
         order = V7,
         family = V8,
         genus = V9,
         species = V10,
         method = V11,
         identity = V12,
         coverage = V13) |>
  mutate(reference_db = "bold") |>
  as_tibble() |>
  mutate(identity.min = as.numeric(str_split_fixed(identity, "-", 2)[,1]),
         identity.max = as.numeric(str_split_fixed(identity, "-", 2)[,2]),
         coverage.min = as.numeric(str_split_fixed(coverage, "-", 2)[,1]),
         coverage.max = as.numeric(str_split_fixed(coverage, "-", 2)[,2]),
         n = as.numeric(str_extract(method, "\\d+")))
bold.blast_COI <- read.table("taxonomicassignment_coi_bold-20240705.out", sep="\t", dec = ".") |>
  rename(asv_id = V1,
         subject = V2,
         accession_id = V3,
         taxonomy_id = V4,
         identity = V5,
         coverage = V6,
         evalue = V7,
         bitscore = V8,
         reference_db = V9,
         taxonomy = V10)
gb.taxa_COI <- read.table("lca_coi_gb-20240705.out",sep="\t", dec = ".", header = FALSE, na = c("NA"))  |>
  rename(asv_id = V1,
         lca_rank = V2,
         lca_taxon = V3,
         kingdom = V4,
         phylum = V5,
         class = V6,
         order = V7,
         family = V8,
         genus = V9,
         species = V10,
         method = V11,
         identity = V12,
         coverage = V13) |>
  mutate(reference_db = "genbank") |>
  as_tibble() |>
  mutate(identity.min = as.numeric(str_split_fixed(identity, "-", 2)[,1]),
         identity.max = as.numeric(str_split_fixed(identity, "-", 2)[,2]),
         coverage.min = as.numeric(str_split_fixed(coverage, "-", 2)[,1]),
         coverage.max = as.numeric(str_split_fixed(coverage, "-", 2)[,2]),
         n = as.numeric(str_extract(method, "\\d+")))

gb.blast_COI <- read.table("taxonomicassignment_coi_gb-20240705.out", sep="\t", dec = ".") |>
  rename(asv_id = V1,
         subject = V2,
         accession_id = V3,
         taxonomy_id = V4,
         identity = V5,
         coverage = V6,
         evalue = V7,
         bitscore = V8,
         reference_db = V9,
         taxonomy = V10)

# Add identity & coverage ranges and number of samples to asvs identified based on a lca analysis.
bold.blast_COI <- bold.blast_COI |>
  group_by(asv_id) |>
  filter(bitscore > 0.92*max(bitscore)) |>
  summarise(identity.max = max(identity),
            identity.min = min(identity),
            coverage.max = max(coverage),
            coverage.min = min(coverage),
            n = n()) |>
  filter(asv_id %in% filter(bold.taxa_COI, method == "lca")$asv_id)

gb.blast_COI <- gb.blast_COI |>
  group_by(asv_id) |>
  filter(bitscore > 0.92*max(bitscore)) |>
  summarise(identity.max = max(identity),
            identity.min = min(identity),
            coverage.max = max(coverage),
            coverage.min = min(coverage),
            n = n()) |>
  filter(asv_id %in% filter(gb.taxa_COI, method == "lca")$asv_id)

bold.taxa_COI <- bold.taxa_COI |>
  left_join(bold.blast_COI, by = "asv_id") |>
  mutate(identity.min = coalesce(identity.min.x, identity.min.y),
         identity.max = coalesce(identity.max.x, identity.max.y),
         coverage.min = coalesce(coverage.min.x, coverage.min.y),
         coverage.max = coalesce(coverage.max.x, coverage.max.y),
         n = coalesce(n.x, n.y))|>
  mutate(method = ifelse(str_detect(method, "top hit"), "top hit", method)) |>
  select(-contains(".x"), -contains(".y"), -identity, -coverage)

gb.taxa_COI <- gb.taxa_COI |>
  left_join(gb.blast_COI, by = "asv_id") |>
  mutate(identity.min = coalesce(identity.min.x, identity.min.y),
         identity.max = coalesce(identity.max.x, identity.max.y),
         coverage.min = coalesce(coverage.min.x, coverage.min.y),
         coverage.max = coalesce(coverage.max.x, coverage.max.y),
         n = coalesce(n.x, n.y))|>
  mutate(method = ifelse(str_detect(method, "top hit"), "top hit", method)) |>
  select(-contains(".x"), -contains(".y"), -identity, -coverage)

## Set unknown taxa to NA and fix lca_taxon
fix_taxon <- function(lca_rank, lca_taxon, kingdom, phylum, class, order, family, genus, species) {
  if (is.na(lca_taxon)) {
    if (lca_rank == "species") {
      if (is.na(species)) lca_rank <- "genus"
    }
    if  (lca_rank == "genus") {
      if (is.na(genus)) lca_rank <- "family"
    }
    if  (lca_rank == "family") {
      if (is.na(family)) lca_rank <- "order"
    }
    if  (lca_rank == "order") {
      if (is.na(order)) lca_rank <- "class"
    }
    if  (lca_rank == "class") {
      if (is.na(class)) lca_rank <- "phylum"
    }
    if  (lca_rank == "class") {
      if (is.na(class)) lca_rank <- "phylum"
    }
    if  (lca_rank == "phylum") {
      if (is.na(phylum)) lca_rank <- "kingdom"
    }
    if  (lca_rank == "kingdom") {
      if (is.na(kingdom)) lca_rank <- "no identification"
    }
  }
  return(lca_rank)
}

# Remove environmental samples and fix unidentified species
gb.taxa_COI <- gb.taxa_COI |>
  filter(!str_detect(lca_taxon, "environmental")) |>
  # Assume that taxa with a "." in the name (sp., aff., nr., etc.), or with a number are unknown species
  # Exception: sometimes a species is identified as a species "sensu lato", this identification is informative, but removed at this step
  mutate(across(3:10, ~ ifelse(.x == "no identification" |
                                 str_detect(.x, "unknown") |
                                 str_detect(.x, "\\.") |
                                 str_detect(.x, "\\d") |
                                 str_detect(.x, "endosymbiont"), NA, .x))) |>
  mutate(assign_id = 1:n()) |>
  rowwise() |>
  mutate(lca_rank = fix_taxon(lca_rank, lca_taxon, kingdom, phylum, class, order, family, genus, species)) |>
  pivot_longer(cols = 4:10, names_to = "taxon_level", values_to = "taxon") |>
  group_by(assign_id) |>
  mutate(lca_taxon = ifelse(any(is.na(lca_taxon)), taxon[taxon_level == lca_rank], lca_taxon)) |>
  pivot_wider(names_from = "taxon_level", values_from = "taxon") |>
  ungroup() |>
  select(-assign_id)

bold.taxa_COI <- bold.taxa_COI |>
  filter(!str_detect(lca_taxon, "environmental")) |>
  mutate(across(3:10, ~ ifelse(.x == "no identification" |
                                 str_detect(.x, "unknown") |
                                 str_detect(.x, "\\.") |
                                 str_detect(.x, "\\d") |
                                 str_detect(.x, "endosymbiont"), NA, .x))) |>
  mutate(assign_id = 1:n()) |>
  rowwise() |>
  mutate(lca_rank = fix_taxon(lca_rank, lca_taxon, kingdom, phylum, class, order, family, genus, species)) |>
  pivot_longer(cols = 4:10, names_to = "taxon_level", values_to = "taxon") |>
  group_by(assign_id) |>
  mutate(lca_taxon = ifelse(any(is.na(lca_taxon)), taxon[taxon_level == lca_rank], lca_taxon)) |>
  pivot_wider(names_from = "taxon_level", values_from = "taxon") |>
  ungroup() |>
  select(-assign_id)

## Change taxonomic nomenclature to make genbank and bold comparable
# Change BOLDs Animalia to Metazoa and Plantae to Viridiplantae
# Change Genbanks Oomycota to BOLDs classification
bold.taxa_COI <- bold.taxa_COI |>
  mutate(kingdom = ifelse(kingdom == "Animalia", "Metazoa", kingdom),
         kingdom = ifelse(kingdom == "Plantae", "Viridiplantae", kingdom))
gb.taxa_COI <- gb.taxa_COI |>
  mutate(class = ifelse(phylum == "Oomycota" & !is.na(phylum), "Oomycota", class),
         kingdom = ifelse(phylum == "Oomycota" & !is.na(phylum), "Chromista", kingdom),
         phylum = ifelse(phylum == "Oomycota" & !is.na(phylum), "Heterokontophyta", phylum))

# Some other differences
gb.taxa_COI <- gb.taxa_COI |>
  mutate(family = ifelse(family == "Caeciliusidae", "Paracaeciliidae", family),
         order = ifelse(order == "Psocoptera", "Psocodea", order),
         family = ifelse(family == "Apionidae", "Brentidae", family),
         family = ifelse(family == "Elachistidae", "Geometridae", family))
# How many ASVs are assigned?
length(unique(gb.taxa_COI$asv_id)) #1143 ASVs assigned by genbank
length(unique(bold.taxa_COI$asv_id)) #1041 ASVs assigned by bold

## Summarise asv assignments to one taxon per asv

# Combine bold and genbank assignments in a single table
taxa_COI <- bind_rows(bold.taxa_COI, gb.taxa_COI) |>
  arrange(asv_id) |>
  group_by(asv_id)
# How many ASVs are assigned?
length(unique(taxa_COI$asv_id)) # 1144 ASVs assigned by genbank, bold or both

# Add number for taxonomic rank
taxon.level <- tibble(rank = c("kingdom", "phylum", "class", "order", "family", "genus", "species", "no identification"),
                      lca_level = c(1:7, -1))
taxa_COI <-  taxa_COI |>
  left_join(y = taxon.level, by = c("lca_rank" = "rank"))

#### Option:
#### 0. Nested assignments here!!

### 1. If at least one database identifies an ASV as a top hit or based on an lca analysis to either Wolbachia or Homo, use that assignment
taxa.wolbacha.homo_COI <- taxa_COI |>
  group_by(asv_id) |>
  filter(any(str_detect(genus, "Wolbachia")) | any(str_detect(genus, "Homo")))

summarised.taxa.wolbacha.homo_COI <- taxa.wolbacha.homo_COI |>
  filter(any(str_detect(genus, "Wolbachia")) | any(str_detect(genus, "Homo"))) |>
  filter(genus %in% c("Wolbachia", "Homo")) |>
  # In case of a top hit, pick the best one
  group_by(asv_id, lca_taxon) |>
  mutate(n = sum(n),
         identity.min = min(identity.min),
         identity.max = max(identity.max),
         coverage.min = min(coverage.min),
         coverage.max = max(coverage.max),
         reference_db = str_c(reference_db, collapse = ";")) |>
  distinct() |>
  group_by(asv_id) |>
  arrange(desc(identity.min), desc(coverage.max))|> ##Sort to prioritize hightest identity and coverage
  slice(1) ##pick the top hit per ASV

# Have all these ASVs been summarised into a single taxonomic assignment?
summarised.taxa.wolbacha.homo_COI |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# Ture
nrow(summarised.taxa.wolbacha.homo_COI)
# 21 ASVs have been identified in this way

# Remove summarised taxa from list
taxa.left_COI <- taxa_COI |>
  filter(!(asv_id %in% summarised.taxa.wolbacha.homo_COI$asv_id))

### 1. Select ASVs where both reference databases used an lca analysis for taxonomic assignment
taxa.lca_COI <- taxa.left_COI |>
  filter(all(method == "lca"))

## For which ASVs is there agreement on the assignment?
# This includes ASV that have only been identified in a single database
taxa.lca.agree_COI <- taxa.lca_COI |>
  filter(length(unique(lca_taxon)) == 1)

# Summarise, use genbank taxonomy for summarised assignment

summarised.taxa.lca.agree_COI <- taxa.lca.agree_COI |>
  mutate(n_dbs = length(unique(reference_db))) |>
  mutate(
    n = sum(n),
    identity.min = min(identity.min, na.rm = TRUE),
    identity.max = max(identity.max, na.rm = TRUE),
    coverage.min = min(coverage.min, na.rm = TRUE),
    coverage.max = max(coverage.max, na.rm = TRUE)
  ) |>
  filter(if (all(n_dbs == 2)) reference_db == "genbank" else TRUE) |>
  mutate(reference_db = ifelse(n_dbs == 2, "bold;genbank", reference_db)) |>
  # Use `across()` within `mutate()` to apply the `first` function to all columns
  mutate(across(everything(), first, .names = "{col}"))

problematic_asvs <- summarised.taxa.lca.agree_COI |>
  group_by(asv_id) |>
  summarise(n_assignments = n()) |>
  filter(n_assignments > 1)
print(problematic_asvs)

problematic_asvs_COI <- taxa.lca.agree_COI|>
  filter(asv_id %in% problematic_asvs$asv_id) |>
  arrange(asv_id)

# Force a single taxonomic assignment by selecting the first row for each asv_id
summarised.taxa.lca.agree_COI <- summarised.taxa.lca.agree_COI %>%
  group_by(asv_id) %>%
  slice(1) %>%
  ungroup()

# Have all these ASVs been summarised into a single taxonomic assignment?
summarised.taxa.lca.agree_COI |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# correct
nrow(summarised.taxa.lca.agree_COI)
# 137 ASVs have been identified in this way

taxa.left_COI <- taxa.left_COI |>
  filter(!(asv_id %in% summarised.taxa.lca.agree_COI$asv_id))

# For which taxa is there no agreement on the assignment? 1608
taxa.lca.disagree_COI <- taxa.lca_COI |>
  filter(length(unique(lca_taxon)) > 1)

# Some of this disagreement may be because of differences in the level of taxonomic assignment 1448
taxa.lca.disagree.level_COI <- taxa.lca.disagree_COI |>
  filter(length(unique(lca_level)) > 1)

# Check if there is agreement at higher taxonomic levels
agreement.level <- function(kingdom, phylum, class, order, family, genus, species) {
  if (length(unique(species)) == 1 & !any(is.na(species))) {
    lvl <- 7
  } else if (length(unique(genus)) == 1 & !any(is.na(genus))) {
    lvl <- 6
  } else if (length(unique(family)) == 1 & !any(is.na(family))) {
    lvl <- 5
  } else if (length(unique(order)) == 1 & !any(is.na(order))) {
    lvl <- 4
  } else if (length(unique(class)) == 1 & !any(is.na(class))) {
    lvl <- 3
  } else if (length(unique(phylum)) == 1 & !any(is.na(phylum))) {
    lvl <- 2
  } else if (length(unique(kingdom)) == 1 & !any(is.na(kingdom))) {
    lvl <- 1
  } else lvl <- -1
  return(lvl)
}
# Find the level of agreement
taxa.lca.disagree.level_COI <- taxa.lca.disagree.level_COI |>
  mutate(lvl_agree = agreement.level(kingdom, phylum, class, order, family, genus, species))

# If the level of agreement between bold and genbank corresponds to the lca level of the database that identifies to the higher taxonomic level,
# the databases only disagree on the level of taxonomic assignment, not on the taxonomy itself
# 236
summarised.taxa.lca.disagree.level_COI <- taxa.lca.disagree.level_COI |>
  filter(lvl_agree == min(lca_level)) |>
  mutate(n_dbs = length(unique(reference_db))) |>
  filter(lca_level == max(lca_level))|>
  slice(1)

# Have all these ASVs been summarised into a single taxonomic assignment?
summarised.taxa.lca.disagree.level_COI |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# True
nrow(summarised.taxa.lca.disagree.level_COI)
# 236 ASVs have been identified in this way

# What ASVs are left
taxa.lca.disagree_COI <- taxa.lca.disagree_COI |>
  filter(!(asv_id %in% summarised.taxa.lca.disagree.level_COI$asv_id)) #664
taxa.left_COI <- taxa.left_COI |>
  filter(!(asv_id %in% summarised.taxa.lca.disagree.level_COI$asv_id)) #3652

# For what ASVs does the assignment disagree at the kingdom level?
# This usually means that a hit has the wrong label in the database
# 468
taxa.lca.disagree.kingdom_COI <- taxa.lca.disagree_COI |>
  filter(length(unique(kingdom)) > 1)
####################################################################################
# If BOLD suggests a metazoan assignment and genbank a plant, fungus, algae or unicellular organism, follow Genbank
summarised.taxa.lca.disagree.kingdom_COI <- taxa.lca.disagree.kingdom_COI |>
  filter(asv_id %in% asv_id[reference_db == "bold" & kingdom == "Metazoa"]) |>
  filter(reference_db == "genbank") |>
  mutate(n_dbs = 1)|>
  slice(1)
# What ASVs are left that disagree at the kingdom level?
taxa.lca.disagree.kingdom_COI <- taxa.lca.disagree.kingdom_COI |>
  filter(!(asv_id %in% summarised.taxa.lca.disagree.kingdom_COI$asv_id))
# still have six disagreements on the kingdom level!

# What ASVs are left? #24
taxa.lca.disagree_COI <- taxa.lca.disagree_COI |>
  filter(!(asv_id %in% summarised.taxa.lca.disagree.kingdom_COI$asv_id))
taxa.left_COI <- taxa.left_COI |>
  filter(!(asv_id %in% summarised.taxa.lca.disagree.kingdom_COI$asv_id))

# set zotu489,562,750,972 in bold, because they are show better identifity in bold.
summarised.taxa.lca.disagree.kingdom_COI <- taxa.lca.disagree.kingdom_COI |>
  filter(asv_id %in% asv_id[reference_db == "genbank" & kingdom == "Metazoa"]) |>
  filter(reference_db == "bold") |>
  mutate(n_dbs = 1)|>
  slice(1)

# Have all these ASVs been summarised into a single taxonomic assignment?
summarised.taxa.lca.disagree.kingdom_COI |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# True
nrow(summarised.taxa.lca.disagree.kingdom_COI)
# 4 ASVs have been identified in this way

# What ASVs are left that disagree at the kingdom level? #8
taxa.lca.disagree.kingdom_COI <- taxa.lca.disagree.kingdom_COI |>
  filter(!(asv_id %in% summarised.taxa.lca.disagree.kingdom_COI$asv_id))
# still have 8 disagreements on the kingdom level!

#zotu422 is better in genbank
summarised.taxa.lca.disagree.kingdom_COI <- taxa.lca.disagree.kingdom_COI |>
  filter(asv_id %in% asv_id[reference_db == "bold" & kingdom == "Chromista"]) |>
  filter(reference_db == "genbank") |>
  mutate(n_dbs = 1)|>
  slice(1)

# Have all these ASVs been summarised into a single taxonomic assignment?
summarised.taxa.lca.disagree.kingdom_COI |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# True
nrow(summarised.taxa.lca.disagree.kingdom_COI)
# 1 ASVs have been identified in this way

# What ASVs are left that disagree at the kingdom level? #4
taxa.lca.disagree.kingdom_COI <- taxa.lca.disagree.kingdom_COI |>
  filter(!(asv_id %in% summarised.taxa.lca.disagree.kingdom_COI$asv_id))
# still have 4 disagreements on the kingdom level!

#zotu880 is better in genbank
summarised.taxa.lca.disagree.kingdom_COI <- taxa.lca.disagree.kingdom_COI |>
  filter(asv_id %in% asv_id[reference_db == "bold" & kingdom == "Protozoa"]) |>
  filter(reference_db == "genbank") |>
  mutate(n_dbs = 1)|>
  slice(1)

# Have all these ASVs been summarised into a single taxonomic assignment?
summarised.taxa.lca.disagree.kingdom_COI |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# True
nrow(summarised.taxa.lca.disagree.kingdom_COI)
# 1 ASVs have been identified in this way

# What ASVs are left that disagree at the kingdom level? #0
taxa.lca.disagree.kingdom_COI <- taxa.lca.disagree.kingdom_COI |>
  filter(!(asv_id %in% summarised.taxa.lca.disagree.kingdom_COI$asv_id))
# No disagreement on the kingdom level!

# What ASVs are left?
taxa.lca.disagree_COI <- taxa.lca.disagree_COI |>
  filter(!(asv_id %in% summarised.taxa.lca.disagree.kingdom_COI$asv_id)) #660
taxa.left_COI <- taxa.left_COI |>
  filter(!(asv_id %in% summarised.taxa.lca.disagree.kingdom_COI$asv_id)) #3648

## For all these hits, look at the lowest common ancestor in the taxonomic classification

summarised.taxa.lca.disagree_COI <- taxa.lca.disagree_COI |>
  mutate(lvl_agree = agreement.level(kingdom, phylum, class, order, family, genus, species)) |>
  mutate(assign_id = 1:n()) |>
  rowwise() |>
  pivot_longer(cols = 11:17, names_to = "taxon_level", values_to = "taxon") |>
  left_join(y = rename(taxon.level, rank_level = lca_level), by = c("taxon_level" = "rank")) |>
  # Remove taxonomic levels below the LCA
  mutate(taxon = ifelse(rank_level <= lvl_agree, taxon, NA)) |>
  # Fix lca rank and taxon, selecting the first valid match in case of multiple
  group_by(asv_id, reference_db) |>
  mutate(lca_rank = taxon_level[which.max(lvl_agree == rank_level)],  # Take the first match if there are multiple
         lca_taxon = taxon[which.max(lvl_agree == rank_level)]) |>  # Take the first valid taxon match
  select(-rank_level) |>
  pivot_wider(names_from = "taxon_level", values_from = "taxon") |>
  group_by(asv_id) |>
  select(-assign_id) |>
  # Combine identity and coverage scores, reference dbs, and number of hits
  mutate(n_dbs = n(),
         n = ifelse(lvl_agree %in% lca_level, n, sum(n)),
         identity.min = min(identity.min),
         identity.max = max(identity.max),
         coverage.min = min(coverage.min),
         coverage.max = max(coverage.max),
         reference_db = str_c(reference_db, collapse = ";")) |>
  select(-lca_level) |>
  distinct(asv_id, .keep_all= TRUE)
# Have all these ASVs been summarised into a single taxonomic assignment?
summarised.taxa.lca.disagree_COI |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# True
nrow(summarised.taxa.lca.disagree_COI)
# 54 ASVs have been identified in this way

# What ASVs are left?
taxa.lca.disagree_COI <- taxa.lca.disagree_COI |>
  filter(!(asv_id %in% summarised.taxa.lca.disagree_COI$asv_id))
# None left!
taxa.left_COI <- taxa.left_COI |>
  filter(!(asv_id %in% summarised.taxa.lca.disagree_COI$asv_id)) # 3432
### Check if these are all the taxa

### 2. Taxa with at least one top hit match in one of the databases, and a lca in the other
taxa.toplca_COI <- taxa.left_COI |>
  filter(!all(method == "top hit") & any(method == "top hit"))

# For what ASVs does the assignment disagree at the kingdom level?
# This usually means that a hit has the wrong label in the database
taxa.toplca.disagree.kingdom_COI <- taxa.toplca_COI |>
  filter(length(unique(kingdom)) > 1)

# If BOLD suggests a metazoan assignment and genbank a plant, fungus, algae or unicellular organism, follow Genbank
summarised.taxa.toplca.disagree.kingdom_COI <- taxa.toplca.disagree.kingdom_COI |>
  filter(asv_id %in% asv_id[reference_db == "bold" & kingdom == "Metazoa"]) |>
  filter(reference_db == "genbank") |>
  mutate(n_dbs = 1)|>
  slice(1)
# Have all these ASVs been summarised into a single taxonomic assignment?
summarised.taxa.toplca.disagree.kingdom_COI |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# Correct
nrow(summarised.taxa.toplca.disagree.kingdom_COI)
# 9 ASVs have been identified in this way

# What ASVs are left
taxa.toplca_COI <- taxa.toplca_COI |>
  filter(!(asv_id %in% summarised.taxa.toplca.disagree.kingdom_COI$asv_id)) #310
taxa.left_COI <- taxa.left_COI |>
  filter(!(asv_id %in% summarised.taxa.toplca.disagree.kingdom_COI$asv_id)) #3392

## Summarise the top hits into a single assignment per ASV, and compare with the lca analysis of the other database
# Load function to select best top hit
source("get_tophit.R")
source("agreement_tophit.R")

# Increase the time limit to, 600 seconds
setTimeLimit(cpu = 600, elapsed = 600)

taxa.toplca_COI <- taxa.toplca_COI |>
  # Combine duplicate assignemnts
  group_by(asv_id, reference_db, lca_rank, lca_taxon, method, kingdom, phylum, class, order, family, genus, species, lca_level) |>
  summarise(identity.min = min(identity.min),
            identity.max = max(identity.max),
            coverage.min = min(coverage.min),
            coverage.max = max(coverage.max),
            n = sum(n)) |>
  group_by(asv_id, reference_db)|>
  group_split()

taxa.toplca_COI <- lapply(taxa.toplca_COI, get_tophit) |>
  bind_rows() |>
  # Only keep the best top hit
  filter(iv.rank == 1) |>
  # Get lowest common ancestor if there is still more then a single top hit
  group_by(asv_id, reference_db) |>
  group_split()
taxa.toplca_COI <- lapply(taxa.toplca_COI, agreement.tophit) |>
  bind_rows()

## Check if top hits are nested within the assignment by the lca analysis in the other
summarised.toplca.nested_COI <- taxa.toplca_COI |>
  group_by(asv_id) |>
  mutate(lvl_agree = agreement.level(kingdom, phylum, class, order, family, genus, species)) |>
  filter(lvl_agree %in% lca_level) |>
  filter(method == "top hit")

# Have all these ASVs been summarised into a single taxonomic assignment?
summarised.toplca.nested_COI |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# Correct
nrow(summarised.toplca.nested_COI)
# 40 ASVs have been identified in this way

# What ASVs are left
taxa.toplca_COI <- taxa.toplca_COI |>
  filter(!(asv_id %in% summarised.toplca.nested_COI$asv_id))
# still 42 taxa left

taxa.left_COI <- taxa.left_COI |>
  filter(!(asv_id %in% summarised.toplca.nested_COI$asv_id)) #3206

###################################################################################
left_taxa.toplca_COI<-taxa.toplca_COI

process_remaining_data <- function(df, id_col = "asv_id") {
  df <- df %>%
    group_by(!!sym(id_col)) %>%  # Use the correct id column for grouping
    summarise(
      # Compare each taxonomic level; if values are consistent, return the value, else NA
      kingdom = if_else(length(unique(na.omit(kingdom))) == 1, first(na.omit(kingdom)), NA_character_),
      phylum = if_else(length(unique(na.omit(phylum))) == 1, first(na.omit(phylum)), NA_character_),
      class = if_else(length(unique(na.omit(class))) == 1, first(na.omit(class)), NA_character_),
      order = if_else(length(unique(na.omit(order))) == 1, first(na.omit(order)), NA_character_),
      family = if_else(length(unique(na.omit(family))) == 1, first(na.omit(family)), NA_character_),
      genus = if_else(length(unique(na.omit(genus))) == 1, first(na.omit(genus)), NA_character_),
      species = if_else(length(unique(na.omit(species))) == 1, first(na.omit(species)), NA_character_),

      # Get the first row's values for all other columns
      across(everything(), first, .names = "{col}"),

      # Determine the lowest taxonomic rank with an agreement
      lca_rank = case_when(
        !is.na(species) ~ "species",
        !is.na(genus) ~ "genus",
        !is.na(family) ~ "family",
        !is.na(order) ~ "order",
        !is.na(class) ~ "class",
        !is.na(phylum) ~ "phylum",
        !is.na(kingdom) ~ "kingdom",
        TRUE ~ NA_character_
      ),

      # Assign the corresponding level for lca_rank
      lca_level = case_when(
        !is.na(species) ~ 7,
        !is.na(genus) ~ 6,
        !is.na(family) ~ 5,
        !is.na(order) ~ 4,
        !is.na(class) ~ 3,
        !is.na(phylum) ~ 2,
        !is.na(kingdom) ~ 1,
        TRUE ~ NA_integer_
      ),

      # Get the taxon at the lowest common rank
      lca_taxon = coalesce(species, genus, family, order, class, phylum, kingdom)
    ) %>%
    ungroup()

  return(df)
}

# Apply the function to your remaining dataset with the correct id column
summarised.toplca.nested_COI_left <- process_remaining_data(left_taxa.toplca_COI, id_col = "asv_id")

# What ASVs are left
taxa.toplca_COI <- taxa.toplca_COI |>
  filter(!(asv_id %in% summarised.toplca.nested_COI_left$asv_id))
# no taxa left

taxa.left_COI <- taxa.left_COI |>
  filter(!(asv_id %in% summarised.toplca.nested_COI_left$asv_id)) #3082
####################################################################################
### 3. Taxa with top hits in both databases
taxa.top_COI <- taxa.left_COI |>
  group_by(asv_id) |>
  filter(all(method == "top hit"))

taxa.top_COI <- taxa.top_COI |>
  # Combine duplicate assignemnts
  group_by(asv_id, reference_db, lca_rank, lca_taxon, method, kingdom, phylum, class, order, family, genus, species, lca_level) |>
  summarise(identity.min = min(identity.min),
            identity.max = max(identity.max),
            coverage.min = min(coverage.min),
            coverage.max = max(coverage.max),
            n = sum(n)) |>
  group_by(asv_id) |>
  group_split()

taxa.top_COI <- lapply(taxa.top_COI, get_tophit) |>
  bind_rows() |>
  # Only keep the best top hit
  filter(iv.rank == 1) |>
  # Get lowest common ancestor if there is still more then a single top hit
  group_by(asv_id, reference_db) |>
  group_split()

taxa.top_COI <- lapply(taxa.top_COI, agreement.tophit) |>
  bind_rows()

## Compare the best top hits of both databases
# If nested, follow the database with the identification to the lowest taxonomic level
summarised.taxa.top.nested_COI <- taxa.top_COI |>
  group_by(asv_id) |>
  mutate(lvl_agree = agreement.level(kingdom, phylum, class, order, family, genus, species)) |>
  filter(lvl_agree %in% lca_level) |>
  filter(lca_level == max(lca_level)) |>
  # Combine duplicate hits
  group_by(asv_id, lca_rank, lca_taxon, method, kingdom, phylum, class, order, family, genus, species, lca_level) |>
  summarise(reference_db = str_c(reference_db, collapse = ";"),
            n_dbs = length(unique(reference_db)),
            identity.min = min(identity.min),
            identity.max = max(identity.max),
            coverage.min = min(coverage.min),
            coverage.max = max(coverage.max),
            n = sum(n)) |>
  group_by(asv_id)

# Have all these ASVs been summarised into a single taxonomic assignment?
summarised.taxa.top.nested_COI |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# False
nrow(summarised.taxa.top.nested_COI)
#  174 ASVs have been identified in this way

# Identify ASVs with more than one taxonomic assignment
problematic_asvs_2 <- summarised.taxa.top.nested_COI %>%
  group_by(asv_id) %>%
  summarise(n = n()) %>%
  filter(n > 1)

# View the problematic ASVs
problematic_asvs_2

# Filter and view the rows corresponding to problematic ASVs
problematic_asvs_2_COI<-summarised.taxa.top.nested_COI %>%
  filter(asv_id %in% problematic_asvs_2$asv_id) %>%
  arrange(asv_id)

# Force a single taxonomic assignment by selecting the first row for each asv_id
summarised.taxa.top.nested_COI <- summarised.taxa.top.nested_COI %>%
  group_by(asv_id) %>%
  slice(1) %>%
  ungroup()

# Check if this resolves the issue
summarised.taxa.top.nested_COI %>%
  group_by(asv_id) %>%
  summarise(n = n()) %>%
  filter(n > 1) %>%
  nrow() == 0
nrow(summarised.taxa.top.nested_COI)
#  168 ASVs have been identified in this way

# What ASVs are left
taxa.top_COI <- taxa.top_COI |>
  filter(!(asv_id %in% summarised.taxa.top.nested_COI$asv_id)) #12

taxa.left_COI <- taxa.left_COI |>
  filter(!(asv_id %in% summarised.taxa.top.nested_COI$asv_id)) #1376

### Get the lowest common ancestor for the other asvs
taxa.top.disagreement_COI <- taxa.top_COI |>
  group_by(asv_id) |>
  mutate(reference_db = str_c(reference_db, collapse = ";"),
         n_dbs = length(unique(reference_db)),
         identity.min = min(identity.min),
         identity.max = max(identity.max),
         coverage.min = min(coverage.min),
         coverage.max = max(coverage.max),
         n = sum(n)) |>
  group_split()

summarised.taxa.top.disagreement_COI <- lapply(taxa.top.disagreement_COI, agreement.tophit) |>
  bind_rows()

# Have all these ASVs been summarised into a single taxonomic assignment?
summarised.taxa.top.disagreement_COI |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# Correct
nrow(summarised.taxa.top.disagreement_COI)
# 6 ASVs have been identified in this way

# What ASVs are left
taxa.top_COI <- taxa.top_COI |>
  filter(!(asv_id %in% summarised.taxa.top.disagreement_COI$asv_id))
# No taxa left

taxa.left_COI <- taxa.left_COI |>
  filter(!(asv_id %in% summarised.taxa.top.disagreement_COI$asv_id)) #1330
#####################################################################################
### 4. Taxa that have not been identified in at least one of the reference dbs ("no lca")
taxa.nolca_COI <- taxa.left_COI |>
  filter(any(method == "no lca"))

# No identification in one database: follow the other
summarised.taxa.nolca1_COI <- taxa.nolca_COI |>
  filter(method != "no lca")

# Identify ASVs with more than one taxonomic assignment
# 240
problematic_asvs_3 <- summarised.taxa.nolca1_COI %>%
  group_by(asv_id) %>%
  summarise(n = n()) %>%
  filter(n > 1)

# View the problematic ASVs
problematic_asvs_3

# Filter and view the rows corresponding to problematic ASVs
problematic_asvs_3_COI<-summarised.taxa.nolca1_COI %>%
  filter(asv_id %in% problematic_asvs_3$asv_id) %>%
  arrange(asv_id)

# Force a single taxonomic assignment by selecting the first row for each asv_id
# 240
problematic_asvs_3_COI <- problematic_asvs_3_COI %>%
  group_by(asv_id) %>%
  slice(1) %>%
  ungroup()
# Have all these ASVs been summarised into a single taxonomic assignment?
problematic_asvs_3_COI |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# correct

# Force a single taxonomic assignment by selecting the first row for each asv_id
summarised.taxa.nolca1_COI <- summarised.taxa.nolca1_COI %>%
  group_by(asv_id) %>%
  slice(1) %>%
  ungroup()

# Have all these ASVs been summarised into a single taxonomic assignment?
summarised.taxa.nolca1_COI |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# Correct
nrow(summarised.taxa.nolca1_COI)
# 240 ASVs have been identified in this way

# What ASVs are left?
taxa.nolca_COI <- taxa.nolca_COI |>
  filter(!(asv_id %in% summarised.taxa.nolca1_COI$asv_id)) #370

taxa.left_COI <- taxa.left_COI |>
  filter(!(asv_id %in% summarised.taxa.nolca1_COI$asv_id)) #370

# No identification in both databases
summarised.taxa.noident_COI <- taxa.nolca_COI |>
  filter(all(method == "no lca")) |>
  mutate(reference_db = str_c(reference_db, collapse = ";")) |>
  distinct()

# Have all these ASVs been summarised into a single taxonomic assignment?
summarised.taxa.noident_COI |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# Correct
nrow(summarised.taxa.noident_COI)
# 100 ASVs have been identified in this way


# What ASVs are left?
taxa.nolca_COI <- taxa.nolca_COI |>
  filter(!(asv_id %in% summarised.taxa.noident_COI$asv_id))
# No taxa are left

taxa.left_COI <- taxa.left_COI |>
  filter(!(asv_id %in% summarised.taxa.noident_COI$asv_id))
# No taxa left!

## Combine everything
taxatable_COI <- list(select(summarised.taxa.lca.agree_COI,
                         c(asv_id, lca_rank, lca_taxon, method, reference_db, kingdom, phylum, class, order, family, genus, species)),
                  select(summarised.taxa.lca.disagree_COI,
                         c(asv_id, lca_rank, lca_taxon, method, reference_db, kingdom, phylum, class, order, family, genus, species)),
                  select(summarised.taxa.lca.disagree.kingdom_COI,
                         c(asv_id, lca_rank, lca_taxon, method, reference_db, kingdom, phylum, class, order, family, genus, species)),
                  select(summarised.taxa.lca.disagree.level_COI,
                         c(asv_id, lca_rank, lca_taxon, method, reference_db, kingdom, phylum, class, order, family, genus, species)),
                  select(summarised.taxa.noident_COI,
                         c(asv_id, lca_rank, lca_taxon, method, reference_db, kingdom, phylum, class, order, family, genus, species)),
                  select(summarised.taxa.nolca1_COI,
                         c(asv_id, lca_rank, lca_taxon, method, reference_db, kingdom, phylum, class, order, family, genus, species)),
                  select(summarised.taxa.top.disagreement_COI,
                         c(asv_id, lca_rank, lca_taxon, method, reference_db, kingdom, phylum, class, order, family, genus, species)),
                  select(summarised.taxa.top.nested_COI,
                         c(asv_id, lca_rank, lca_taxon, method, reference_db, kingdom, phylum, class, order, family, genus, species)),

                  select(summarised.taxa.toplca.disagree.kingdom_COI,
                         c(asv_id, lca_rank, lca_taxon, method, reference_db, kingdom, phylum, class, order, family, genus, species)),
                  select(summarised.taxa.wolbacha.homo_COI,
                         c(asv_id, lca_rank, lca_taxon, method, reference_db, kingdom, phylum, class, order, family, genus, species)),
                  select(summarised.toplca.nested_COI,
                         c(asv_id, lca_rank, lca_taxon, method, reference_db, kingdom, phylum, class, order, family, genus, species)),
                  select(summarised.toplca.nested_COI_left,
                         c(asv_id, lca_rank, lca_taxon, method, reference_db, kingdom, phylum, class, order, family, genus, species)))|>
  do.call(what = rbind)

## Final checks: have all ASVs been assigned to a single taxon?
taxatable_COI |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# Correct!

## Are all ASVs included in the taxatable?
sum(!(taxatable_COI$asv_id) %in% unique(taxa_COI$asv_id)) == 0
# Correct!

### Export
write.csv(taxatable_COI, file = "taxatable_COI_20240821.csv", quote = FALSE, row.names = FALSE)

write.xlsx(taxatable_COI, file = file.path("D:/pigeon/metabarcoding/pigeondata/taxa_checked", "taxatable_COI_20240821.xlsx"))

########################Its2#############################Its2##########################Its2#########################################################################
########################Its2#############################Its2##########################Its2#########################################################################
########################Its2#############################Its2##########################Its2#########################################################################
########################Its2#############################Its2##########################Its2#########################################################################

#Load LCA and BLAST output based on assignments with BOLD and Genbank
bold.taxa_its2 <- read.table("lca_its2_bold-20240705.out",sep="\t", dec = ".", header = FALSE, na = c("NA"))  |>
  rename(asv_id = V1,
         lca_rank = V2,
         lca_taxon = V3,
         kingdom = V4,
         phylum = V5,
         class = V6,
         order = V7,
         family = V8,
         genus = V9,
         species = V10,
         method = V11,
         identity = V12,
         coverage = V13) |>
  mutate(reference_db = "bold") |>
  as_tibble() |>
  mutate(identity.min = as.numeric(str_split_fixed(identity, "-", 2)[,1]),
         identity.max = as.numeric(str_split_fixed(identity, "-", 2)[,2]),
         coverage.min = as.numeric(str_split_fixed(coverage, "-", 2)[,1]),
         coverage.max = as.numeric(str_split_fixed(coverage, "-", 2)[,2]),
         n = as.numeric(str_extract(method, "\\d+")))
bold.blast_its2 <- read.table("taxonomicassignment_its2_bold-20240705.out", sep="\t", dec = ".") |>
  rename(asv_id = V1,
         subject = V2,
         accession_id = V3,
         taxonomy_id = V4,
         identity = V5,
         coverage = V6,
         evalue = V7,
         bitscore = V8,
         reference_db = V9,
         taxonomy = V10)
gb.taxa_its2 <- read.table("lca_its2_gb-20240705.out",sep="\t", dec = ".", header = FALSE, na = c("NA"))  |>
  rename(asv_id = V1,
         lca_rank = V2,
         lca_taxon = V3,
         kingdom = V4,
         phylum = V5,
         class = V6,
         order = V7,
         family = V8,
         genus = V9,
         species = V10,
         method = V11,
         identity = V12,
         coverage = V13) |>
  mutate(reference_db = "genbank") |>
  as_tibble() |>
  mutate(identity.min = as.numeric(str_split_fixed(identity, "-", 2)[,1]),
         identity.max = as.numeric(str_split_fixed(identity, "-", 2)[,2]),
         coverage.min = as.numeric(str_split_fixed(coverage, "-", 2)[,1]),
         coverage.max = as.numeric(str_split_fixed(coverage, "-", 2)[,2]),
         n = as.numeric(str_extract(method, "\\d+")))

gb.blast_its2 <- read.table("taxonomicassignment_its2_gb-20240705.out", sep="\t", dec = ".") |>
  rename(asv_id = V1,
         subject = V2,
         accession_id = V3,
         taxonomy_id = V4,
         identity = V5,
         coverage = V6,
         evalue = V7,
         bitscore = V8,
         reference_db = V9,
         taxonomy = V10)

# Add identity & coverage ranges and number of samples to asvs identified based on a lca analysis.
bold.blast_its2 <- bold.blast_its2 |>
  group_by(asv_id) |>
  filter(bitscore > 0.92*max(bitscore)) |>
  summarise(identity.max = max(identity),
            identity.min = min(identity),
            coverage.max = max(coverage),
            coverage.min = min(coverage),
            n = n()) |>
  filter(asv_id %in% filter(bold.taxa_its2, method == "lca")$asv_id)

gb.blast_its2 <- gb.blast_its2 |>
  group_by(asv_id) |>
  filter(bitscore > 0.92*max(bitscore)) |>
  summarise(identity.max = max(identity),
            identity.min = min(identity),
            coverage.max = max(coverage),
            coverage.min = min(coverage),
            n = n()) |>
  filter(asv_id %in% filter(gb.taxa_its2, method == "lca")$asv_id)

bold.taxa_its2 <- bold.taxa_its2 |>
  left_join(bold.blast_its2, by = "asv_id") |>
  mutate(identity.min = coalesce(identity.min.x, identity.min.y),
         identity.max = coalesce(identity.max.x, identity.max.y),
         coverage.min = coalesce(coverage.min.x, coverage.min.y),
         coverage.max = coalesce(coverage.max.x, coverage.max.y),
         n = coalesce(n.x, n.y))|>
  mutate(method = ifelse(str_detect(method, "top hit"), "top hit", method)) |>
  select(-contains(".x"), -contains(".y"), -identity, -coverage)

gb.taxa_its2 <- gb.taxa_its2 |>
  left_join(gb.blast_its2, by = "asv_id") |>
  mutate(identity.min = coalesce(identity.min.x, identity.min.y),
         identity.max = coalesce(identity.max.x, identity.max.y),
         coverage.min = coalesce(coverage.min.x, coverage.min.y),
         coverage.max = coalesce(coverage.max.x, coverage.max.y),
         n = coalesce(n.x, n.y))|>
  mutate(method = ifelse(str_detect(method, "top hit"), "top hit", method)) |>
  select(-contains(".x"), -contains(".y"), -identity, -coverage)

## Set unknown taxa to NA and fix lca_taxon
fix_taxon <- function(lca_rank, lca_taxon, kingdom, phylum, class, order, family, genus, species) {
  if (is.na(lca_taxon)) {
    if (lca_rank == "species") {
      if (is.na(species)) lca_rank <- "genus"
    }
    if  (lca_rank == "genus") {
      if (is.na(genus)) lca_rank <- "family"
    }
    if  (lca_rank == "family") {
      if (is.na(family)) lca_rank <- "order"
    }
    if  (lca_rank == "order") {
      if (is.na(order)) lca_rank <- "class"
    }
    if  (lca_rank == "class") {
      if (is.na(class)) lca_rank <- "phylum"
    }
    if  (lca_rank == "class") {
      if (is.na(class)) lca_rank <- "phylum"
    }
    if  (lca_rank == "phylum") {
      if (is.na(phylum)) lca_rank <- "kingdom"
    }
    if  (lca_rank == "kingdom") {
      if (is.na(kingdom)) lca_rank <- "no identification"
    }
  }
  return(lca_rank)
}

# Remove environmental samples and fix unidentified species
gb.taxa_its2 <- gb.taxa_its2 |>
  filter(!str_detect(lca_taxon, "environmental")) |>
  # Assume that taxa with a "." in the name (sp., aff., nr., etc.), or with a number are unknown species
  # Exception: sometimes a species is identified as a species "sensu lato", this identification is informative, but removed at this step
  mutate(across(3:10, ~ ifelse(.x == "no identification" |
                                 str_detect(.x, "unknown") |
                                 str_detect(.x, "\\.") |
                                 str_detect(.x, "\\d") |
                                 str_detect(.x, "endosymbiont"), NA, .x))) |>
  mutate(assign_id = 1:n()) |>
  rowwise() |>
  mutate(lca_rank = fix_taxon(lca_rank, lca_taxon, kingdom, phylum, class, order, family, genus, species)) |>
  pivot_longer(cols = 4:10, names_to = "taxon_level", values_to = "taxon") |>
  group_by(assign_id) |>
  mutate(lca_taxon = ifelse(any(is.na(lca_taxon)), taxon[taxon_level == lca_rank], lca_taxon)) |>
  pivot_wider(names_from = "taxon_level", values_from = "taxon") |>
  ungroup() |>
  select(-assign_id)

bold.taxa_its2 <- bold.taxa_its2 |>
  filter(!str_detect(lca_taxon, "environmental")) |>
  mutate(across(3:10, ~ ifelse(.x == "no identification" |
                                 str_detect(.x, "unknown") |
                                 str_detect(.x, "\\.") |
                                 str_detect(.x, "\\d") |
                                 str_detect(.x, "endosymbiont"), NA, .x))) |>
  mutate(assign_id = 1:n()) |>
  rowwise() |>
  mutate(lca_rank = fix_taxon(lca_rank, lca_taxon, kingdom, phylum, class, order, family, genus, species)) |>
  pivot_longer(cols = 4:10, names_to = "taxon_level", values_to = "taxon") |>
  group_by(assign_id) |>
  mutate(lca_taxon = ifelse(any(is.na(lca_taxon)), taxon[taxon_level == lca_rank], lca_taxon)) |>
  pivot_wider(names_from = "taxon_level", values_from = "taxon") |>
  ungroup() |>
  select(-assign_id)


## Change taxonomic nomenclature to make genbank and bold comparable
# Change BOLDs Animalia to Metazoa and Plantae to Viridiplantae
# Change Genbanks Oomycota to BOLDs classification
bold.taxa_its2 <- bold.taxa_its2 |>
  mutate(kingdom = ifelse(kingdom == "Animalia", "Metazoa", kingdom),
         kingdom = ifelse(kingdom == "Plantae", "Viridiplantae", kingdom))
gb.taxa_its2 <- gb.taxa_its2 |>
  mutate(class = ifelse(phylum == "Oomycota" & !is.na(phylum), "Oomycota", class),
         kingdom = ifelse(phylum == "Oomycota" & !is.na(phylum), "Chromista", kingdom),
         phylum = ifelse(phylum == "Oomycota" & !is.na(phylum), "Heterokontophyta", phylum))

# Some other differences
bold.taxa_its2 <- bold.taxa_its2 |>
  mutate(phylum = ifelse(phylum == "Magnoliophyta", "Streptophyta", phylum),
         class = ifelse(class == "Liliopsida", "Magnoliopsida", class))

# How many ASVs are assigned?
length(unique(gb.taxa_its2$asv_id)) #3217 ASVs assigned by genbank
length(unique(bold.taxa_its2$asv_id)) #770 ASVs assigned by bold

## Summarise asv assignments to one taxon per asv
# Combine bold and genbank assignments in a single table
taxa_its2 <- bind_rows(bold.taxa_its2, gb.taxa_its2) |>
  arrange(asv_id) |>
  group_by(asv_id)
# How many ASVs are assigned?
length(unique(taxa_its2$asv_id)) # 3217 ASVs assigned by genbank, bold or both

# Add number for taxonomic rank
taxon.level <- tibble(rank = c("kingdom", "phylum", "class", "order", "family", "genus", "species", "no identification"),
                      lca_level = c(1:7, -1))
taxa_its2 <-  taxa_its2 |>
  left_join(y = taxon.level, by = c("lca_rank" = "rank"))

#### Option:
#### 0. Nested assignments here!!

### 1. If at least one database identifies an ASV as a top hit or based on an lca analysis to either Wolbachia or Homo, use that assignment
taxa.wolbacha.homo_its2 <- taxa_its2 |>
  group_by(asv_id) |>
  filter(any(str_detect(genus, "Wolbachia")) | any(str_detect(genus, "Homo")))

summarised.taxa.wolbacha.homo_its2 <- taxa.wolbacha.homo_its2 |>
  filter(any(str_detect(genus, "Wolbachia")) | any(str_detect(genus, "Homo"))) |>
  filter(genus %in% c("Wolbachia", "Homo")) |>
  # In case of a top hit, pick the best one
  group_by(asv_id, lca_taxon) |>
  mutate(n = sum(n),
         identity.min = min(identity.min),
         identity.max = max(identity.max),
         coverage.min = min(coverage.min),
         coverage.max = max(coverage.max),
         reference_db = str_c(reference_db, collapse = ";")) |>
  distinct() |>
  group_by(asv_id) |>
  arrange(desc(identity.min), desc(coverage.max))|> ##Sort to prioritize hightest identity and coverage
  slice(1) ##pick the top hit per ASV

# Have all these ASVs been summarised into a single taxonomic assignment?
summarised.taxa.wolbacha.homo_its2 |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# Ture
nrow(summarised.taxa.wolbacha.homo_its2)
# 6 ASVs have been identified in this way

# Remove summarised taxa from list
taxa.left_its2 <- taxa_its2 |>
  filter(!(asv_id %in% summarised.taxa.wolbacha.homo_its2$asv_id))

### 1. Select ASVs where both reference databases used an lca analysis for taxonomic assignment
taxa.lca_its2 <- taxa.left_its2 |>
  filter(all(method == "lca"))

## For which ASVs is there agreement on the assignment?
# This includes ASV that have only been identified in a single database
taxa.lca.agree_its2 <- taxa.lca_its2 |>
  filter(length(unique(lca_taxon)) == 1)

# Summarise, use genbank taxonomy for summarised assignment
summarised.taxa.lca.agree_its2 <- taxa.lca.agree_its2 |>
  mutate(n_dbs = length(unique(reference_db))) |>
  mutate(
    n = sum(n),
    identity.min = min(identity.min, na.rm = TRUE),
    identity.max = max(identity.max, na.rm = TRUE),
    coverage.min = min(coverage.min, na.rm = TRUE),
    coverage.max = max(coverage.max, na.rm = TRUE)
  ) |>
  filter(if (all(n_dbs == 2)) reference_db == "genbank" else TRUE) |>
  mutate(reference_db = ifelse(n_dbs == 2, "bold;genbank", reference_db)) |>
  # Use `across()` within `mutate()` to apply the `first` function to all columns
  mutate(across(everything(), first, .names = "{col}"))

problematic_asvs <- summarised.taxa.lca.agree_its2 |>
  group_by(asv_id) |>
  summarise(n_assignments = n()) |>
  filter(n_assignments > 1)
print(problematic_asvs)

problematic_asvs_its2 <- taxa.lca.agree_its2|>
  filter(asv_id %in% problematic_asvs$asv_id) |>
  arrange(asv_id)

# Force a single taxonomic assignment by selecting the first row for each asv_id
summarised.taxa.lca.agree_its2 <- summarised.taxa.lca.agree_its2 %>%
  group_by(asv_id) %>%
  slice(1) %>%
  ungroup()

# Have all these ASVs been summarised into a single taxonomic assignment?
summarised.taxa.lca.agree_its2 |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# correct
nrow(summarised.taxa.lca.agree_its2)
# 1076 ASVs have been identified in this way

taxa.left_its2 <- taxa.left_its2 |>
  filter(!(asv_id %in% summarised.taxa.lca.agree_its2$asv_id)) #21314

# For which taxa is there no agreement on the assignment? #306
taxa.lca.disagree_its2 <- taxa.lca_its2 |>
  filter(length(unique(lca_taxon)) > 1)

# Some of this disagreement may be because of differences in the level of taxonomic assignment 1448
taxa.lca.disagree.level_its2 <- taxa.lca.disagree_its2 |>
  filter(length(unique(lca_level)) > 1)

# Check if there is agreement at higher taxonomic levels
agreement.level <- function(kingdom, phylum, class, order, family, genus, species) {
  if (length(unique(species)) == 1 & !any(is.na(species))) {
    lvl <- 7
  } else if (length(unique(genus)) == 1 & !any(is.na(genus))) {
    lvl <- 6
  } else if (length(unique(family)) == 1 & !any(is.na(family))) {
    lvl <- 5
  } else if (length(unique(order)) == 1 & !any(is.na(order))) {
    lvl <- 4
  } else if (length(unique(class)) == 1 & !any(is.na(class))) {
    lvl <- 3
  } else if (length(unique(phylum)) == 1 & !any(is.na(phylum))) {
    lvl <- 2
  } else if (length(unique(kingdom)) == 1 & !any(is.na(kingdom))) {
    lvl <- 1
  } else lvl <- -1
  return(lvl)
}
# Find the level of agreement
taxa.lca.disagree.level_its2 <- taxa.lca.disagree.level_its2 |>
  mutate(lvl_agree = agreement.level(kingdom, phylum, class, order, family, genus, species))

# If the level of agreement between bold and genbank corresponds to the lca level of the database that identifies to the higher taxonomic level,
# the databases only disagree on the level of taxonomic assignment, not on the taxonomy itself
# 201
summarised.taxa.lca.disagree.level_its2 <- taxa.lca.disagree.level_its2 |>
  filter(lvl_agree == min(lca_level)) |>
  mutate(n_dbs = length(unique(reference_db))) |>
  filter(lca_level == max(lca_level))|>
  slice(1)

# Have all these ASVs been summarised into a single taxonomic assignment?
summarised.taxa.lca.disagree.level_its2 |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# True
nrow(summarised.taxa.lca.disagree.level_its2)
# 101 ASVs have been identified in this way

# What ASVs are left
taxa.lca.disagree_its2 <- taxa.lca.disagree_its2 |>
  filter(!(asv_id %in% summarised.taxa.lca.disagree.level_its2$asv_id)) #0
# None left!
taxa.left_its2 <- taxa.left_its2 |>
  filter(!(asv_id %in% summarised.taxa.lca.disagree.level_its2$asv_id)) #21008

### 2. Taxa with at least one top hit match in one of the databases, and a lca in the other
taxa.toplca_its2 <- taxa.left_its2 |>
  filter(!all(method == "top hit") & any(method == "top hit")) #1198

# For what ASVs does the assignment disagree at the kingdom level?
# This usually means that a hit has the wrong label in the database
taxa.toplca.disagree.kingdom_its2 <- taxa.toplca_its2 |>
  filter(length(unique(kingdom)) > 1) #0

## Summarise the top hits into a single assignment per ASV, and compare with the lca analysis of the other database
# Load function to select best top hit
source("get_tophit.R")
source("agreement_tophit.R")

# Increase the time limit to, for example, 600 seconds
setTimeLimit(cpu = 600, elapsed = 600)

taxa.toplca_its2 <- taxa.toplca_its2 |>
  # Combine duplicate assignemnts
  group_by(asv_id, reference_db, lca_rank, lca_taxon, method, kingdom, phylum, class, order, family, genus, species, lca_level) |>
  summarise(identity.min = min(identity.min),
            identity.max = max(identity.max),
            coverage.min = min(coverage.min),
            coverage.max = max(coverage.max),
            n = sum(n)) |>
  group_by(asv_id, reference_db)|>
  group_split()

taxa.toplca_its2 <- lapply(taxa.toplca_its2, get_tophit) |>
  bind_rows() |>
  # Only keep the best top hit
  filter(iv.rank == 1) |>
  # Get lowest common ancestor if there is still more then a single top hit
  group_by(asv_id, reference_db) |>
  group_split()
taxa.toplca_its2 <- lapply(taxa.toplca_its2, agreement.tophit) |>
  bind_rows()

## Check if top hits are nested within the assignment by the lca analysis in the other
summarised.toplca.nested_its2 <- taxa.toplca_its2 |>
  group_by(asv_id) |>
  mutate(lvl_agree = agreement.level(kingdom, phylum, class, order, family, genus, species)) |>
  filter(lvl_agree %in% lca_level) |>
  filter(method == "top hit")

# Have all these ASVs been summarised into a single taxonomic assignment?
summarised.toplca.nested_its2 |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# Correct
nrow(summarised.toplca.nested_its2)
# 89 ASVs have been identified in this way

# What ASVs are left
taxa.toplca_its2 <- taxa.toplca_its2 |>
  filter(!(asv_id %in% summarised.toplca.nested_its2$asv_id))
# still 8 taxa left

taxa.left_its2 <- taxa.left_its2 |>
  filter(!(asv_id %in% summarised.toplca.nested_its2$asv_id)) #19838

###################################################################################
left_taxa.toplca_its2<-taxa.toplca_its2

process_remaining_data <- function(df, id_col = "asv_id") {
  df <- df %>%
    group_by(!!sym(id_col)) %>%  # Use the correct id column for grouping
    summarise(
      # Compare each taxonomic level; if values are consistent, return the value, else NA
      kingdom = if_else(length(unique(na.omit(kingdom))) == 1, first(na.omit(kingdom)), NA_character_),
      phylum = if_else(length(unique(na.omit(phylum))) == 1, first(na.omit(phylum)), NA_character_),
      class = if_else(length(unique(na.omit(class))) == 1, first(na.omit(class)), NA_character_),
      order = if_else(length(unique(na.omit(order))) == 1, first(na.omit(order)), NA_character_),
      family = if_else(length(unique(na.omit(family))) == 1, first(na.omit(family)), NA_character_),
      genus = if_else(length(unique(na.omit(genus))) == 1, first(na.omit(genus)), NA_character_),
      species = if_else(length(unique(na.omit(species))) == 1, first(na.omit(species)), NA_character_),

      # Get the first row's values for all other columns
      across(everything(), first, .names = "{col}"),

      # Determine the lowest taxonomic rank with an agreement
      lca_rank = case_when(
        !is.na(species) ~ "species",
        !is.na(genus) ~ "genus",
        !is.na(family) ~ "family",
        !is.na(order) ~ "order",
        !is.na(class) ~ "class",
        !is.na(phylum) ~ "phylum",
        !is.na(kingdom) ~ "kingdom",
        TRUE ~ NA_character_
      ),

      # Assign the corresponding level for lca_rank
      lca_level = case_when(
        !is.na(species) ~ 7,
        !is.na(genus) ~ 6,
        !is.na(family) ~ 5,
        !is.na(order) ~ 4,
        !is.na(class) ~ 3,
        !is.na(phylum) ~ 2,
        !is.na(kingdom) ~ 1,
        TRUE ~ NA_integer_
      ),

      # Get the taxon at the lowest common rank
      lca_taxon = coalesce(species, genus, family, order, class, phylum, kingdom)
    ) %>%
    ungroup()

  return(df)
}

# Apply the function to your remaining dataset with the correct id column
summarised.toplca.nested_its2_left <- process_remaining_data(left_taxa.toplca_its2, id_col = "asv_id")

# What ASVs are left
taxa.toplca_its2 <- taxa.toplca_its2 |>
  filter(!(asv_id %in% summarised.toplca.nested_its2_left$asv_id))
# no taxa left

taxa.left_its2 <- taxa.left_its2 |>
  filter(!(asv_id %in% summarised.toplca.nested_its2_left$asv_id)) #19810
####################################################################################
### 3. Taxa with top hits in both databases
taxa.top_its2 <- taxa.left_its2 |>
  group_by(asv_id) |>
  filter(all(method == "top hit"))

taxa.top_its2 <- taxa.top_its2 |>
  # Combine duplicate assignemnts
  group_by(asv_id, reference_db, lca_rank, lca_taxon, method, kingdom, phylum, class, order, family, genus, species, lca_level) |>
  summarise(identity.min = min(identity.min),
            identity.max = max(identity.max),
            coverage.min = min(coverage.min),
            coverage.max = max(coverage.max),
            n = sum(n)) |>
  group_by(asv_id) |>
  group_split()

taxa.top_its2 <- lapply(taxa.top_its2, get_tophit) |>
  bind_rows() |>
  # Only keep the best top hit
  filter(iv.rank == 1) |>
  # Get lowest common ancestor if there is still more then a single top hit
  group_by(asv_id, reference_db) |>
  group_split()

taxa.top_its2 <- lapply(taxa.top_its2, agreement.tophit) |>
  bind_rows()

## Compare the best top hits of both databases
# If nested, follow the database with the identification to the lowest taxonomic level
summarised.taxa.top.nested_its2 <- taxa.top_its2 |>
  group_by(asv_id) |>
  mutate(lvl_agree = agreement.level(kingdom, phylum, class, order, family, genus, species)) |>
  filter(lvl_agree %in% lca_level) |>
  filter(lca_level == max(lca_level)) |>
  # Combine duplicate hits
  group_by(asv_id, lca_rank, lca_taxon, method, kingdom, phylum, class, order, family, genus, species, lca_level) |>
  summarise(reference_db = str_c(reference_db, collapse = ";"),
            n_dbs = length(unique(reference_db)),
            identity.min = min(identity.min),
            identity.max = max(identity.max),
            coverage.min = min(coverage.min),
            coverage.max = max(coverage.max),
            n = sum(n)) |>
  group_by(asv_id)

# Have all these ASVs been summarised into a single taxonomic assignment?
summarised.taxa.top.nested_its2 |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# Ture
nrow(summarised.taxa.top.nested_its2)
#  1716 ASVs have been identified in this way

# What ASVs are left
taxa.top_its2 <- taxa.top_its2 |>
  filter(!(asv_id %in% summarised.taxa.top.nested_its2$asv_id)) #32

taxa.left_its2 <- taxa.left_its2 |>
  filter(!(asv_id %in% summarised.taxa.top.nested_its2$asv_id)) #844

### Get the lowest common ancestor for the other asvs
taxa.top.disagreement_its2 <- taxa.top_its2 |>
  group_by(asv_id) |>
  mutate(reference_db = str_c(reference_db, collapse = ";"),
         n_dbs = length(unique(reference_db)),
         identity.min = min(identity.min),
         identity.max = max(identity.max),
         coverage.min = min(coverage.min),
         coverage.max = max(coverage.max),
         n = sum(n)) |>
  group_split()

summarised.taxa.top.disagreement_its2 <- lapply(taxa.top.disagreement_its2, agreement.tophit) |>
  bind_rows()

# Have all these ASVs been summarised into a single taxonomic assignment?
summarised.taxa.top.disagreement_its2 |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# Correct
nrow(summarised.taxa.top.disagreement_its2)
# 16 ASVs have been identified in this way

# What ASVs are left
taxa.top_its2 <- taxa.top_its2 |>
  filter(!(asv_id %in% summarised.taxa.top.disagreement_its2$asv_id))
# No taxa left

taxa.left_its2 <- taxa.left_its2 |>
  filter(!(asv_id %in% summarised.taxa.top.disagreement_its2$asv_id)) #424
#####################################################################################
### 4. Taxa that have not been identified in at least one of the reference dbs ("no lca")
taxa.nolca_its2 <- taxa.left_its2 |>
  filter(any(method == "no lca")) #424

# No identification in one database: follow the other
summarised.taxa.nolca1_its2 <- taxa.nolca_its2 |>
  filter(method != "no lca")

# Force a single taxonomic assignment by selecting the first row for each asv_id
summarised.taxa.nolca1_its2 <- summarised.taxa.nolca1_its2 %>%
  group_by(asv_id) %>%
  slice(1) %>%
  ungroup()

# Have all these ASVs been summarised into a single taxonomic assignment?
summarised.taxa.nolca1_its2 |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# Correct
nrow(summarised.taxa.nolca1_its2)
# 4 ASVs have been identified in this way

# What ASVs are left?
taxa.nolca_its2 <- taxa.nolca_its2 |>
  filter(!(asv_id %in% summarised.taxa.nolca1_its2$asv_id)) #412

taxa.left_its2 <- taxa.left_its2 |>
  filter(!(asv_id %in% summarised.taxa.nolca1_its2$asv_id)) #412

# No identification in both databases
# 205
summarised.taxa.noident_its2 <- taxa.nolca_its2 |>
  filter(all(method == "no lca")) |>
  mutate(reference_db = str_c(reference_db, collapse = ";")) |>
  distinct()

# Have all these ASVs been summarised into a single taxonomic assignment?
summarised.taxa.noident_its2 |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# Correct
nrow(summarised.taxa.noident_its2)
# 100 ASVs have been identified in this way


# What ASVs are left?
taxa.nolca_its2 <- taxa.nolca_its2 |>
  filter(!(asv_id %in% summarised.taxa.noident_its2$asv_id))
# 4 taxa are left, but they are totally fine to combine

taxa.left_its2 <- taxa.left_its2 |>
  filter(!(asv_id %in% summarised.taxa.noident_its2$asv_id))
# No taxa left!

## Combine everything
taxatable_its2 <- list(select(summarised.taxa.lca.agree_its2,
                             c(asv_id, lca_rank, lca_taxon, method, reference_db, kingdom, phylum, class, order, family, genus, species)),
                      select(summarised.taxa.lca.disagree.level_its2,
                             c(asv_id, lca_rank, lca_taxon, method, reference_db, kingdom, phylum, class, order, family, genus, species)),
                      select(summarised.taxa.noident_its2,
                             c(asv_id, lca_rank, lca_taxon, method, reference_db, kingdom, phylum, class, order, family, genus, species)),
                      select(summarised.taxa.nolca1_its2,
                             c(asv_id, lca_rank, lca_taxon, method, reference_db, kingdom, phylum, class, order, family, genus, species)),
                      select(summarised.taxa.top.disagreement_its2,
                             c(asv_id, lca_rank, lca_taxon, method, reference_db, kingdom, phylum, class, order, family, genus, species)),
                      select(summarised.taxa.top.nested_its2,
                             c(asv_id, lca_rank, lca_taxon, method, reference_db, kingdom, phylum, class, order, family, genus, species)),
                      select(summarised.taxa.toplca.disagree.kingdom_its2,
                             c(asv_id, lca_rank, lca_taxon, method, reference_db, kingdom, phylum, class, order, family, genus, species)),
                      select(summarised.taxa.wolbacha.homo_its2,
                             c(asv_id, lca_rank, lca_taxon, method, reference_db, kingdom, phylum, class, order, family, genus, species)),
                      select(summarised.toplca.nested_its2,
                             c(asv_id, lca_rank, lca_taxon, method, reference_db, kingdom, phylum, class, order, family, genus, species)),
                      select(summarised.toplca.nested_its2_left,
                             c(asv_id, lca_rank, lca_taxon, method, reference_db, kingdom, phylum, class, order, family, genus, species)))|>
  do.call(what = rbind)

## Final checks: have all ASVs been assigned to a single taxon?
taxatable_its2 |>
  summarise(n = n()) |>
  filter(n > 1) |>
  nrow() == 0
# Correct!

## Are all ASVs included in the taxatable?
sum(!(taxatable_its2$asv_id) %in% unique(taxa_its2$asv_id)) == 0
# Correct!

### Export
write.csv(taxatable_its2, file = "taxatable_its2_20240821.csv", quote = FALSE, row.names = FALSE)

write.xlsx(taxatable_its2, file = file.path("D:/pigeon/metabarcoding/pigeondata/taxa_checked", "taxatable_its2_20240821.xlsx"))



















