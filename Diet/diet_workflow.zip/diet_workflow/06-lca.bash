#!/bin/bash

# Set directory
cd /scratch/p314509/metabarcoding/
source /scratch/hb-conseco_lab/python_venvs/venv_metabarcoding/bin/activate

git clone https://github.com/naturalis/galaxy-tool-lca

chmod 755 galaxy-tool-lca/lca.sh
chmod 755 galaxy-tool-lca/lca.py

# Run lca on bold and genbank results for coi and trnl
mkdir 05-taxonomic_assignment
python galaxy-tool-lca/lca.py -i 04-blast/taxonomicassignment_coi_gb-20240705.out -o 05-taxonomic_assignment/lca_coi_gb-20240705.out -b 8 -id 80 -cov 80 -t best_hits_range -tid 98 -tcov 100 -flh unknown
python galaxy-tool-lca/lca.py -i 04-blast/taxonomicassignment_coi_bold-20240705.out -o 05-taxonomic_assignment/lca_coi_bold-20240705.out -b 8 -id 80 -cov 80 -t best_hits_range -tid 98 -tcov 100 -flh unknown
python galaxy-tool-lca/lca.py -i 04-blast/taxonomicassignment_its2_gb-20240705.out -o 05-taxonomic_assignment/lca_its2_gb-20240705.out -b 8 -id 80 -cov 80 -t best_hits_range -tid 98 -tcov 100 -flh unknown
python galaxy-tool-lca/lca.py -i 04-blast/taxonomicassignment_its2_bold-20240705.out -o 05-taxonomic_assignment/lca_its2_bold-20240705.out -b 8 -id 80 -cov 80 -t best_hits_range -tid 98 -tcov 100 -flh unknown

deactivate 